export type Testament = 'AT' | 'NT';

export type BookCategory =
  | 'Pentateuco'
  | 'Históricos'
  | 'Poéticos'
  | 'Profetas Maiores'
  | 'Profetas Menores'
  | 'Evangelhos'
  | 'Histórico NT'
  | 'Epístolas Paulinas'
  | 'Epístolas Gerais'
  | 'Profético';

export interface BibleBook {
  id: string;
  name: string;
  testament: Testament;
  category: BookCategory;
  chaptersCount: number;
  abbreviation: string;
  description: string;
}

export interface Verse {
  bookId: string;
  bookName: string;
  chapter: number;
  verse: number;
  text: string;
}

export interface Highlight {
  id: string;
  bookId: string;
  chapter: number;
  verse: number;
  color: 'amber' | 'emerald' | 'sky' | 'rose';
  date: string;
  text: string;
}

export interface FavoriteVerse {
  id: string;
  bookId: string;
  bookName: string;
  chapter: number;
  verse: number;
  text: string;
  date: string;
}

export type QuizCategory =
  | 'Personagens'
  | 'Antigo Testamento'
  | 'Novo Testamento'
  | 'Jesus'
  | 'Profetas'
  | 'Evangelhos'
  | 'Versículos'
  | 'História bíblica';

export type QuizDifficulty = 'Fácil' | 'Médio' | 'Difícil' | 'Mestre';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  reference: string;
  category: QuizCategory;
  difficulty: QuizDifficulty;
  xpReward: number;
}

export interface BiblicalCharacter {
  id: string;
  name: string;
  role: string;
  testament: Testament;
  category: 'Patriarcas' | 'Líderes e Juízes' | 'Reis' | 'Profetas' | 'Mulheres da Bíblia' | 'Apóstolos e Discípulos' | 'Figuras Centrais';
  summary: string;
  avatarIcon: string;
  importantEvents: string[];
  keyVerses: { ref: string; text: string }[];
  curiosities: string[];
  quizQuestionId?: string;
}

export type EmotionalMood =
  | 'peace'
  | 'sad'
  | 'worried'
  | 'strength'
  | 'grateful'
  | 'afraid'
  | 'direction';

export interface MoodEntry {
  id: EmotionalMood;
  label: string;
  emoji: string;
  verse: {
    reference: string;
    text: string;
  };
  reflection: string;
  prayer: string;
}

export interface JourneyMilestone {
  id: string;
  order: number;
  title: string;
  subtitle: string;
  icon: string;
  epoch: string;
  story: string;
  recommendedChapters: { bookId: string; bookName: string; chapter: number; label: string }[];
  keyCharacters: string[];
  quizCategory: QuizCategory;
  requiredXp: number;
  completed: boolean;
}

export interface ReadingPlanDay {
  day: number;
  title: string;
  passages: { bookId: string; bookName: string; chapter: number }[];
  completed: boolean;
}

export interface ReadingPlan {
  id: string;
  title: string;
  durationDays: number;
  description: string;
  category: 'Iniciante' | 'Geral' | 'Devocional' | 'Avançado';
  isPremium: boolean;
  days: ReadingPlanDay[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  requiredMetric: 'chaptersRead' | 'streakDays' | 'questionsAnswered' | 'correctAnswers' | 'plansCompleted' | 'totalXp';
  threshold: number;
  unlockedAt?: string;
}

export interface DailyMission {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  progress: number;
  maxProgress: number;
  completed: boolean;
  type: 'read_chapter' | 'do_quiz' | 'do_devotional';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar: string;
  level: number;
  levelName: string;
  totalXp: number;
  streakDays: number;
  lastActiveDate: string;
  isPremium: boolean;
  goal: string;
  chaptersReadCount: number;
  questionsAnsweredCount: number;
  correctAnswersCount: number;
  plansCompletedCount: number;
}

export interface BibleIAAnswer {
  scripture: string;
  explanation: string;
  interpretation: string;
  reflection: string;
}
