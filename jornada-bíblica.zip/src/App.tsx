import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { NotificationToast } from './components/NotificationToast';
import { HomeTab } from './components/HomeTab';
import { BibleTab } from './components/BibleTab';
import { QuizTab } from './components/QuizTab';
import { JourneyTab } from './components/JourneyTab';
import { ProfileTab } from './components/ProfileTab';

import { DevotionalModal } from './components/DevotionalModal';
import { AiBibleModal } from './components/AiBibleModal';
import { CharactersModal } from './components/CharactersModal';
import { ReadingPlansModal } from './components/ReadingPlansModal';
import { PremiumModal } from './components/PremiumModal';
import { AdminModal } from './components/AdminModal';
import { OnboardingModal } from './components/OnboardingModal';
import { AuthModal } from './components/AuthModal';
import { ExportModal } from './components/ExportModal';

const AppContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="min-h-screen bg-amber-50/20 text-slate-800 flex flex-col font-sans selection:bg-amber-200 selection:text-amber-950">
      {/* Toast notifications */}
      <NotificationToast />

      {/* Top Navbar */}
      <Navbar />

      {/* Main Responsive Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-5 pb-20">
        {activeTab === 'home' && <HomeTab />}
        {activeTab === 'bible' && <BibleTab />}
        {activeTab === 'quiz' && <QuizTab />}
        {activeTab === 'journey' && <JourneyTab />}
        {activeTab === 'profile' && <ProfileTab />}
      </main>

      {/* Modals & Dialogs */}
      <DevotionalModal />
      <AiBibleModal />
      <CharactersModal />
      <ReadingPlansModal />
      <PremiumModal />
      <AdminModal />
      <OnboardingModal />
      <AuthModal />
      <ExportModal />

      {/* Mobile/Desktop Bottom Navigation */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
