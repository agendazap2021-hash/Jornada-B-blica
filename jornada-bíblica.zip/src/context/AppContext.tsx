import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  Highlight,
  FavoriteVerse,
  Achievement,
  ReadingPlan,
  JourneyMilestone,
  QuizQuestion,
  BiblicalCharacter,
  DailyMission
} from '../types';
import { INITIAL_ACHIEVEMENTS } from '../data/achievementsData';
import { READING_PLANS } from '../data/readingPlansData';
import { JOURNEY_MILESTONES } from '../data/journeyData';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { BIBLICAL_CHARACTERS } from '../data/charactersData';

// Levels configuration
export const LEVELS_CONFIG = [
  { level: 1, name: 'Iniciante', minXp: 0, maxXp: 200 },
  { level: 2, name: 'Explorador', minXp: 201, maxXp: 500 },
  { level: 3, name: 'Aprendiz', minXp: 501, maxXp: 1000 },
  { level: 4, name: 'Discípulo', minXp: 1001, maxXp: 2000 },
  { level: 5, name: 'Estudioso', minXp: 2001, maxXp: 3500 },
  { level: 6, name: 'Mestre', minXp: 3501, maxXp: 6000 },
];

export function getLevelInfo(xp: number) {
  const current = LEVELS_CONFIG.find((l) => xp >= l.minXp && xp <= l.maxXp) || LEVELS_CONFIG[LEVELS_CONFIG.length - 1];
  const next = LEVELS_CONFIG.find((l) => l.level === current.level + 1);

  const prevMax = current.level === 1 ? 0 : LEVELS_CONFIG[current.level - 2].maxXp;
  const range = current.maxXp - prevMax;
  const progressInLevel = Math.max(0, xp - prevMax);
  const percent = next ? Math.min(100, Math.round((progressInLevel / range) * 100)) : 100;

  return {
    level: current.level,
    levelName: current.name,
    currentXp: xp,
    nextLevelXp: next ? current.maxXp : xp,
    xpToNext: next ? Math.max(0, current.maxXp - xp) : 0,
    percent,
  };
}

// Gentle pleasant synthesised audio feedback
function playSoundEffect(type: 'success' | 'level' | 'badge' | 'click' | 'wrong') {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    if (type === 'success') {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.08); // E5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.16); // G5
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'level') {
      const notes = [440, 554.37, 659.25, 880];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        const start = ctx.currentTime + idx * 0.09;
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.18, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.28);
        osc.start(start);
        osc.stop(start + 0.28);
      });
    } else if (type === 'wrong') {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.2);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    }
  } catch {
    // Audio context may be blocked by browser policy until interaction
  }
}

interface ToastNotification {
  id: string;
  title: string;
  message: string;
  type?: 'xp' | 'level' | 'badge' | 'info';
}

interface AppContextType {
  user: UserProfile;
  activeTab: 'home' | 'bible' | 'quiz' | 'journey' | 'profile';
  setActiveTab: (tab: 'home' | 'bible' | 'quiz' | 'journey' | 'profile') => void;
  // Reader navigation
  currentBookId: string;
  currentChapter: number;
  openChapter: (bookId: string, chapter: number) => void;
  // XP & Gamification
  addXp: (amount: number, reason: string) => void;
  markChapterAsRead: (bookId: string, chapter: number) => void;
  completeDevotional: () => void;
  recordQuizResult: (correctCount: number, totalQuestions: number, xpEarned: number) => void;
  // Favorites & Highlights
  favorites: FavoriteVerse[];
  toggleFavorite: (bookId: string, bookName: string, chapter: number, verse: number, text: string) => void;
  highlights: Highlight[];
  addHighlight: (bookId: string, chapter: number, verse: number, color: 'amber' | 'emerald' | 'sky' | 'rose', text: string) => void;
  removeHighlight: (id: string) => void;
  // Reading Plans
  readingPlans: ReadingPlan[];
  togglePlanDay: (planId: string, dayNumber: number) => void;
  // Journey
  journeyMilestones: JourneyMilestone[];
  completeMilestone: (milestoneId: string) => void;
  // Characters & Quizzes
  biblicalCharacters: BiblicalCharacter[];
  quizQuestions: QuizQuestion[];
  achievements: Achievement[];
  dailyMissions: DailyMission[];
  // Modals & Panels
  isDevotionalOpen: boolean;
  setIsDevotionalOpen: (v: boolean) => void;
  isCharactersOpen: boolean;
  setIsCharactersOpen: (v: boolean) => void;
  selectedCharacter: BiblicalCharacter | null;
  setSelectedCharacter: (c: BiblicalCharacter | null) => void;
  isAiBibleOpen: boolean;
  setIsAiBibleOpen: (v: boolean) => void;
  isPlansOpen: boolean;
  setIsPlansOpen: (v: boolean) => void;
  selectedPlan: ReadingPlan | null;
  setSelectedPlan: (p: ReadingPlan | null) => void;
  isPremiumOpen: boolean;
  setIsPremiumOpen: (v: boolean) => void;
  isAdminOpen: boolean;
  setIsAdminOpen: (v: boolean) => void;
  isOnboardingOpen: boolean;
  setIsOnboardingOpen: (v: boolean) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (v: boolean) => void;
  isExportOpen: boolean;
  setIsExportOpen: (v: boolean) => void;
  // Toasts
  toasts: ToastNotification[];
  dismissToast: (id: string) => void;
  showToast: (title: string, message: string, type?: 'xp' | 'level' | 'badge' | 'info') => void;
  // Admin & Settings
  addQuizQuestion: (q: QuizQuestion) => void;
  addCharacter: (c: BiblicalCharacter) => void;
  togglePremiumSubscription: () => void;
  updateUserGoal: (goal: string) => void;
  loginUser: (email: string, name: string) => void;
  logoutUser: () => void;
  resetAllProgress: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

const DEFAULT_USER: UserProfile = {
  id: 'usr_default',
  name: 'Discípulo da Palavra',
  email: 'ederlopespro@gmail.com',
  avatar: '✝️',
  level: 5,
  levelName: 'Estudioso',
  totalXp: 2150,
  streakDays: 7,
  lastActiveDate: new Date().toISOString().split('T')[0],
  isPremium: false,
  goal: 'Ler mais a Bíblia e ter um momento diário com Deus',
  chaptersReadCount: 24,
  questionsAnsweredCount: 58,
  correctAnswersCount: 47,
  plansCompletedCount: 1,
};

const DEFAULT_DAILY_MISSIONS: DailyMission[] = [
  { id: 'm-read', title: 'Leitura Sagrada', description: 'Ler pelo menos 1 capítulo da Bíblia', xpReward: 50, progress: 1, maxProgress: 1, completed: true, type: 'read_chapter' },
  { id: 'm-devotional', title: 'Momento com Deus', description: 'Realizar o momento devocional diário', xpReward: 30, progress: 1, maxProgress: 1, completed: true, type: 'do_devotional' },
  { id: 'm-quiz', title: 'Mente Sábia', description: 'Acertar 5 perguntas no Desafio Bíblico', xpReward: 100, progress: 3, maxProgress: 5, completed: false, type: 'do_quiz' },
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // User Profile
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('jb_user');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_USER;
  });

  const [activeTab, setActiveTab] = useState<'home' | 'bible' | 'quiz' | 'journey' | 'profile'>('home');
  const [currentBookId, setCurrentBookId] = useState<string>('sl');
  const [currentChapter, setCurrentChapter] = useState<number>(23);

  // Lists
  const [favorites, setFavorites] = useState<FavoriteVerse[]>(() => {
    const saved = localStorage.getItem('jb_favorites');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'fav-1',
        bookId: 'sl',
        bookName: 'Salmos',
        chapter: 23,
        verse: 1,
        text: 'O SENHOR é o meu pastor; nada me faltará.',
        date: '2026-09-24',
      },
      {
        id: 'fav-2',
        bookId: 'fp',
        bookName: 'Filipenses',
        chapter: 4,
        verse: 13,
        text: 'Tudo posso naquele que me fortalece.',
        date: '2026-09-25',
      }
    ];
  });

  const [highlights, setHighlights] = useState<Highlight[]>(() => {
    const saved = localStorage.getItem('jb_highlights');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [
      {
        id: 'hl-1',
        bookId: 'sl',
        chapter: 23,
        verse: 4,
        color: 'amber',
        date: '2026-09-25',
        text: 'Ainda que eu ande pelo vale da sombra da morte, não temerei mal nenhum, porque tu estás comigo;'
      }
    ];
  });

  const [readingPlans, setReadingPlans] = useState<ReadingPlan[]>(() => {
    const saved = localStorage.getItem('jb_plans');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return READING_PLANS;
  });

  const [journeyMilestones, setJourneyMilestones] = useState<JourneyMilestone[]>(() => {
    const saved = localStorage.getItem('jb_journey');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return JOURNEY_MILESTONES;
  });

  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(() => {
    const saved = localStorage.getItem('jb_quiz_questions');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return QUIZ_QUESTIONS;
  });

  const [biblicalCharacters, setBiblicalCharacters] = useState<BiblicalCharacter[]>(() => {
    const saved = localStorage.getItem('jb_characters');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return BIBLICAL_CHARACTERS;
  });

  const [achievements, setAchievements] = useState<Achievement[]>(() => {
    const saved = localStorage.getItem('jb_achievements');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return INITIAL_ACHIEVEMENTS;
  });

  const [dailyMissions, setDailyMissions] = useState<DailyMission[]>(() => {
    const saved = localStorage.getItem('jb_missions');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_DAILY_MISSIONS;
  });

  // Modals state
  const [isDevotionalOpen, setIsDevotionalOpen] = useState(false);
  const [isCharactersOpen, setIsCharactersOpen] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState<BiblicalCharacter | null>(null);
  const [isAiBibleOpen, setIsAiBibleOpen] = useState(false);
  const [isPlansOpen, setIsPlansOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<ReadingPlan | null>(null);
  const [isPremiumOpen, setIsPremiumOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Toast notifications queue
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  const showToast = (title: string, message: string, type: 'xp' | 'level' | 'badge' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      dismissToast(id);
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('jb_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('jb_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('jb_highlights', JSON.stringify(highlights));
  }, [highlights]);

  useEffect(() => {
    localStorage.setItem('jb_plans', JSON.stringify(readingPlans));
  }, [readingPlans]);

  useEffect(() => {
    localStorage.setItem('jb_journey', JSON.stringify(journeyMilestones));
  }, [journeyMilestones]);

  useEffect(() => {
    localStorage.setItem('jb_quiz_questions', JSON.stringify(quizQuestions));
  }, [quizQuestions]);

  useEffect(() => {
    localStorage.setItem('jb_characters', JSON.stringify(biblicalCharacters));
  }, [biblicalCharacters]);

  useEffect(() => {
    localStorage.setItem('jb_achievements', JSON.stringify(achievements));
  }, [achievements]);

  useEffect(() => {
    localStorage.setItem('jb_missions', JSON.stringify(dailyMissions));
  }, [dailyMissions]);

  // Open Chapter in Bible reader
  const openChapter = (bookId: string, chapter: number) => {
    setCurrentBookId(bookId);
    setCurrentChapter(chapter);
    setActiveTab('bible');
  };

  // Check achievements after stats change
  const checkAchievements = (updatedUser: UserProfile) => {
    setAchievements((prev) =>
      prev.map((ach) => {
        if (ach.unlockedAt) return ach;
        let unlocked = false;
        if (ach.requiredMetric === 'chaptersRead' && updatedUser.chaptersReadCount >= ach.threshold) unlocked = true;
        if (ach.requiredMetric === 'streakDays' && updatedUser.streakDays >= ach.threshold) unlocked = true;
        if (ach.requiredMetric === 'questionsAnswered' && updatedUser.questionsAnsweredCount >= ach.threshold) unlocked = true;
        if (ach.requiredMetric === 'correctAnswers' && updatedUser.correctAnswersCount >= ach.threshold) unlocked = true;
        if (ach.requiredMetric === 'plansCompleted' && updatedUser.plansCompletedCount >= ach.threshold) unlocked = true;
        if (ach.requiredMetric === 'totalXp' && updatedUser.totalXp >= ach.threshold) unlocked = true;

        if (unlocked) {
          playSoundEffect('badge');
          showToast(`🏆 Conquista Desbloqueada: ${ach.title}!`, ach.description, 'badge');
          return { ...ach, unlockedAt: new Date().toISOString().split('T')[0] };
        }
        return ach;
      })
    );
  };

  // Add XP and handle level up
  const addXp = (amount: number, reason: string) => {
    setUser((prev) => {
      const newXp = prev.totalXp + amount;
      const oldLevelInfo = getLevelInfo(prev.totalXp);
      const newLevelInfo = getLevelInfo(newXp);

      let updated = {
        ...prev,
        totalXp: newXp,
        level: newLevelInfo.level,
        levelName: newLevelInfo.levelName,
      };

      if (newLevelInfo.level > oldLevelInfo.level) {
        playSoundEffect('level');
        showToast(
          `🎉 Parabéns! Subiu de Nível!`,
          `Você agora é Nível ${newLevelInfo.level} — ${newLevelInfo.levelName}!`,
          'level'
        );
      } else {
        playSoundEffect('success');
        showToast(`+${amount} XP!`, reason, 'xp');
      }

      checkAchievements(updated);
      return updated;
    });
  };

  // Mark chapter as read (+50 XP)
  const markChapterAsRead = (bookId: string, chapter: number) => {
    setUser((prev) => {
      const updated = {
        ...prev,
        chaptersReadCount: prev.chaptersReadCount + 1,
      };
      checkAchievements(updated);
      return updated;
    });

    addXp(50, `Leitura concluída com sucesso! (+50 XP)`);

    // Update daily mission
    setDailyMissions((prev) =>
      prev.map((m) => {
        if (m.type === 'read_chapter' && !m.completed) {
          const newProg = m.progress + 1;
          const completed = newProg >= m.maxProgress;
          if (completed) showToast('🎯 Missão Diária Cumprida!', 'Você completou a leitura sagrada do dia.', 'info');
          return { ...m, progress: newProg, completed };
        }
        return m;
      })
    );
  };

  // Complete Devotional (+30 XP)
  const completeDevotional = () => {
    addXp(30, 'Momento com Deus realizado com serenidade (+30 XP)');
    setDailyMissions((prev) =>
      prev.map((m) => {
        if (m.type === 'do_devotional' && !m.completed) {
          return { ...m, progress: 1, completed: true };
        }
        return m;
      })
    );
  };

  // Record Quiz Result
  const recordQuizResult = (correctCount: number, totalQuestions: number, xpEarned: number) => {
    setUser((prev) => {
      const updated = {
        ...prev,
        questionsAnsweredCount: prev.questionsAnsweredCount + totalQuestions,
        correctAnswersCount: prev.correctAnswersCount + correctCount,
      };
      checkAchievements(updated);
      return updated;
    });

    if (xpEarned > 0) {
      addXp(xpEarned, `Desafio Bíblico concluído com ${correctCount} acertos!`);
    }

    setDailyMissions((prev) =>
      prev.map((m) => {
        if (m.type === 'do_quiz') {
          const newProg = Math.min(m.maxProgress, m.progress + correctCount);
          const completed = newProg >= m.maxProgress;
          return { ...m, progress: newProg, completed };
        }
        return m;
      })
    );
  };

  // Toggle Favorite
  const toggleFavorite = (bookId: string, bookName: string, chapter: number, verse: number, text: string) => {
    setFavorites((prev) => {
      const exists = prev.find((f) => f.bookId === bookId && f.chapter === chapter && f.verse === verse);
      if (exists) {
        showToast('Favorito removido', `${bookName} ${chapter}:${verse}`, 'info');
        return prev.filter((f) => f.id !== exists.id);
      } else {
        playSoundEffect('success');
        showToast('Salvo em Favoritos ❤️', `${bookName} ${chapter}:${verse}`, 'info');
        return [
          ...prev,
          {
            id: `fav-${Date.now()}`,
            bookId,
            bookName,
            chapter,
            verse,
            text,
            date: new Date().toISOString().split('T')[0],
          }
        ];
      }
    });
  };

  // Add & Remove Highlights
  const addHighlight = (bookId: string, chapter: number, verse: number, color: 'amber' | 'emerald' | 'sky' | 'rose', text: string) => {
    setHighlights((prev) => {
      const filtered = prev.filter((h) => !(h.bookId === bookId && h.chapter === chapter && h.verse === verse));
      showToast('Versículo destacado ✨', `Destaque aplicado com sucesso`, 'info');
      return [
        ...filtered,
        {
          id: `hl-${Date.now()}`,
          bookId,
          chapter,
          verse,
          color,
          date: new Date().toISOString().split('T')[0],
          text,
        }
      ];
    });
  };

  const removeHighlight = (id: string) => {
    setHighlights((prev) => prev.filter((h) => h.id !== id));
  };

  // Reading Plans
  const togglePlanDay = (planId: string, dayNumber: number) => {
    setReadingPlans((prev) =>
      prev.map((plan) => {
        if (plan.id !== planId) return plan;
        let newlyCompletedPlan = false;
        const updatedDays = plan.days.map((d) => {
          if (d.day === dayNumber) {
            const willComplete = !d.completed;
            if (willComplete) {
              addXp(25, `Dia ${dayNumber} do plano "${plan.title}" concluído! (+25 XP)`);
            }
            return { ...d, completed: willComplete };
          }
          return d;
        });

        const allDone = updatedDays.every((d) => d.completed);
        if (allDone && !plan.days.every((d) => d.completed)) {
          newlyCompletedPlan = true;
        }

        if (newlyCompletedPlan) {
          addXp(500, `🏆 Plano completo: "${plan.title}"! (+500 XP)`);
          setUser((u) => {
            const updated = { ...u, plansCompletedCount: u.plansCompletedCount + 1 };
            checkAchievements(updated);
            return updated;
          });
        }

        return { ...plan, days: updatedDays };
      })
    );
  };

  // Journey milestones
  const completeMilestone = (milestoneId: string) => {
    setJourneyMilestones((prev) =>
      prev.map((m) => {
        if (m.id === milestoneId) {
          if (!m.completed) {
            addXp(250, `Marco concluído: "${m.title}"! (+250 XP)`);
            showToast('🔓 Nova etapa desbloqueada!', `Você avançou na grande Jornada Bíblica!`, 'badge');
          }
          return { ...m, completed: true };
        }
        return m;
      })
    );
  };

  // Admin and management actions
  const addQuizQuestion = (q: QuizQuestion) => {
    setQuizQuestions((prev) => [q, ...prev]);
    showToast('Nova pergunta adicionada', q.question, 'info');
  };

  const addCharacter = (c: BiblicalCharacter) => {
    setBiblicalCharacters((prev) => [c, ...prev]);
    showToast('Novo personagem adicionado', c.name, 'info');
  };

  const togglePremiumSubscription = () => {
    setUser((prev) => {
      const willBePremium = !prev.isPremium;
      showToast(
        willBePremium ? '👑 Plano Premium Ativado!' : 'Plano Gratuito',
        willBePremium ? 'Acesso ilimitado à IA Bíblica, todos os planos e personagens liberados!' : 'Voltou ao modo padrão.',
        'badge'
      );
      return { ...prev, isPremium: willBePremium };
    });
  };

  const updateUserGoal = (goal: string) => {
    setUser((prev) => ({ ...prev, goal }));
    showToast('Objetivo atualizado!', 'Sua experiência foi personalizada.', 'info');
  };

  const loginUser = (email: string, name: string) => {
    setUser((prev) => ({
      ...prev,
      email,
      name: name || 'Peregrino da Fé',
    }));
    showToast(`Bem-vindo, ${name || 'irmão'}! 👋`, 'Sua jornada bíblica foi conectada.', 'info');
  };

  const logoutUser = () => {
    setUser(DEFAULT_USER);
    showToast('Sessão encerrada', 'Você está navegando como visitante.', 'info');
  };

  const resetAllProgress = () => {
    setUser(DEFAULT_USER);
    setFavorites([]);
    setHighlights([]);
    setReadingPlans(READING_PLANS);
    setJourneyMilestones(JOURNEY_MILESTONES);
    setDailyMissions(DEFAULT_DAILY_MISSIONS);
    setAchievements(INITIAL_ACHIEVEMENTS);
    localStorage.clear();
    showToast('Dados restaurados', 'O aplicativo foi reiniciado para os valores padrão.', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        user,
        activeTab,
        setActiveTab,
        currentBookId,
        currentChapter,
        openChapter,
        addXp,
        markChapterAsRead,
        completeDevotional,
        recordQuizResult,
        favorites,
        toggleFavorite,
        highlights,
        addHighlight,
        removeHighlight,
        readingPlans,
        togglePlanDay,
        journeyMilestones,
        completeMilestone,
        biblicalCharacters,
        quizQuestions,
        achievements,
        dailyMissions,
        isDevotionalOpen,
        setIsDevotionalOpen,
        isCharactersOpen,
        setIsCharactersOpen,
        selectedCharacter,
        setSelectedCharacter,
        isAiBibleOpen,
        setIsAiBibleOpen,
        isPlansOpen,
        setIsPlansOpen,
        selectedPlan,
        setSelectedPlan,
        isPremiumOpen,
        setIsPremiumOpen,
        isAdminOpen,
        setIsAdminOpen,
        isOnboardingOpen,
        setIsOnboardingOpen,
        isAuthOpen,
        setIsAuthOpen,
        isExportOpen,
        setIsExportOpen,
        toasts,
        dismissToast,
        showToast,
        addQuizQuestion,
        addCharacter,
        togglePremiumSubscription,
        updateUserGoal,
        loginUser,
        logoutUser,
        resetAllProgress,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
