import { Achievement } from '../types';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first-chapter',
    title: 'Primeiro Capítulo',
    description: 'Completou a leitura do seu primeiro capítulo bíblico.',
    icon: '🏆',
    requiredMetric: 'chaptersRead',
    threshold: 1,
    unlockedAt: '2026-09-20'
  },
  {
    id: 'streak-7',
    title: '7 Dias Consecutivos',
    description: 'Manteve a chama acesa durante uma semana completa.',
    icon: '🔥',
    requiredMetric: 'streakDays',
    threshold: 7,
    unlockedAt: '2026-09-26'
  },
  {
    id: 'streak-30',
    title: '30 Dias Consecutivos',
    description: 'Um mês ininterrupto em comunhão e estudo diário.',
    icon: '⚡',
    requiredMetric: 'streakDays',
    threshold: 30
  },
  {
    id: 'chapters-10',
    title: '10 Capítulos Lidos',
    description: 'Aprofundou o conhecimento com dez leituras bíblicas.',
    icon: '📖',
    requiredMetric: 'chaptersRead',
    threshold: 10,
    unlockedAt: '2026-09-24'
  },
  {
    id: 'chapters-100',
    title: '100 Capítulos Lidos',
    description: 'Centena sagrada: dedicação exemplar às Escrituras.',
    icon: '📚',
    requiredMetric: 'chaptersRead',
    threshold: 100
  },
  {
    id: 'quiz-50',
    title: '50 Perguntas Respondidas',
    description: 'Colocou à prova seus conhecimentos bíblicos cinquenta vezes.',
    icon: '🎯',
    requiredMetric: 'questionsAnswered',
    threshold: 50,
    unlockedAt: '2026-09-25'
  },
  {
    id: 'quiz-100-correct',
    title: '100 Respostas Corretas',
    description: 'Mente aguçada na Palavra com 100 acertos no desafio.',
    icon: '🧠',
    requiredMetric: 'correctAnswers',
    threshold: 100
  },
  {
    id: 'gospels-complete',
    title: 'Evangelhos Concluídos',
    description: 'Completou o estudo dos quatro Evangelhos de Cristo.',
    icon: '✝️',
    requiredMetric: 'plansCompleted',
    threshold: 1
  },
  {
    id: 'bible-master',
    title: 'Mestre da Bíblia',
    description: 'Alcançou o nível supremo de dedicação e sabedoria.',
    icon: '🏅',
    requiredMetric: 'totalXp',
    threshold: 3500
  }
];
