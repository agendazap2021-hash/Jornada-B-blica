import { MoodEntry } from '../types';

export const MOOD_ENTRIES: MoodEntry[] = [
  {
    id: 'peace',
    label: 'Estou em paz',
    emoji: '😌',
    verse: {
      reference: 'Filipenses 4:7',
      text: 'E a paz de Deus, que excede todo o entendimento, guardará o vosso coração e a vossa mente em Cristo Jesus.'
    },
    reflection: 'A verdadeira paz bíblica não é apenas a ausência de tempestades externas, mas a certeza inabalável da presença de Cristo em nosso barco. Cultive este momento de serenidade expressando gratidão e compartilhando bondade com quem cruzar seu caminho.',
    prayer: 'Senhor Deus, agradeço profundamente pela serenidade que inunda minha alma hoje. Que Tua doce paz continue guardando meus pensamentos e sentimentos em Cristo Jesus, e que eu seja um instrumento de reconciliação e calma para o meu próximo. Amém.'
  },
  {
    id: 'sad',
    label: 'Estou triste',
    emoji: '😔',
    verse: {
      reference: 'Salmos 34:18',
      text: 'Perto está o SENHOR dos que têm o coração quebrantado e salva os de espírito oprimido.'
    },
    reflection: 'Você não precisa esconder sua vulnerabilidade de Deus. Ele não rejeita lágrimas sinceras; pelo contrário, acolhe cada uma delas com infinita ternura. Permita que a presença consoladora do Senhor envolva sua dor hoje com esperança renovada.',
    prayer: 'Pai de amor e misericórdia, hoje meu coração se sente pesaroso e cansado. Coloco diante de Ti a minha dor, sabendo que estás bem perto de mim. Derrama Teu consolo divino sobre a minha alma e lembra-me de que o choro pode durar uma noite, mas a alegria vem pela manhã. Amém.'
  },
  {
    id: 'worried',
    label: 'Estou preocupado',
    emoji: '😰',
    verse: {
      reference: '1 Pedro 5:7',
      text: 'Lançando sobre ele toda a vossa ansiedade, porque ele tem cuidado de vós.'
    },
    reflection: 'A preocupação tenta nos fazer carregar o peso do amanhã antes do tempo. Quando você entrega conscientemente suas incertezas nas mãos daquele que sustenta o universo, o fardo se torna leve e o coração encontra descanso seguro.',
    prayer: 'Querido Deus, entrego em Tuas mãos tudo aquilo que tem roubado a minha tranquilidade: meus planos, meus receios e aquilo que não posso controlar. Ajuda-me a confiar no Teu cuidado paterno e descansa meu espírito na certeza de que Tu és fiel. Em nome de Jesus, amém.'
  },
  {
    id: 'strength',
    label: 'Preciso de força',
    emoji: '🙏',
    verse: {
      reference: 'Isaías 40:29',
      text: 'Faz forte ao cansado e multiplica as forças ao que não tem nenhum vigor.'
    },
    reflection: 'Quando nossas energias naturais se esgotam, é exatamente aí que o poder de Deus se aperfeiçoa em nossa fraqueza. Você não precisa enfrentar esta batalha com seus próprios recursos; há uma fonte inesgotável de graça disponível agora mesmo.',
    prayer: 'Senhor Todo-Poderoso, reconheço meus limites e sinto minhas energias se esvaindo. Rogo que renove o meu vigor físico, emocional e espiritual. Concede-me a Tua força sobrenatural para continuar caminhando com coragem e fé. Amém.'
  },
  {
    id: 'grateful',
    label: 'Quero agradecer',
    emoji: '❤️',
    verse: {
      reference: 'Salmos 103:1-2',
      text: 'Bendize, ó minha alma, ao SENHOR, e tudo o que há em mim bendiga ao seu santo nome. Bendize, ó minha alma, ao SENHOR, e não te esqueças de nem um só de seus benefícios.'
    },
    reflection: 'A gratidão transforma o que temos em suficiência e abre nossos olhos para enxergar as pequenas maravilhas diárias da providência divina. Celebrar as bênçãos recebidas fortalece a fé para os novos horizontes que virão.',
    prayer: 'Senhor, hoje meu coração transborda de alegria e gratidão. Obrigado pela dádiva da vida, pelo pão de cada dia, pela família e pelas bênçãos visíveis e invisíveis que Tu derramas generosamente sobre os meus caminhos. Toda glória pertence a Ti! Amém.'
  },
  {
    id: 'afraid',
    label: 'Estou com medo',
    emoji: '😟',
    verse: {
      reference: 'Salmos 56:3',
      text: 'Em me vindo o temor, hei de confiar em ti.'
    },
    reflection: 'O medo é uma reação humana natural diante do desconhecido, mas a fé é a decisão sagrada de olhar para a grandeza de Deus em vez de focar no tamanho da tempestade. Lembre-se: Aquele que guarda você jamais dorme.',
    prayer: 'Pai celeste, quando o medo ameaça paralisar meus passos, decido firmar meus olhos na Tua verdade. Afasta de mim todo espírito de temor e enche-me do Teu perfeito amor que dissipa toda a aflição. Tu és meu escudo e fortaleza. Amém.'
  },
  {
    id: 'direction',
    label: 'Preciso de direção',
    emoji: '🎯',
    verse: {
      reference: 'Provérbios 3:5-6',
      text: 'Confia no SENHOR de todo o teu coração e não te estribes no teu próprio entendimento. Reconhece-o em todos os teus caminhos, e ele endireitará as tuas veredas.'
    },
    reflection: 'Tomar decisões importantes pode parecer assustador, mas você não está navegando no escuro. A Palavra de Deus é lâmpada para os seus pés. Quando você busca sinceramente o conselho divino antes de agir, os passos certos se tornam claros.',
    prayer: 'Senhor Deus da sabedoria, coloco meus caminhos e decisões diante do Teu altar. Não quero seguir apenas a minha própria intuição; peço clareza, prudência e discernimento pelo Teu Santo Espírito. Guia meus passos pelo caminho da justiça e da paz. Amém.'
  }
];
