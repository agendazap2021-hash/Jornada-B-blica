import { JourneyMilestone } from '../types';

export const JOURNEY_MILESTONES: JourneyMilestone[] = [
  {
    id: 'm1-comeco',
    order: 1,
    title: 'O Começo de Tudo',
    subtitle: 'A Criação e o Éden',
    icon: '🌱',
    epoch: 'Criação e Origens',
    story: 'No princípio, Deus falou e o universo passou a existir. Das trevas fez-se luz, os mares foram contidos e o homem foi formado à Sua imagem e semelhança.',
    recommendedChapters: [
      { bookId: 'gn', bookName: 'Gênesis', chapter: 1, label: 'A Criação do Mundo' },
      { bookId: 'gn', bookName: 'Gênesis', chapter: 2, label: 'O Jardim do Éden' }
    ],
    keyCharacters: ['Adão', 'Eva', 'Noé'],
    quizCategory: 'Antigo Testamento',
    requiredXp: 0,
    completed: true
  },
  {
    id: 'm2-genesis',
    order: 2,
    title: 'Os Patriarcas e a Promessa',
    subtitle: 'Abraão, Isaque e Jacó',
    icon: '📖',
    epoch: 'Era Patriarcal',
    story: 'Deus chama Abraão para uma aliança perpétua: uma descendência tão numerosa quanto as estrelas dos céus. A bênção segue através de Isaque e Jacó.',
    recommendedChapters: [
      { bookId: 'gn', bookName: 'Gênesis', chapter: 12, label: 'O Chamado de Abraão' },
      { bookId: 'gn', bookName: 'Gênesis', chapter: 37, label: 'A História de José' }
    ],
    keyCharacters: ['Abraão', 'Sara', 'José do Egito'],
    quizCategory: 'Personagens',
    requiredXp: 150,
    completed: true
  },
  {
    id: 'm3-exodo',
    order: 3,
    title: 'A Libertação do Povo',
    subtitle: 'Êxodo e a Aliança do Sinai',
    icon: '🔥',
    epoch: 'Libertação e Deserto',
    story: 'O clamor dos escravos no Egito sobe a Deus. Com mão forte e braço estendido, o Senhor abre o Mar Vermelho e entrega a Lei moral no Monte Sinai.',
    recommendedChapters: [
      { bookId: 'ex', bookName: 'Êxodo', chapter: 14, label: 'A Passagem do Mar Vermelho' },
      { bookId: 'ex', bookName: 'Êxodo', chapter: 20, label: 'Os Dez Mandamentos' }
    ],
    keyCharacters: ['Moisés', 'Arão', 'Miriã'],
    quizCategory: 'Antigo Testamento',
    requiredXp: 350,
    completed: false
  },
  {
    id: 'm4-reis',
    order: 4,
    title: 'A Glória da Monarquia',
    subtitle: 'Davi, Salomão e os Salmos',
    icon: '👑',
    epoch: 'Reino Unido de Israel',
    story: 'Israel clama por um rei. Davi unifica as doze tribos, vence gigantes, traz a Arca a Jerusalém e compõe cânticos eternos. Salomão ergue o Templo sagrado.',
    recommendedChapters: [
      { bookId: '1sm', bookName: '1 Samuel', chapter: 17, label: 'Davi e Golias' },
      { bookId: 'sl', bookName: 'Salmos', chapter: 23, label: 'O Bom Pastor' }
    ],
    keyCharacters: ['Davi', 'Salomão', 'Samuel'],
    quizCategory: 'História bíblica',
    requiredXp: 600,
    completed: false
  },
  {
    id: 'm5-profetas',
    order: 5,
    title: 'A Voz dos Profetas',
    subtitle: 'Esperança no Exílio e Promessa do Messias',
    icon: '🕊️',
    epoch: 'Tempo dos Profetas',
    story: 'Homens corajosos clamam por retidão e justiça. Em meio à dor do exílio babilônico, Isaías, Jeremias e Daniel vislumbram o Messias vindouro.',
    recommendedChapters: [
      { bookId: 'is', bookName: 'Isaías', chapter: 40, label: 'Consolo e Renovo' },
      { bookId: 'is', bookName: 'Isaías', chapter: 53, label: 'O Servo Sofredor' }
    ],
    keyCharacters: ['Elias', 'Isaías', 'Daniel'],
    quizCategory: 'Profetas',
    requiredXp: 900,
    completed: false
  },
  {
    id: 'm6-evangelhos',
    order: 6,
    title: 'O Verbo se Fez Carne',
    subtitle: 'A Vida e Ressurreição de Jesus',
    icon: '✝️',
    epoch: 'O Ministério de Cristo',
    story: 'A plenitude dos tempos chegou! Deus enviou Seu Filho unigênito. Jesus ensina o amor ao próximo, cura enfermos e dá a Sua vida na cruz, ressuscitando ao terceiro dia.',
    recommendedChapters: [
      { bookId: 'mt', bookName: 'Mateus', chapter: 5, label: 'O Sermão da Montanha' },
      { bookId: 'joao', bookName: 'João', chapter: 3, label: 'O Amor de Deus e a Vida Eterna' }
    ],
    keyCharacters: ['Jesus Cristo', 'Maria', 'João Batista'],
    quizCategory: 'Jesus',
    requiredXp: 1300,
    completed: false
  },
  {
    id: 'm7-atos',
    order: 7,
    title: 'O Fogo do Pentecostes',
    subtitle: 'O Nascimento e a Expansão da Igreja',
    icon: '⚡',
    epoch: 'Igreja Primitiva',
    story: 'O Espírito Santo desce com poder. Os apóstolos proclamam o Evangelho com ousadia em Jerusalém, Judeia, Samaria e até os confins da terra.',
    recommendedChapters: [
      { bookId: 'at', bookName: 'Atos dos Apóstolos', chapter: 2, label: 'O Dia de Pentecostes' },
      { bookId: 'at', bookName: 'Atos dos Apóstolos', chapter: 9, label: 'A Conversão de Saulo' }
    ],
    keyCharacters: ['Pedro', 'Estêvão', 'Filipe'],
    quizCategory: 'Novo Testamento',
    requiredXp: 1800,
    completed: false
  },
  {
    id: 'm8-cartas',
    order: 8,
    title: 'A Fé em Prática',
    subtitle: 'As Epístolas Apostólicas',
    icon: '📜',
    epoch: 'Doutrina e Vida Cristã',
    story: 'Paulo, Pedro, João e Tiago escrevem cartas preciosas orientando as igrejas sobre graça, santidade, unidade e a supremacia do amor fraterno.',
    recommendedChapters: [
      { bookId: 'rm', bookName: 'Romanos', chapter: 8, label: 'Mais que Vencedores' },
      { bookId: '1co', bookName: '1 Coríntios', chapter: 13, label: 'O Hino do Amor' }
    ],
    keyCharacters: ['Paulo de Tarso', 'Tiago', 'Timóteo'],
    quizCategory: 'Versículos',
    requiredXp: 2400,
    completed: false
  },
  {
    id: 'm9-apocalipse',
    order: 9,
    title: 'O Triunfo Eterno',
    subtitle: 'Novos Céus e Nova Terra',
    icon: '🌅',
    epoch: 'A Vitória Final de Deus',
    story: 'A revelação do Cristo glorificado. O mal é derrotado para todo o sempre, a morte é tragada pela vitória e Deus habita para sempre com o Seu povo.',
    recommendedChapters: [
      { bookId: 'ap', bookName: 'Apocalipse', chapter: 21, label: 'A Nova Jerusalém' },
      { bookId: 'ap', bookName: 'Apocalipse', chapter: 22, label: 'O Rio da Vida' }
    ],
    keyCharacters: ['João', 'Jesus Cristo'],
    quizCategory: 'História bíblica',
    requiredXp: 3200,
    completed: false
  }
];
