import { QuizQuestion } from '../types';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // Personagens
  {
    id: 'q-noe',
    question: 'Quem construiu a arca por instrução de Deus para salvar sua família do dilúvio?',
    options: ['Moisés', 'Noé', 'Davi', 'Abraão'],
    correctIndex: 1,
    explanation: 'Deus instruiu Noé a construir uma arca de madeira de gofer para abrigar sua família e os animais durante o Dilúvio.',
    reference: 'Gênesis 6:14',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-moises',
    question: 'Qual personagem bíblico liderou o povo de Israel na saída do Egito e abriu o Mar Vermelho?',
    options: ['Josué', 'Arão', 'Moisés', 'Gideão'],
    correctIndex: 2,
    explanation: 'Moisés foi escolhido por Deus para libertar os hebreus do cativeiro no Egito e conduzi-los pelo deserto.',
    reference: 'Êxodo 14:21',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-davi-golias',
    question: 'Qual jovem pastor derrotou o gigante filisteu Golias usando apenas uma funda e uma pedra?',
    options: ['Davi', 'Saul', 'Salomão', 'Jônatas'],
    correctIndex: 0,
    explanation: 'Davi, filho de Jessé, confiou no nome do SENHOR dos Exércitos para derrubar Golias com uma pedrada na testa.',
    reference: '1 Samuel 17:49',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-abraao',
    question: 'Quem é conhecido nas Escrituras como o "Pai da Fé" e "Amigo de Deus"?',
    options: ['Isaque', 'Jacó', 'Abraão', 'Melquisedeque'],
    correctIndex: 2,
    explanation: 'Abraão creu no Senhor, e isso lhe foi imputado como justiça, sendo chamado de amigo de Deus.',
    reference: 'Tiago 2:23 / Gênesis 15:6',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-jose-egito',
    question: 'Qual filho de Jacó recebeu uma túnica de várias cores e foi vendido pelos irmãos ao Egito?',
    options: ['Benjamim', 'Ruben', 'Judá', 'José'],
    correctIndex: 3,
    explanation: 'José foi vendido aos ismaelitas por ciúmes de seus irmãos, tornando-se mais tarde governador do Egito.',
    reference: 'Gênesis 37:3',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-sansao',
    question: 'De onde vinha o voto de consagração e a extraordinária força física de Sansão?',
    options: ['Da sua espada mágica', 'De sua dieta vegetal', 'Do voto de nazireu e cabelo não cortado', 'De sua armadura de bronze'],
    correctIndex: 2,
    explanation: 'Sansão era consagrado a Deus como nazireu desde o ventre materno; o cabelo intocado era a marca desse voto.',
    reference: 'Juízes 13:5',
    category: 'Personagens',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-ester-purim',
    question: 'Qual rainha judia disse a célebre frase "se perecer, pereci" para interceder por seu povo?',
    options: ['Vasti', 'Ester', 'Rute', 'Atalia'],
    correctIndex: 1,
    explanation: 'A rainha Ester arriscou a própria vida comparecendo sem convocação perante o rei Assuero para salvar os judeus.',
    reference: 'Ester 4:16',
    category: 'Personagens',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-salomao-sabedoria',
    question: 'O que o jovem rei Salomão pediu a Deus em oração quando assumiu o trono de Israel?',
    options: ['Riquezas sem fim', 'Vida longa', 'Coração compreensivo e sabedoria', 'A morte de seus inimigos'],
    correctIndex: 2,
    explanation: 'Salomão pediu a Deus sabedoria e discernimento para governar retamente o povo de Deus em Gibeão.',
    reference: '1 Reis 3:9',
    category: 'Personagens',
    difficulty: 'Fácil',
    xpReward: 100
  },

  // Jesus
  {
    id: 'q-jesus-nascimento',
    question: 'Em qual cidade Jesus nasceu, cumprindo a profecia de Miquéias?',
    options: ['Nazaré', 'Jerusalém', 'Belém da Judeia', 'Cafarnaum'],
    correctIndex: 2,
    explanation: 'Jesus nasceu em Belém da Judeia nos dias do rei Herodes, conforme predito em Miquéias 5:2.',
    reference: 'Mateus 2:1',
    category: 'Jesus',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-jesus-primeiro-milagre',
    question: 'Qual foi o primeiro milagre público realizado por Jesus segundo o Evangelho de João?',
    options: ['Cura do cego de Jericó', 'Transformar água em vinho nas bodas de Caná', 'Multiplicação dos pães', 'Ressurreição de Lázaro'],
    correctIndex: 1,
    explanation: 'Nas bodas de Caná da Galileia, Jesus transformou cerca de 600 litros de água em vinho excelente.',
    reference: 'João 2:11',
    category: 'Jesus',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-jesus-tentacao',
    question: 'Quantos dias Jesus jejuou no deserto antes de ser tentado pelo diabo?',
    options: ['7 dias', '14 dias', '40 dias e 40 noites', '100 dias'],
    correctIndex: 2,
    explanation: 'Jesus jejuou quarenta dias e quarenta noites no deserto da Judeia, após o que teve fome.',
    reference: 'Mateus 4:2',
    category: 'Jesus',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-jesus-lazaro',
    question: 'Por quantos dias Lázaro já estava no sepulcro quando Jesus o ressuscitou?',
    options: ['1 dia', '2 dias', '4 dias', '7 dias'],
    correctIndex: 2,
    explanation: 'Marta advertiu a Jesus que Lázaro já cheirava mal por estar morto havia quatro dias no sepulcro.',
    reference: 'João 11:39',
    category: 'Jesus',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-jesus-frase-cruz',
    question: 'Qual foi o significado do brado "Tetelestai" ("Está consumado!") proclamado por Jesus na cruz?',
    options: ['A desistência da missão', 'O pagamento integral e vitória da redenção', 'Um pedido de socorro', 'O fim do povo de Israel'],
    correctIndex: 1,
    explanation: 'Tetelestai era um termo comercial grego que significava "totalmente pago, dívida quitada", marcando a redenção eterna.',
    reference: 'João 19:30',
    category: 'Jesus',
    difficulty: 'Difícil',
    xpReward: 100
  },

  // Antigo Testamento
  {
    id: 'q-at-livros-total',
    question: 'Quantos livros compõem o Antigo Testamento no cânon protestante adotado comumente?',
    options: ['27 livros', '39 livros', '66 livros', '73 livros'],
    correctIndex: 1,
    explanation: 'O Antigo Testamento contém 39 livros (de Gênesis a Malaquias). Com os 27 do NT, somam-se 66 livros bíblicos.',
    reference: 'Cânon Bíblico',
    category: 'Antigo Testamento',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-at-primeiro-mandamento',
    question: 'Qual é o primeiro dos Dez Mandamentos entregues por Deus a Moisés no Sinai?',
    options: ['Honra teu pai e tua mãe', 'Não furtarás', 'Não terás outros deuses diante de mim', 'Não matarás'],
    correctIndex: 2,
    explanation: 'O primeiro mandamento afirma a exclusividade divina: "Não terás outros deuses diante de mim".',
    reference: 'Êxodo 20:3',
    category: 'Antigo Testamento',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-at-jerico-queda',
    question: 'Quantas vezes o exército de Israel marchou ao redor de Jericó no sétimo dia antes da queda das muralhas?',
    options: ['1 vez', '3 vezes', '7 vezes', '12 vezes'],
    correctIndex: 2,
    explanation: 'No sétimo dia deram sete voltas à cidade de Jericó. Ao toque prolongado das trombetas e ao clamor do povo, as muralhas ruíram.',
    reference: 'Josué 6:4',
    category: 'Antigo Testamento',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-at-homem-mais-velho',
    question: 'Quem foi o homem que mais tempo viveu registrado na Bíblia, falecendo aos 969 anos?',
    options: ['Adão', 'Matusalém', 'Noé', 'Jared'],
    correctIndex: 1,
    explanation: 'Matusalém, filho de Enoque e avô de Noé, viveu 969 anos.',
    reference: 'Gênesis 5:27',
    category: 'Antigo Testamento',
    difficulty: 'Médio',
    xpReward: 100
  },

  // Novo Testamento
  {
    id: 'q-nt-pentecostes',
    question: 'Em que dia o Espírito Santo desceu como línguas de fogo sobre os apóstolos reunidos no cenáculo?',
    options: ['Dia da Páscoa', 'Dia do Pentecostes', 'Festa dos Tabernáculos', 'Dia da Expiação'],
    correctIndex: 1,
    explanation: 'No Dia do Pentecostes, os discípulos cheios do Espírito começaram a falar em outras línguas conforme Ele lhes concedia.',
    reference: 'Atos 2:1-4',
    category: 'Novo Testamento',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-nt-estrada-damasco',
    question: 'Qual apóstolo se converteu a caminho de Damasco após ver uma luz resplandecente do céu?',
    options: ['Pedro', 'Paulo (Saulo)', 'Barnabé', 'Estêvão'],
    correctIndex: 1,
    explanation: 'Saulo de Tarso perseguia a Igreja quando foi confrontado por Jesus: "Saulo, Saulo, por que me persegues?".',
    reference: 'Atos 9:3-4',
    category: 'Novo Testamento',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-nt-fruto-espirito',
    question: 'Em qual epístola de Paulo encontramos a lista dos frutos do Espírito ("amor, alegria, paz, longanimidade...")?',
    options: ['Romanos', 'Gálatas', 'Efésios', 'Colossenses'],
    correctIndex: 1,
    explanation: 'Em Gálatas 5:22-23 Paulo descreve o fruto do Espírito contraposto às obras da carne.',
    reference: 'Gálatas 5:22',
    category: 'Novo Testamento',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-nt-autor-apocalipse',
    question: 'Quem escreveu o livro do Apocalipse enquanto estava exilado na ilha de Patmos?',
    options: ['Apóstolo Paulo', 'Apóstolo Pedro', 'Apóstolo João', 'Lucas'],
    correctIndex: 2,
    explanation: 'O apóstolo João recebeu as visões da Revelação de Jesus Cristo exilado na ilha de Patmos por amor ao Evangelho.',
    reference: 'Apocalipse 1:9',
    category: 'Novo Testamento',
    difficulty: 'Fácil',
    xpReward: 100
  },

  // Profetas
  {
    id: 'q-profetas-boca-peixe',
    question: 'Qual profeta tentou fugir para Társis de navio e foi engolido por um grande peixe após desobedecer a Deus?',
    options: ['Jeremias', 'Jonas', 'Amós', 'Habacuque'],
    correctIndex: 1,
    explanation: 'Jonas recusou-se inicialmente a pregar arrependimento aos assírios de Nínive e foi engolido por um grande peixe.',
    reference: 'Jonas 1:17',
    category: 'Profetas',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-profetas-cova-leoes',
    question: 'Por que o profeta Daniel foi lançado na cova dos leões pelo rei Dario?',
    options: ['Por roubar o tesouro real', 'Por continuar orando ao Deus de Israel três vezes ao dia', 'Por destruir um ídolo pagão', 'Por liderar uma rebelião armada'],
    correctIndex: 1,
    explanation: 'Daniel desobedeceu ao decreto real de não orar a outro deus senão ao rei e manteve suas três orações diárias.',
    reference: 'Daniel 6:10-16',
    category: 'Profetas',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-profetas-carmelo',
    question: 'No Monte Carmelo, contra quantos profetas de Baal o profeta Elias disputou a descida do fogo divino?',
    options: ['50 profetas', '100 profetas', '450 profetas', '1.000 profetas'],
    correctIndex: 2,
    explanation: 'Elias confrontou sozinho os 450 profetas de Baal sustentados por Jezabel no altar do Senhor.',
    reference: '1 Reis 18:22',
    category: 'Profetas',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-profetas-ossos-secos',
    question: 'Qual profeta teve a impressionante visão de um vale repleto de ossos secos que voltaram a viver pelo Espírito?',
    options: ['Isaías', 'Jeremias', 'Ezequiel', 'Daniel'],
    correctIndex: 2,
    explanation: 'Ezequiel profetizou aos quatro ventos sobre o vale de ossos secos, simbolizando a restauração de Israel.',
    reference: 'Ezequiel 37:1-10',
    category: 'Profetas',
    difficulty: 'Médio',
    xpReward: 100
  },

  // Evangelhos
  {
    id: 'q-evangelhos-quantos',
    question: 'Quantos e quais são os Evangelhos sinóticos da Bíblia?',
    options: ['Dois: Mateus e Lucas', 'Três: Mateus, Marcos e Lucas', 'Quatro: Mateus, Marcos, Lucas e João', 'Nenhum deles'],
    correctIndex: 1,
    explanation: 'Mateus, Marcos e Lucas são chamados "sinóticos" ("mesmo olhar/ponto de vista") pela estrutura narrativa semelhante, enquanto João é teologicamente singular.',
    reference: 'Introdução Bíblica',
    category: 'Evangelhos',
    difficulty: 'Difícil',
    xpReward: 100
  },
  {
    id: 'q-evangelhos-samaritano',
    question: 'Na parábola do Bom Samaritano, quem foram os dois religiosos que passaram de largo pelo homem ferido?',
    options: ['Um fariseu e um escriba', 'Um sacerdote e um levita', 'Um pescador e um cobrador de impostos', 'Um centurião e um rabino'],
    correctIndex: 1,
    explanation: 'Tanto o sacerdote quanto o levita viram a vítima ensanguentada na estrada de Jericó e passaram pelo lado oposto.',
    reference: 'Lucas 10:31-32',
    category: 'Evangelhos',
    difficulty: 'Médio',
    xpReward: 100
  },
  {
    id: 'q-evangelhos-bem-aventurados',
    question: 'Onde Jesus proferiu o célebre sermão das Bem-Aventuranças ("Bem-aventurados os humildes de espírito...")?',
    options: ['No Templo de Jerusalém', 'No Monte das Oliveiras', 'No Sermão do Monte (na Galileia)', 'Em alto mar num barco'],
    correctIndex: 2,
    explanation: 'Jesus subiu a uma encosta perto de Cafarnaum e ensinou os Seus discípulos no Sermão do Monte.',
    reference: 'Mateus 5:1',
    category: 'Evangelhos',
    difficulty: 'Fácil',
    xpReward: 100
  },

  // Versículos
  {
    id: 'q-versiculos-joao316',
    question: 'Complete o versículo: "Porque Deus amou ao mundo de tal maneira que deu o seu Filho unigênito, para que todo o que nele crê..."',
    options: ['seja rico e próspero', 'não pereça, mas tenha a vida eterna', 'conquiste as nações', 'nunca passe por aflições'],
    correctIndex: 1,
    explanation: 'João 3:16 é um dos versículos mais conhecidos da Bíblia, expressando o centro da mensagem do Evangelho.',
    reference: 'João 3:16',
    category: 'Versículos',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-versiculos-salmo23',
    question: 'Qual é o início do consagrado Salmo 23 escrito por Davi?',
    options: ['O SENHOR é a minha luz e a minha salvação', 'O SENHOR é o meu pastor; nada me faltará', 'Aquele que habita no esconderijo do Altíssimo', 'Elevo os olhos para os montes'],
    correctIndex: 1,
    explanation: 'O Salmo 23 abre com a afirmação confiante: "O SENHOR é o meu pastor; nada me faltará".',
    reference: 'Salmos 23:1',
    category: 'Versículos',
    difficulty: 'Fácil',
    xpReward: 100
  },
  {
    id: 'q-versiculos-lampada',
    question: 'De acordo com o Salmo 119:105, o que a Palavra de Deus é para os nossos pés e caminho?',
    options: ['Uma bússola e um mapa', 'Lâmpada para os pés e luz para o caminho', 'Um escudo e uma espada afiada', 'Um bálsamo suave'],
    correctIndex: 1,
    explanation: 'Salmos 119:105 declara: "Lâmpada para os meus pés é a tua palavra e luz, para o meu caminho".',
    reference: 'Salmos 119:105',
    category: 'Versículos',
    difficulty: 'Fácil',
    xpReward: 100
  },

  // História Bíblica
  {
    id: 'q-historia-arca-alianca',
    question: 'O que havia guardado dentro da Arca da Aliança segundo a carta aos Hebreus?',
    options: ['Apenas ouro e prata', 'As Tábuas da Lei, a vara de Arão florescida e um vaso de maná', 'O manto de Moisés e cinzas do altar', 'As trombetas de prata de Jericó'],
    correctIndex: 1,
    explanation: 'A Arca da Aliança continha a urna de ouro com o maná, a vara florescida de Arão e as tábuas dos mandamentos.',
    reference: 'Hebreus 9:4',
    category: 'História bíblica',
    difficulty: 'Mestre',
    xpReward: 100
  },
  {
    id: 'q-historia-divisao-reino',
    question: 'Após a morte de qual rei de Israel o reino foi dividido em Reino do Norte (Israel) e Reino do Sul (Judá)?',
    options: ['Saul', 'Davi', 'Salomão', 'Ezequias'],
    correctIndex: 2,
    explanation: 'Com a morte de Salomão e a dureza de seu filho Roboão, as dez tribos do norte se rebelaram com Jeroboão.',
    reference: '1 Reis 12:16-20',
    category: 'História bíblica',
    difficulty: 'Difícil',
    xpReward: 100
  },
  {
    id: 'q-historia-muros-neemias',
    question: 'Em quantos dias Neemias e o povo de Jerusalém conseguiram reconstruir os muros da cidade?',
    options: ['7 dias', '40 dias', '52 dias', '365 dias'],
    correctIndex: 2,
    explanation: 'A reconstrução miraculosa das muralhas de Jerusalém foi finalizada em apenas 52 dias no mês de Elul.',
    reference: 'Neemias 6:15',
    category: 'História bíblica',
    difficulty: 'Mestre',
    xpReward: 100
  }
];
