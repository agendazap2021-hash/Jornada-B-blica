import { ReadingPlan } from '../types';

export const READING_PLANS: ReadingPlan[] = [
  {
    id: 'plan-jesus',
    title: 'Conhecendo Jesus',
    durationDays: 14,
    description: 'Uma caminhada transformadora de duas semanas pelos ensinamentos, milagres e o coração compassivo de Cristo nos Evangelhos.',
    category: 'Iniciante',
    isPremium: false,
    days: [
      { day: 1, title: 'O Verbo se fez carne', passages: [{ bookId: 'joao', bookName: 'João', chapter: 1 }], completed: true },
      { day: 2, title: 'O primeiro milagre e a purificação', passages: [{ bookId: 'joao', bookName: 'João', chapter: 2 }], completed: true },
      { day: 3, title: 'Nicodemos e o novo nascimento', passages: [{ bookId: 'joao', bookName: 'João', chapter: 3 }], completed: true },
      { day: 4, title: 'A mulher samaritana e a água viva', passages: [{ bookId: 'joao', bookName: 'João', chapter: 4 }], completed: false },
      { day: 5, title: 'As Bem-Aventuranças', passages: [{ bookId: 'mt', bookName: 'Mateus', chapter: 5 }], completed: false },
      { day: 6, title: 'O Pai Nosso e a confiança em Deus', passages: [{ bookId: 'mt', bookName: 'Mateus', chapter: 6 }], completed: false },
      { day: 7, title: 'A tempestade acalmada e milagres', passages: [{ bookId: 'mc', bookName: 'Marcos', chapter: 4 }], completed: false },
      { day: 8, title: 'O Bom Samaritano', passages: [{ bookId: 'lc', bookName: 'Lucas', chapter: 10 }], completed: false },
      { day: 9, title: 'A ovelha perdida e o Filho Pródigo', passages: [{ bookId: 'lc', bookName: 'Lucas', chapter: 15 }], completed: false },
      { day: 10, title: 'A ressurreição de Lázaro', passages: [{ bookId: 'joao', bookName: 'João', chapter: 11 }], completed: false },
      { day: 11, title: 'Eu sou o Caminho, a Verdade e a Vida', passages: [{ bookId: 'joao', bookName: 'João', chapter: 14 }], completed: false },
      { day: 12, title: 'A videira verdadeira', passages: [{ bookId: 'joao', bookName: 'João', chapter: 15 }], completed: false },
      { day: 13, title: 'A entrega na cruz e o amor supremo', passages: [{ bookId: 'joao', bookName: 'João', chapter: 19 }], completed: false },
      { day: 14, title: 'O sepulcro vazio e a vitória triunfal', passages: [{ bookId: 'joao', bookName: 'João', chapter: 20 }], completed: false }
    ]
  },
  {
    id: 'plan-proverbios',
    title: 'Provérbios em 31 dias',
    durationDays: 31,
    description: 'Um capítulo por dia para cultivar sabedoria prática, discernimento financeiro, integridade e relacionamentos saudáveis no temor do Senhor.',
    category: 'Devocional',
    isPremium: false,
    days: Array.from({ length: 31 }, (_, i) => ({
      day: i + 1,
      title: `Sabedoria Diária — Capítulo ${i + 1}`,
      passages: [{ bookId: 'pv', bookName: 'Provérbios', chapter: i + 1 }],
      completed: i < 5
    }))
  },
  {
    id: 'plan-salmos',
    title: 'Salmos em 30 dias',
    durationDays: 30,
    description: 'Mergulhe no livro de orações e cânticos de Israel. Encontre alívio nas tribulações, refúgio na presença de Deus e hinos de louvor para cada manhã.',
    category: 'Devocional',
    isPremium: false,
    days: Array.from({ length: 30 }, (_, i) => ({
      day: i + 1,
      title: `Cânticos de Louvor e Súplica — Dia ${i + 1}`,
      passages: [
        { bookId: 'sl', bookName: 'Salmos', chapter: i * 5 + 1 },
        { bookId: 'sl', bookName: 'Salmos', chapter: i * 5 + 2 }
      ],
      completed: i < 2
    }))
  },
  {
    id: 'plan-evangelhos',
    title: 'Evangelhos em 30 dias',
    durationDays: 30,
    description: 'Uma imersão completa e compassada na vida, ministério, morte e ressurreição de Jesus Cristo através dos quatro Evangelhos.',
    category: 'Geral',
    isPremium: false,
    days: Array.from({ length: 30 }, (_, i) => ({
      day: i + 1,
      title: `Os Passos do Mestre — Dia ${i + 1}`,
      passages: [
        { bookId: 'mt', bookName: 'Mateus', chapter: Math.min(28, i + 1) }
      ],
      completed: i < 4
    }))
  },
  {
    id: 'plan-nt90',
    title: 'Novo Testamento em 90 dias',
    durationDays: 90,
    description: 'Leia todo o Novo Testamento, de Mateus a Apocalipse, em apenas três meses com cerca de três capítulos por dia.',
    category: 'Geral',
    isPremium: true,
    days: Array.from({ length: 90 }, (_, i) => ({
      day: i + 1,
      title: `A Nova Aliança — Dia ${i + 1}`,
      passages: [
        { bookId: 'mt', bookName: 'Mateus', chapter: Math.min(28, (i % 28) + 1) }
      ],
      completed: i < 7
    }))
  },
  {
    id: 'plan-ano',
    title: 'Bíblia em 1 ano',
    durationDays: 365,
    description: 'O clássico e consagrado plano anual cobrindo toda a Escritura de Gênesis a Apocalipse de forma equilibrada e rica.',
    category: 'Avançado',
    isPremium: true,
    days: Array.from({ length: 365 }, (_, i) => ({
      day: i + 1,
      title: `Caminho das Escrituras — Dia ${i + 1}`,
      passages: [
        { bookId: 'gn', bookName: 'Gênesis', chapter: Math.min(50, (i % 50) + 1) },
        { bookId: 'sl', bookName: 'Salmos', chapter: (i % 150) + 1 }
      ],
      completed: i < 12
    }))
  }
];
