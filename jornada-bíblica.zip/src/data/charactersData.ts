import { BiblicalCharacter } from '../types';

export const BIBLICAL_CHARACTERS: BiblicalCharacter[] = [
  {
    id: 'moises',
    name: 'Moisés',
    role: 'O Libertador de Israel e Legislador',
    testament: 'AT',
    category: 'Líderes e Juízes',
    avatarIcon: '🌊',
    summary: 'Chamado por Deus na sarça ardente, libertou o povo hebreu da escravidão do Egito, atravessou o Mar Vermelho e recebeu as Tábuas da Lei no Monte Sinai.',
    importantEvents: [
      'Salvo das águas do Nilo e criado no palácio do Faraó',
      'Encontro transformador com Deus na Sarça Ardente em Midiã',
      'As Dez Pragas sobre o Egito e a instituição da Páscoa',
      'Abertura milagrosa do Mar Vermelho',
      'Recebimento dos Dez Mandamentos no Monte Sinai',
      'Condução do povo pelo deserto por 40 anos até o Monte Nebo'
    ],
    keyVerses: [
      { ref: 'Êxodo 3:14', text: 'Disse Deus a Moisés: EU SOU O QUE SOU. Disse mais: Assim dirás aos filhos de Israel: EU SOU me enviou a vós.' },
      { ref: 'Deuteronômio 34:10', text: 'Nunca mais se levantou em Israel profeta semelhante a Moisés, com quem o SENHOR houvesse tratado face a face.' }
    ],
    curiosities: [
      'Seu nome significa "tirado das águas".',
      'Viveu 120 anos divididos exatamente em três fases de 40 anos: no Egito, em Midiã e no deserto.',
      'Apareceu ao lado de Elias na Transfiguração de Jesus no Novo Testamento.'
    ],
    quizQuestionId: 'q-moises'
  },
  {
    id: 'abraao',
    name: 'Abraão',
    role: 'O Pai da Fé e Amigo de Deus',
    testament: 'AT',
    category: 'Patriarcas',
    avatarIcon: '⭐',
    summary: 'Deixou sua parentela em Ur dos Caldeus obedecendo à voz de Deus rumo a Canaã, tornando-se o pai de uma multidão de nações através de sua aliança de fé.',
    importantEvents: [
      'Chamado de Deus para sair da sua terra e da sua parentela',
      'Promessa de que sua descendência seria como as estrelas dos céus',
      'Nascimento miraculoso de Isaque na velhice de Sara',
      'A prova suprema de fé no Monte Moriá com o cordeiro provido por Deus'
    ],
    keyVerses: [
      { ref: 'Gênesis 15:6', text: 'Ele creu no SENHOR, e isso lhe foi imputado para justiça.' },
      { ref: 'Hebreus 11:8', text: 'Pela fé, Abraão, quando chamado, obedeceu, a fim de ir para um lugar que devia receber por herança; e partiu sem saber aonde ia.' }
    ],
    curiosities: [
      'Originalmente se chamava Abrão ("pai exaltado") e Deus mudou para Abraão ("pai de multidões").',
      'É chamado nas Escrituras de "amigo de Deus" (Tiago 2:23).'
    ],
    quizQuestionId: 'q-abraao'
  },
  {
    id: 'davi',
    name: 'Davi',
    role: 'O Rei segundo o Coração de Deus',
    testament: 'AT',
    category: 'Reis',
    avatarIcon: '👑',
    summary: 'Pastor de ovelhas, salmista inspirado e guerreiro corajoso que derrotou o gigante Golias e unificou o reino de Israel, tornando Jerusalém a capital sagrada.',
    importantEvents: [
      'Ungido em segredo pelo profeta Samuel em Belém',
      'Vitória contra Golias usando apenas uma funda e cinco pedras',
      'Amizade leal com Jônatas e fuga das perseguições de Saul',
      'Coroação como rei e conquista de Jerusalém',
      'Composição da maior parte dos Salmos'
    ],
    keyVerses: [
      { ref: '1 Samuel 16:7', text: 'O homem vê o exterior, porém o SENHOR, o coração.' },
      { ref: 'Salmos 23:1', text: 'O SENHOR é o meu pastor; nada me faltará.' }
    ],
    curiosities: [
      'Era o filho caçula de Jessé e cuidava das ovelhas da família.',
      'Jesus é chamado repetidamente no Novo Testamento de "Filho de Davi".'
    ],
    quizQuestionId: 'q-davi'
  },
  {
    id: 'noe',
    name: 'Noé',
    role: 'O Construtor da Arca e Homem Justo',
    testament: 'AT',
    category: 'Patriarcas',
    avatarIcon: '🕊️',
    summary: 'Homem íntegro que andou com Deus em meio a uma geração corrompida. Construiu a arca por fé e preservou a vida durante o grande Dilúvio.',
    importantEvents: [
      'Recebimento das instruções divinas para a construção da Arca',
      'A preservação de sua família e das espécies durante as águas',
      'O envio do corvo e da pomba com o ramo de oliveira',
      'O arco-íris celestial como selo da aliança eterna'
    ],
    keyVerses: [
      { ref: 'Gênesis 6:9', text: 'Noé era homem justo e íntegro entre os seus contemporâneos; Noé andava com Deus.' },
      { ref: 'Hebreus 11:7', text: 'Pela fé, Noé, divinamente instruído acerca de acontecimentos não vistos ainda, aparelhou uma arca para a salvação de sua casa.' }
    ],
    curiosities: [
      'A arca media aproximadamente 135 metros de comprimento, 22 de largura e 13 de altura.',
      'A pomba retornando com a folha de oliveira tornou-se o símbolo mundial da paz.'
    ],
    quizQuestionId: 'q-noe'
  },
  {
    id: 'jose',
    name: 'José do Egito',
    role: 'O Sonhador que Salvou Nações',
    testament: 'AT',
    category: 'Patriarcas',
    avatarIcon: '🌾',
    summary: 'Vendido como escravo por seus próprios irmãos invejosos, suportou a prisão injusta com integridade e foi promovido por Deus a governador de todo o Egito.',
    importantEvents: [
      'Sonhos proféticos e a túnica de várias cores dada por Jacó',
      'Traição dos irmãos e venda aos midianitas rumo ao Egito',
      'Integridade diante da tentação na casa de Potifar',
      'Interpretação dos sonhos do copeiro e do padeiro no cárcere',
      'Interpretação dos sonhos do Faraó sobre os sete anos de fome',
      'Perdão e reconciliação emocionante com seus irmãos'
    ],
    keyVerses: [
      { ref: 'Gênesis 50:20', text: 'Vós, na verdade, intentastes o mal contra mim; porém Deus o tornou em bem, para fazer, como vedes agora, que se conserve muita gente em vida.' }
    ],
    curiosities: [
      'Tornou-se primeiro-ministro do maior império de sua época aos 30 anos.',
      'Pediu que seus ossos fossem levados de volta a Canaã no êxodo futuro.'
    ]
  },
  {
    id: 'elias',
    name: 'Elias',
    role: 'O Profeta do Fogo e da Restauração',
    testament: 'AT',
    category: 'Profetas',
    avatarIcon: '🔥',
    summary: 'Profeta intrépido de Tisbé que desafiou os 450 profetas de Baal no Monte Carmelo, orou para fechar e abrir os céus e foi levado aos céus em um redemoinho.',
    importantEvents: [
      'Seca profetizada a Acabe e sustento pelos corvos junto ao ribeiro de Querite',
      'Multiplicação da farinha e do azeite da viúva de Sarepta',
      'Confronto dramático no Monte Carmelo com fogo descendo dos céus',
      'Ouvir a voz mansa e delicada de Deus na caverna de Horebe',
      'Arrebatamento aos céus em uma carruagem de fogo com cavalos ardentes'
    ],
    keyVerses: [
      { ref: '1 Reis 18:39', text: 'O que vendo todo o povo, caiu de bruços e disse: O SENHOR é Deus! O SENHOR é Deus!' },
      { ref: 'Tiago 5:17', text: 'Elias era homem sujeito às mesmas paixões que nós, e orou com fervor para que não chovesse e, por três anos e seis meses, não choveu.' }
    ],
    curiosities: [
      'Foi um dos únicos dois personagens do Antigo Testamento que não experimentou a morte física (junto a Enoque).'
    ]
  },
  {
    id: 'daniel',
    name: 'Daniel',
    role: 'O Profeta Fiel na Babilônia',
    testament: 'AT',
    category: 'Profetas',
    avatarIcon: '🦁',
    summary: 'Levado cativo ainda jovem para a Babilônia, decidiu não se contaminar com as iguarias do rei, desvendou mistérios imperiais e sobreviveu ileso na cova dos leões.',
    importantEvents: [
      'Recusa em comer a comida impura do rei da Babilônia',
      'Interpretação da estátua do sonho do rei Nabucodonosor',
      'Interpretação da escrita na parede durante o banquete de Belsazar',
      'Livramento miraculoso na cova dos leões sob o rei Dario',
      'Visões escatológicas sobre os reinos mundiais e o Ancião de Dias'
    ],
    keyVerses: [
      { ref: 'Daniel 1:8', text: 'Resolveu Daniel, firmemente, não contaminar-se com as finas iguarias do rei, nem com o vinho que ele bebia.' },
      { ref: 'Daniel 6:22', text: 'O meu Deus enviou o seu anjo e fechou a boca dos leões, para que não me fizessem dano.' }
    ],
    curiosities: [
      'Orava ajoelhado três vezes ao dia em seu quarto com as janelas abertas voltadas para Jerusalém.',
      'Seu nome babilônico era Beltessazar.'
    ]
  },
  {
    id: 'isaias',
    name: 'Isaías',
    role: 'O Profeta Messiânico',
    testament: 'AT',
    category: 'Profetas',
    avatarIcon: '📜',
    summary: 'Profeta de alta estatura intelectual que teve a visão sublime do trono de Deus no Templo e profetizou com espantosa precisão sobre o nascimento virginal e o sacrifício de Jesus.',
    importantEvents: [
      'Visão do Senhor alto e sublime e a brasa viva tocando seus lábios',
      'Profecia de Emanuel nascido da virgem',
      'A revelação do Servo Sofredor que levou sobre Si as nossas dores',
      'Anúncio do Reino de Paz onde o lobo habitará com o cordeiro'
    ],
    keyVerses: [
      { ref: 'Isaías 6:8', text: 'Depois disto, ouvi a voz do Senhor, que dizia: A quem enviarei, e quem há de ir por nós? Disse eu: eis-me aqui, envia-me a mim.' },
      { ref: 'Isaías 53:5', text: 'Mas ele foi traspassado pelas nossas transgressões e moído pelas nossas iniquidades; o castigo que nos traz a paz estava sobre ele, e pelas suas pisaduras fomos sarados.' }
    ],
    curiosities: [
      'O livro de Isaías tem 66 capítulos, assim como a Bíblia tem 66 livros (39 com tom de juízo e 27 de conforto e redenção).'
    ]
  },
  {
    id: 'pedro',
    name: 'Pedro',
    role: 'O Apóstolo e Pescador de Homens',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '⛵',
    summary: 'Pescador impetuoso da Galileia que deixou suas redes para seguir a Cristo. Fez a grande confissão de fé, foi restaurado pelo amor de Jesus e liderou a Igreja no Pentecostes.',
    importantEvents: [
      'Chamado junto ao Mar da Galileia com seu irmão André',
      'Caminhar sobre as águas em direção a Jesus',
      'A confissão: "Tu és o Cristo, o Filho do Deus vivo"',
      'A negação dolorosa e o olhar acolhedor de restauração de Cristo',
      'O grande sermão do Pentecostes onde quase três mil almas se converteram'
    ],
    keyVerses: [
      { ref: 'Mateus 16:16', text: 'Respondendo Simão Pedro, disse: Tu és o Cristo, o Filho do Deus vivo.' },
      { ref: '1 Pedro 5:7', text: 'Lançando sobre ele toda a vossa ansiedade, porque ele tem cuidado de vós.' }
    ],
    curiosities: [
      'Seu nome de nascimento era Simão, e Jesus o apelidou de Cefas/Pedro ("Pedra").'
    ]
  },
  {
    id: 'paulo',
    name: 'Paulo de Tarso',
    role: 'O Apóstolo dos Gentios',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '✍️',
    summary: 'De ferrenho perseguidor dos cristãos a um dos maiores missionários e teólogos da história da Igreja, autor de 13 cartas do Novo Testamento após seu encontro na estrada de Damasco.',
    importantEvents: [
      'Conversão radical pela luz resplandecente no caminho de Damasco',
      'Três grandes viagens missionárias pelo Império Romano',
      'Discurso memorável no Areópago de Atenas',
      'Sobrevivência a naufrágio na ilha de Malta e picada de serpente',
      'Cartas inspiradas escritas de dentro de prisões'
    ],
    keyVerses: [
      { ref: 'Gálatas 2:20', text: 'Logo, já não sou eu quem vive, mas Cristo vive em mim.' },
      { ref: 'Filipenses 4:13', text: 'Tudo posso naquele que me fortalece.' },
      { ref: '2 Timóteo 4:7', text: 'Combati o bom combate, completei a carreira, guardei a fé.' }
    ],
    curiosities: [
      'Era cidadão romano por nascimento e fariseu instruído aos pés do célebre mestre Gamaliel.'
    ]
  },
  {
    id: 'maria_mae',
    name: 'Maria (Mãe de Jesus)',
    role: 'A Serva Cheia de Graça',
    testament: 'NT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '🌸',
    summary: 'Jovem humilde de Nazaré escolhida para dar à luz o Salvador da humanidade por obra do Espírito Santo, demonstrando total submissão e confiança nos planos divinos.',
    importantEvents: [
      'Anunciação do arcanjo Gabriel e resposta de obediência',
      'Cântico sublime do Magnificat ao visitar sua prima Isabel',
      'Nascimento de Jesus em uma manjedoura de Belém',
      'Fuga protetora para o Egito para escapar de Herodes',
      'Permanência fiel ao pé da cruz do Calvário'
    ],
    keyVerses: [
      { ref: 'Lucas 1:38', text: 'Aqui está a serva do Senhor; cumpra-se em mim segundo a tua palavra.' },
      { ref: 'Lucas 1:46-47', text: 'A minha alma engrandece ao Senhor, e o meu espírito se alegrou em Deus, meu Salvador.' }
    ],
    curiosities: [
      'Guardava todas as palavras e acontecimentos ponderando-os em seu coração.'
    ]
  },
  {
    id: 'joao_batista',
    name: 'João Batista',
    role: 'A Voz que Clama no Deserto',
    testament: 'NT',
    category: 'Profetas',
    avatarIcon: '🌊',
    summary: 'Precursor do Messias, pregava o batismo de arrependimento no deserto da Judeia e apontou Jesus publicamente como o Cordeiro de Deus que tira o pecado do mundo.',
    importantEvents: [
      'Nascimento miraculoso aos pais idosos Zacarias e Isabel',
      'Pregação inflamada nas margens do Rio Jordão',
      'Batismo de Jesus Cristo e a descida do Espírito em forma de pomba',
      'Declaração de humildade: "Importa que ele cresça e que eu diminua"'
    ],
    keyVerses: [
      { ref: 'João 1:29', text: 'No dia seguinte, viu João a Jesus, que vinha para ele, e disse: Eis o Cordeiro de Deus, que tira o pecado do mundo!' },
      { ref: 'João 3:30', text: 'Convém que ele cresça e que eu diminua.' }
    ],
    curiosities: [
      'Vestia-se de pelos de camelo com cinto de couro e alimentava-se de gafanhotos e mel silvestre.'
    ]
  },
  {
    id: 'rute',
    name: 'Rute',
    role: 'Exemplo de Lealdade e Devoção',
    testament: 'AT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '🌾',
    summary: 'Moabita viúva que demonstrou fidelidade incondicional à sua sogra Noemi, acolheu o Deus de Israel e tornou-se bisavó do rei Davi e ancestral de Jesus.',
    importantEvents: [
      'Decisão de acompanhar Noemi a Belém após as perdas em Moabe',
      'Respiga respeitosa no campo de cevada do parente remidor Boaz',
      'Casamento de redenção com Boaz em Belém',
      'Nascimento de Obede, pai de Jessé e avô de Davi'
    ],
    keyVerses: [
      { ref: 'Rute 1:16', text: 'Não me instes para que te deixe e me afaste de ti; porque, aonde quer que fores, irei eu e, onde quer que pousares, ali pousarei eu; o teu povo é o meu povo, o teu Deus é o meu Deus.' }
    ],
    curiosities: [
      'É uma das poucas mulheres mencionadas expressamente na genealogia de Jesus em Mateus 1.'
    ]
  },
  {
    id: 'ester',
    name: 'Ester',
    role: 'A Rainha da Coragem e do Livramento',
    testament: 'AT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '👑',
    summary: 'Jovem órfã judia na Pérsia criada pelo primo Mardoqueu. Tornou-se rainha e arriscou a própria vida perante o rei Assuero para salvar seu povo do genocídio tramado por Hamã.',
    importantEvents: [
      'Escolha como nova rainha do Império Persa',
      'Convocação de três dias de jejum e oração entre os judeus',
      'Apresentação sem convite ao rei: "Se perecer, pereci"',
      'Desmascaramento de Hamã nos banquetes reais',
      'Instituição festiva do Purim'
    ],
    keyVerses: [
      { ref: 'Ester 4:14', text: 'E quem sabe se para conjuntura como esta é que foste elevada a rainha?' },
      { ref: 'Ester 4:16', text: 'Irei ter com o rei, ainda que é contra a lei; se perecer, pereci.' }
    ],
    curiosities: [
      'Seu nome hebraico era Hadassa, que significa "murta". O livro de Ester não cita explicitamente a palavra "Deus", mas Sua providência é evidente em cada versículo.'
    ]
  },
  {
    id: 'salomao',
    name: 'Salomão',
    role: 'O Rei Sábio e Construtor do Templo',
    testament: 'AT',
    category: 'Reis',
    avatarIcon: '🏛️',
    summary: 'Filho de Davi e Bate-Seba, pediu sabedoria a Deus para governar em vez de riquezas ou vida longa. Edificou o suntuoso Templo de Jerusalém e reuniu milhares de provérbios.',
    importantEvents: [
      'Oração em Gibeão pedindo discernimento para julgar o povo',
      'O célebre julgamento das duas mães disputando o bebê',
      'Construção e consagração solene do Templo de Jerusalém',
      'Visita majestosa da Rainha de Sabá para ouvir sua sabedoria'
    ],
    keyVerses: [
      { ref: 'Provérbios 1:7', text: 'O temor do SENHOR é o princípio do saber, mas os insensatos desprezam a sabedoria e o ensino.' },
      { ref: 'Eclesiastes 12:13', text: 'De tudo o que se ouviu, a conclusão é: Teme a Deus e guarda os seus mandamentos; porque isto é o dever de todo homem.' }
    ],
    curiosities: [
      'Escreveu ou reuniu 3.000 provérbios e compôs 1.005 cânticos (1 Reis 4:32).'
    ]
  },
  {
    id: 'josue',
    name: 'Josué',
    role: 'O Guerreiro da Promessa e Conquistador',
    testament: 'AT',
    category: 'Líderes e Juízes',
    avatarIcon: '🛡️',
    summary: 'Sucessor de Moisés e comandante das tropas de Israel, liderou a travessia do Jordão e a conquista das cidades fortificadas de Canaã com coragem inabalável.',
    importantEvents: [
      'Espião leal que deu relatório de fé juntamente com Calebe',
      'Ordenança divina: "Sê forte e corajoso"',
      'Travessia milagrosa do Rio Jordão com a Arca da Aliança',
      'Queda estrondosa das muralhas de Jericó',
      'Desafio solene: "Eu e a minha casa serviremos ao SENHOR"'
    ],
    keyVerses: [
      { ref: 'Josué 1:9', text: 'Não to mandei eu? Sê forte e corajoso; não temas, nem te espantes, porque o SENHOR, teu Deus, é contigo por onde quer que andares.' },
      { ref: 'Josué 24:15', text: 'Eu e a minha casa serviremos ao SENHOR.' }
    ],
    curiosities: [
      'O nome Josué significa "O SENHOR é salvação", sendo a raiz hebraica do nome Jesus.'
    ]
  },
  {
    id: 'samuel',
    name: 'Samuel',
    role: 'O Último Juiz e Primeiro dos Profetas',
    testament: 'AT',
    category: 'Profetas',
    avatarIcon: '🕯️',
    summary: 'Filho das orações fervorosas de Ana, cresceu no tabernáculo sob o sacerdote Eli, ouviu o chamado de Deus ainda menino e ungiu os dois primeiros reis de Israel (Saul e Davi).',
    importantEvents: [
      'Resposta ao chamado noturno: "Fala, Senhor, que o teu servo ouve"',
      'Vitória contra os filisteus e o memorial Ebenézer ("Até aqui nos ajudou o Senhor")',
      'Unção de Saul como primeiro rei',
      'Unção do jovem pastor Davi em Belém'
    ],
    keyVerses: [
      { ref: '1 Samuel 3:10', text: 'Veio o SENHOR, e ali esteve, e chamou como das outras vezes: Samuel, Samuel! E disse Samuel: Fala, porque o teu servo ouve.' },
      { ref: '1 Samuel 15:22', text: 'Eis que o obedecer é melhor do que o sacrificar.' }
    ],
    curiosities: [
      'Instituiu a escola dos profetas em Israel.'
    ]
  },
  {
    id: 'sara',
    name: 'Sara',
    role: 'A Mãe das Nações',
    testament: 'AT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '✨',
    summary: 'Esposa de Abraão que acompanhou toda a jornada de peregrinação e, na avançada idade de 90 anos, deu à luz Isaque, cumprindo a promessa sobrenatural de Deus.',
    importantEvents: [
      'Partida com Abraão de Ur para a terra prometida',
      'Riso inicial diante do anúncio angélico de gravidez aos 90 anos',
      'Nascimento e criação de Isaque com imenso júbilo'
    ],
    keyVerses: [
      { ref: 'Gênesis 21:6', text: 'Disse Sara: Deus me deu motivo de riso; e todo aquele que ouvir isso vai rir-se comigo.' },
      { ref: 'Hebreus 11:11', text: 'Pela fé, também a própria Sara recebeu poder para conceber, mesmo além do tempo da idade, porquanto teve por fiel aquele que lhe havia feito a promessa.' }
    ],
    curiosities: [
      'O nome do filho Isaque significa "ele ri" ou "riso".'
    ]
  },
  {
    id: 'debora',
    name: 'Débora',
    role: 'A Juíza e Profetisa Inspiradora',
    testament: 'AT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '🌴',
    summary: 'Profetisa e líder de Israel que julgava o povo debaixo de uma palmeira. Convocou o guerreiro Baraque e liderou a libertação militar contra as forças de Sísera.',
    importantEvents: [
      'Julgamento com sabedoria debaixo da palmeira entre Ramá e Betel',
      'Convocação de Baraque para liderar o exército no Monte Tabor',
      'Vitória milagrosa contra os 900 carros de ferro cananeus',
      'O Cântico memorável de Débora celebrando o livramento'
    ],
    keyVerses: [
      { ref: 'Juízes 5:7', text: 'Ficaram desertas as aldeias em Israel, repousaram, até que eu, Débora, me levantei, levantei-me por mãe em Israel.' }
    ],
    curiosities: [
      'Foi a única juíza mulher mencionada no livro de Juízes.'
    ]
  },
  {
    id: 'gideao',
    name: 'Gideão',
    role: 'O Homem Valoroso da Fé',
    testament: 'AT',
    category: 'Líderes e Juízes',
    avatarIcon: '🏺',
    summary: 'Enquanto malhava o trigo no lagar com medo dos midianitas, foi chamado pelo Anjo do Senhor de "homem valente". Com apenas 300 homens equipados com tochas e trombetas, derrotou um exército numeroso.',
    importantEvents: [
      'Aparição do Anjo sob o carvalho de Ofra',
      'A prova do velo de lã com o orvalho',
      'A seleção dos 300 guerreiros nas águas de Harod',
      'Ataque noturno com cântaros quebrados, tochas e o clamor: "Espada pelo SENHOR e por Gideão!"'
    ],
    keyVerses: [
      { ref: 'Juízes 6:12', text: 'Então, o Anjo do SENHOR lhe apareceu e lhe disse: O SENHOR é contigo, homem valente.' }
    ],
    curiosities: [
      'Também era conhecido como Jerubael ("que Baal pleiteie contra ele").'
    ]
  },
  {
    id: 'sansao',
    name: 'Sansão',
    role: 'O Juiz Dotado de Força Sobrenatural',
    testament: 'AT',
    category: 'Líderes e Juízes',
    avatarIcon: '💪',
    summary: 'Nazarireu desde o ventre materno, foi capacitado pelo Espírito de Deus com uma força física inigualável para combater a opressão dos filisteus sobre Israel.',
    importantEvents: [
      'Vencimento de um leão jovem apenas com as mãos',
      'Derrota de mil homens filisteus com uma queixada de jumento',
      'Romance conturbado com Dalila e perda do voto nazireu',
      'Última oração fervorosa e derrubada dos pilares do templo de Dagom'
    ],
    keyVerses: [
      { ref: 'Juízes 16:28', text: 'Então, Sansão clamou ao SENHOR e disse: Senhor DEUS, peço-te que te lembres de mim e dá-me forças só esta vez, ó Deus.' }
    ],
    curiosities: [
      'Seu cabelo longo era o símbolo visível de sua consagração exclusiva a Deus como nazireu.'
    ]
  },
  {
    id: 'jo_personagem',
    name: 'Jó',
    role: 'O Exemplo Máximo de Paciência e Integridade',
    testament: 'AT',
    category: 'Patriarcas',
    avatarIcon: '💎',
    summary: 'Homem temente a Deus e próspero na terra de Uz. Perdeu filhos, bens e saúde em um único dia, mas manteve sua adoração incondicional e viu Deus restaurar sua vida em dobro.',
    importantEvents: [
      'Perda de todos os rebanhos e filhos e a resposta de louvor',
      'Diálogos poéticos profundos com os três amigos sobre a justiça divina',
      'A resposta de Deus a partir do redemoinho',
      'Restauração em dobro de todas as suas posses e nova família'
    ],
    keyVerses: [
      { ref: 'Jó 1:21', text: 'O SENHOR o deu e o SENHOR o tomou; bendito seja o nome do SENHOR!' },
      { ref: 'Jó 19:25', text: 'Porque eu sei que o meu Redentor vive e por fim se levantará sobre a terra.' },
      { ref: 'Jó 42:5', text: 'Eu te conhecia só de ouvir, mas agora os meus olhos te veem.' }
    ],
    curiosities: [
      'Muitos estudiosos acreditam que os eventos de Jó ocorreram na época patriarcal contemporânea a Abraão.'
    ]
  },
  {
    id: 'neemias',
    name: 'Neemias',
    role: 'O Reconstrutor e Líder Visionário',
    testament: 'AT',
    category: 'Líderes e Juízes',
    avatarIcon: '🧱',
    summary: 'Copeiro do rei persa Artaxerxes, comoveu-se com a ruína de Jerusalém, viajou à cidade e liderou o povo a reconstruir os imensos muros caídos em apenas 52 dias de trabalho árduo e oração.',
    importantEvents: [
      'Oração e choro sincero ao saber da aflição de Jerusalém',
      'Inspeção noturna das muralhas em ruínas',
      'Trabalho com uma mão na ferramenta e outra na espada',
      'Conclusão recorde das muralhas em 52 dias',
      'Leitura pública da Lei ao lado do sacerdote Esdras'
    ],
    keyVerses: [
      { ref: 'Neemias 8:10', text: 'Não vos entristeçais, porque a alegria do SENHOR é a vossa força.' },
      { ref: 'Neemias 4:14', text: 'Lembrai-vos do Senhor, grande e temível, e pelejai pelos vossos irmãos, vossos filhos, vossas filhas, vossa mulher e vossa casa.' }
    ],
    curiosities: [
      'Abriu mão do salário e dos privilégios de governador para não sobrecarregar o povo pobre.'
    ]
  },
  {
    id: 'joao_apostolo',
    name: 'João (O Discípulo Amado)',
    role: 'O Apóstolo do Amor e Escritor do Apocalipse',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '🦅',
    summary: 'Um dos três discípulos mais íntimos de Jesus. Reclinou-se no peito do Mestre na Última Ceia, recebeu Maria aos pés da cruz e escreveu o Evangelho, três epístolas e o Apocalipse na ilha de Patmos.',
    importantEvents: [
      'Testemunha da Transfiguração e da ressurreição da filha de Jairo',
      'Cuidado filial confiado por Cristo em relação a Maria na cruz',
      'Corrida com Pedro até o sepulcro vazio no domingo da ressurreição',
      'Exílio na ilha de Patmos e visões proféticas celestiais'
    ],
    keyVerses: [
      { ref: 'João 3:16', text: 'Porque Deus amou ao mundo de tal maneira que deu o seu Filho unigênito, para que todo o que nele crê não pereça, mas tenha a vida eterna.' },
      { ref: '1 João 4:8', text: 'Aquele que não ama não conhece a Deus, pois Deus é amor.' }
    ],
    curiosities: [
      'Foi o único dos doze apóstolos originais que não morreu como mártir violento, falecendo de velhice em Éfeso.'
    ]
  },
  {
    id: 'maria_madalena',
    name: 'Maria Madalena',
    role: 'A Primeira Testemunha da Ressurreição',
    testament: 'NT',
    category: 'Mulheres da Bíblia',
    avatarIcon: '🌅',
    summary: 'Liberta por Jesus de sete demônios, tornou-se seguidora leal que apoiou Seu ministério, permaneceu junto à cruz e foi a primeira pessoa a quem Cristo ressurreto apareceu no jardim.',
    importantEvents: [
      'Cura e libertação total operada por Jesus',
      'Apoio financeiro e ministerial contínuo a Jesus e aos apóstolos',
      'Presença constante no Calvário e no sepultamento',
      'Encontro com o Cristo Ressurreto no jardim junto ao túmulo vazio',
      'Comissão de anunciar a vitória aos discípulos reunidos'
    ],
    keyVerses: [
      { ref: 'João 20:18', text: 'Veio Maria Madalena anunciando aos discípulos: Vi o Senhor! E contava que ele lhe dissera estas coisas.' }
    ],
    curiosities: [
      'A tradição da igreja primitiva a chamava de "apóstola dos apóstolos" por ter sido enviada a anunciar a ressurreição.'
    ]
  },
  {
    id: 'tiago_irmao',
    name: 'Tiago (Irmão do Senhor)',
    role: 'O Líder da Igreja em Jerusalém',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '⚖️',
    summary: 'Irmão de Jesus que inicialmente não acreditava em Seu ministério messiânico, mas após a ressurreição tornou-se a coluna principal da igreja de Jerusalém e autor da epístola de Tiago.',
    importantEvents: [
      'Aparição especial de Jesus ressurreto a ele (1 Coríntios 15:7)',
      'Presidência do histórico Concílio de Jerusalém em Atos 15',
      'Redação da carta prática enfatizando que a fé sem obras é morta'
    ],
    keyVerses: [
      { ref: 'Tiago 1:22', text: 'Tornai-vos, pois, praticantes da palavra e não somente ouvintes, enganando-vos a vós mesmos.' },
      { ref: 'Tiago 2:26', text: 'Porque, assim como o corpo sem espírito é morto, assim também a fé sem obras é morta.' }
    ],
    curiosities: [
      'Era conhecido pelo historiador Hegésipo como "Tiago, o Justo", com joelhos calejados como os de um camelo por orar sem cessar.'
    ]
  },
  {
    id: 'lucas',
    name: 'Lucas',
    role: 'O Médico Amado e Historiador Inspirado',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '🩺',
    summary: 'Médico gentio culto e companheiro inseparável das viagens do apóstolo Paulo. Investigou meticulosamente testemunhas oculares para escrever o Evangelho de Lucas e o livro de Atos.',
    importantEvents: [
      'Investigação histórica detalhada com testemunhas da vida de Jesus',
      'Companheirismo leal nas prisões marítimas e em Roma com Paulo',
      'Registro das parábolas mais queridas (o Bom Samaritano, o Filho Pródigo)',
      'Crônica detalhada do nascimento da Igreja no livro de Atos'
    ],
    keyVerses: [
      { ref: 'Lucas 1:3', text: 'Igualmente a mim me pareceu bem, depois de acurada investigação de tudo desde sua origem, dar-te por escrito, excelentíssimo Teófilo, uma exposição em ordem.' },
      { ref: 'Colossenses 4:14', text: 'Saúda-vos Lucas, o médico amado.' }
    ],
    curiosities: [
      'É o único autor do Novo Testamento que não era de origem judaica.'
    ]
  },
  {
    id: 'timoteo',
    name: 'Timóteo',
    role: 'O Jovem Pastor e Filho na Fé',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '🌱',
    summary: 'Jovem discípulo de Listra instruído nas Escrituras desde a infância por sua mãe Eunice e avó Lóide. Tornou-se colaborador vital e o mais íntimo filho espiritual de Paulo.',
    importantEvents: [
      'Adesão à segunda viagem missionária de Paulo ainda jovem',
      'Envio para pastorear e resolver conflitos na complexa igreja de Éfeso',
      'Recebimento das cartas pastorais repletas de orientações vitais'
    ],
    keyVerses: [
      { ref: '1 Timóteo 4:12', text: 'Ninguém despreze a tua mocidade; pelo contrário, torna-te padrão dos fiéis, na palavra, no procedimento, no amor, na fé, na pureza.' },
      { ref: '2 Timóteo 1:7', text: 'Porque Deus não nos deu espírito de covardia, mas de poder, de amor e de moderação.' }
    ],
    curiosities: [
      'Paulo o chamava carinhosamente de "meu verdadeiro filho na fé".'
    ]
  },
  {
    id: 'estevao',
    name: 'Estevão',
    role: 'O Primeiro Mártir da Igreja',
    testament: 'NT',
    category: 'Apóstolos e Discípulos',
    avatarIcon: '🕊️',
    summary: 'Um dos sete diáconos escolhidos para servir às mesas, homem cheio de fé e do Espírito Santo que fazia grandes prodígios. Ao ser apedrejado injustamente, perdoou seus algozes como Cristo.',
    importantEvents: [
      'Eleição como diácono para assistir as viúvas em Jerusalém',
      'Discurso teológico brilhante recapitulando a história de Israel perante o Sinédrio',
      'Visão do céu aberto e de Jesus em pé à destra de Deus',
      'Oração de perdão enquanto era apedrejado perante o jovem Saulo'
    ],
    keyVerses: [
      { ref: 'Atos 7:59-60', text: 'E apedrejavam Estêvão, que invocava e dizia: Senhor Jesus, recebe o meu espírito! E, pondo-se de joelhos, clamou com grande voz: Senhor, não lhes imputes este pecado! Com estas palavras, adormeceu.' }
    ],
    curiosities: [
      'Seu rosto brilhava perante o conselho "como o rosto de um anjo" (Atos 6:15).'
    ]
  },
  {
    id: 'jesus_cristo',
    name: 'Jesus Cristo',
    role: 'O Filho de Deus, Salvador e Senhor',
    testament: 'NT',
    category: 'Figuras Centrais',
    avatarIcon: '✝️',
    summary: 'O Verbo divino feito carne, nascido em Belém, viveu sem pecado, ensinou o Reino de Deus, curou multidões, entregou Sua vida na cruz em resgate de muitos e ressuscitou triunfante ao terceiro dia.',
    importantEvents: [
      'Nascimento virginal em Belém profetizado pelos profetas',
      'Batismo no Jordão e unção do Espírito Santo',
      'Sermão da Montanha e revelação do amor da Nova Aliança',
      'Morte expiatória na cruz do Calvário para perdão dos pecados',
      'Ressurreição gloriosa dos mortos ao terceiro dia',
      'Ascensão aos céus e a promessa de retorno triunfal'
    ],
    keyVerses: [
      { ref: 'João 14:6', text: 'Respondeu-lhe Jesus: Eu sou o caminho, e a verdade, e a vida; ninguém vem ao Pai senão por mim.' },
      { ref: 'Mateus 11:28', text: 'Vinde a mim, todos os que estais cansados e sobrecarregados, e eu vos aliviarei.' },
      { ref: 'João 11:25', text: 'Disse-lhe Jesus: Eu sou a ressurreição e a vida. Quem crê em mim, ainda que morra, viverá.' }
    ],
    curiosities: [
      'O nome Jesus em hebraico é Yeshua, significando "Yahweh é salvação". Cristo é o termo grego para o hebraico Messias ("O Ungido").'
    ]
  }
];
