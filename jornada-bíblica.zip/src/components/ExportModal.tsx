import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Download,
  FileCode,
  Archive,
  CheckCircle2,
  ExternalLink,
  Github,
  Globe,
  HelpCircle,
  Copy,
  Sparkles,
} from 'lucide-react';

export const ExportModal: React.FC = () => {
  const { isExportOpen, setIsExportOpen, showToast } = useApp();
  const [downloading, setDownloading] = useState<'single' | 'zip' | null>(null);

  if (!isExportOpen) return null;

  const handleDownload = async (type: 'single' | 'zip') => {
    setDownloading(type);
    try {
      const url = type === 'single' ? '/api/download/index.html' : '/api/download/github-pages.zip';
      const filename = type === 'single' ? 'index.html' : 'jornada-biblica-github-pages.zip';

      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      showToast(
        'Download iniciado!',
        `Seu arquivo ${filename} está sendo baixado para a sua máquina.`,
        'info'
      );
    } catch {
      showToast('Erro no download', 'Tente novamente ou use o link direto.', 'info');
    } finally {
      setTimeout(() => setDownloading(null), 1000);
    }
  };

  const copyGitLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText('https://github.com');
      showToast('Copiado!', 'Link do GitHub copiado para a área de transferência.', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-amber-100 flex items-center justify-between bg-gradient-to-r from-amber-50 to-amber-100/60">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg flex items-center gap-1.5">
                <span>Baixar para o GitHub</span>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  Pronto p/ Pages
                </span>
              </h3>
              <p className="text-xs text-slate-600">
                Coloque o Jornada Bíblica no ar gratuitamente no seu GitHub
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsExportOpen(false)}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Option 1: Standalone single index.html */}
          <div className="p-4 sm:p-5 rounded-2xl border-2 border-amber-400/80 bg-gradient-to-br from-amber-50/50 via-white to-amber-100/30 relative">
            <div className="absolute -top-3 right-4 bg-amber-500 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow-sm flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Mais Fácil (1 Arquivo)
            </div>

            <div className="flex items-start gap-3.5 mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center shrink-0">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  Arquivo Único: <code className="text-amber-700 bg-amber-100/60 px-1 py-0.5 rounded text-xs">index.html</code>
                </h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Tudo está 100% embutido em um único arquivo (estilos, ícones, lógica bíblica e quizzes). Você só precisa subir esse único arquivo na raiz do seu repositório no GitHub!
                </p>
              </div>
            </div>

            <button
              onClick={() => handleDownload('single')}
              disabled={downloading === 'single'}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 active:scale-[0.98] transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{downloading === 'single' ? 'Baixando...' : 'Baixar index.html (Arquivo Único)'}</span>
            </button>
          </div>

          {/* Option 2: Full ZIP package */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors">
            <div className="flex items-start gap-3.5 mb-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                <Archive className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  Pacote Completo: <code className="text-slate-700 bg-slate-100 px-1 py-0.5 rounded text-xs">.ZIP</code>
                </h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Contém <span className="font-semibold">index.html</span> e a subpasta <span className="font-semibold">assets/</span> separada. Ideal para descompactar ou para usar na pasta <code className="bg-slate-100 px-1 rounded text-[11px]">/docs</code>.
                </p>
              </div>
            </div>

            <button
              onClick={() => handleDownload('zip')}
              disabled={downloading === 'zip'}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs sm:text-sm flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{downloading === 'zip' ? 'Baixando...' : 'Baixar jornada-biblica.zip'}</span>
            </button>
          </div>

          {/* 3 Step Tutorial for GitHub Pages */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
            <h4 className="font-bold text-slate-900 text-xs sm:text-sm flex items-center gap-1.5 mb-3">
              <Github className="w-4 h-4 text-slate-800" />
              Como ativar no GitHub Pages em 3 passos:
            </h4>

            <ol className="space-y-2.5 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                  1
                </span>
                <span>
                  Crie um repositório no GitHub (ex: <code>jornada-biblica</code>) e suba o arquivo <strong>index.html</strong> que você acabou de baixar.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                  2
                </span>
                <span>
                  No seu repositório no GitHub, clique em <strong>Settings</strong> (Configurações) → <strong>Pages</strong> (menu lateral).
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                  3
                </span>
                <span>
                  Em <em>Build and deployment</em>, selecione <strong>Deploy from a branch</strong>, escolha a branch <strong>main</strong> e a pasta <strong>/(root)</strong>, depois clique em <strong>Save</strong>.
                </span>
              </li>
            </ol>

            <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                Seu link ficará: <code>seunome.github.io/jornada-biblica/</code>
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <button
            onClick={() => setIsExportOpen(false)}
            className="text-xs text-slate-500 hover:text-slate-700 px-3 py-1.5"
          >
            Fechar
          </button>

          <a
            href="https://github.com/new"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-slate-800 hover:text-slate-950 font-medium px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-white transition-colors"
          >
            <span>Abrir GitHub para criar repositório</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
