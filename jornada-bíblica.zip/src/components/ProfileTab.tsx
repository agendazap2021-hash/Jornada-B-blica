import React, { useState } from 'react';
import { useApp, getLevelInfo } from '../context/AppContext';
import {
  Award,
  BookOpen,
  Swords,
  Flame,
  CalendarDays,
  Heart,
  Highlighter,
  Crown,
  Settings,
  ShieldAlert,
  LogOut,
  RotateCcw,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

const AVATAR_OPTIONS = ['✝️', '🕊️', '👑', '⭐', '🦁', '🌿', '🦅', '🔥', '🛡️', '🕯️'];

export const ProfileTab: React.FC = () => {
  const {
    user,
    achievements,
    favorites,
    highlights,
    openChapter,
    setIsPremiumOpen,
    setIsAdminOpen,
    setIsOnboardingOpen,
    resetAllProgress,
    logoutUser,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'achievements' | 'favorites'>('stats');
  const [isEditingAvatar, setIsEditingAvatar] = useState(false);

  const levelInfo = getLevelInfo(user.totalXp);
  const accuracyRate =
    user.questionsAnsweredCount > 0
      ? Math.round((user.correctAnswersCount / user.questionsAnsweredCount) * 100)
      : 0;

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* 1. Profile Header Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
          {/* Avatar with edit button */}
          <div className="relative">
            <div className="w-20 h-20 rounded-full bg-amber-100 border-2 border-amber-300 flex items-center justify-center text-4xl shadow-inner">
              {user.avatar || '👤'}
            </div>
            <button
              onClick={() => setIsEditingAvatar(!isEditingAvatar)}
              className="absolute -bottom-1 -right-1 p-1.5 bg-slate-900 text-white rounded-full text-xs hover:bg-slate-800 transition-colors shadow-xs"
              title="Trocar Avatar"
            >
              ✏️
            </button>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display">
                  {user.name}
                </h2>
                <p className="text-xs text-slate-500">{user.email}</p>
              </div>

              {/* Premium Status Pill */}
              <button
                onClick={() => setIsPremiumOpen(true)}
                className={`self-center sm:self-auto px-3.5 py-1.5 rounded-full text-xs font-bold inline-flex items-center gap-1.5 transition-all ${
                  user.isPremium
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
                }`}
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>{user.isPremium ? 'Membro Premium' : 'Plano Gratuito'}</span>
              </button>
            </div>

            {/* Level & XP Info */}
            <div className="mt-3 flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <span className="px-3 py-1 bg-slate-900 text-white rounded-full text-xs font-bold">
                Nível {levelInfo.level} — {levelInfo.levelName}
              </span>
              <span className="px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-semibold text-amber-900">
                ⭐ {user.totalXp.toLocaleString('pt-BR')} XP Total
              </span>
              <span className="px-3 py-1 bg-orange-50 border border-orange-200 rounded-full text-xs font-semibold text-orange-900 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-orange-500 text-orange-500" />
                <span>{user.streakDays} dias de sequência</span>
              </span>
            </div>
          </div>
        </div>

        {/* Avatar Picker Dropdown */}
        {isEditingAvatar && (
          <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-center sm:justify-start gap-2 animate-in fade-in">
            <span className="text-xs font-semibold text-slate-600 mr-2">
              Escolha seu ícone:
            </span>
            {AVATAR_OPTIONS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => {
                  user.avatar = emoji;
                  setIsEditingAvatar(false);
                }}
                className="w-9 h-9 rounded-xl bg-slate-50 hover:bg-amber-100 border border-slate-200 flex items-center justify-center text-lg transition-colors"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 2. Sub-tabs Selector */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveSubTab('stats')}
          className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'stats'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Estatísticas
        </button>
        <button
          onClick={() => setActiveSubTab('achievements')}
          className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center gap-1.5 ${
            activeSubTab === 'achievements'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <span>Conquistas</span>
          <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded-full font-extrabold">
            {achievements.filter((a) => a.unlockedAt).length}/{achievements.length}
          </span>
        </button>
        <button
          onClick={() => setActiveSubTab('favorites')}
          className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'favorites'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          Favoritos ({favorites.length})
        </button>
      </div>

      {/* 3. Tab: Estatísticas Gerais */}
      {activeSubTab === 'stats' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-3xl border border-slate-200/80 shadow-2xs">
              <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-2xl font-extrabold text-slate-900 font-display block">
                {user.chaptersReadCount}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Capítulos Lidos
              </span>
            </div>

            <div className="p-4 bg-white rounded-3xl border border-slate-200/80 shadow-2xs">
              <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center mb-2">
                <Flame className="w-5 h-5" />
              </div>
              <span className="text-2xl font-extrabold text-slate-900 font-display block">
                {user.streakDays}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Dias de Sequência
              </span>
            </div>

            <div className="p-4 bg-white rounded-3xl border border-slate-200/80 shadow-2xs">
              <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-2">
                <Swords className="w-5 h-5" />
              </div>
              <span className="text-2xl font-extrabold text-slate-900 font-display block">
                {user.questionsAnsweredCount}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Perguntas Quiz
              </span>
            </div>

            <div className="p-4 bg-white rounded-3xl border border-slate-200/80 shadow-2xs">
              <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2">
                <CalendarDays className="w-5 h-5" />
              </div>
              <span className="text-2xl font-extrabold text-slate-900 font-display block">
                {accuracyRate}%
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Taxa de Acertos
              </span>
            </div>
          </div>

          {/* Goal & Customization */}
          <div className="p-5 bg-white rounded-3xl border border-slate-200/80 shadow-2xs flex items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
                Objetivo Atual
              </span>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">
                {user.goal}
              </p>
            </div>
            <button
              onClick={() => setIsOnboardingOpen(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors shrink-0"
            >
              Mudar Objetivo
            </button>
          </div>
        </div>
      )}

      {/* 4. Tab: Conquistas (Badges) */}
      {activeSubTab === 'achievements' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {achievements.map((ach) => {
            const isUnlocked = !!ach.unlockedAt;

            return (
              <div
                key={ach.id}
                className={`p-4 rounded-3xl border transition-all flex items-start gap-3.5 ${
                  isUnlocked
                    ? 'bg-white border-amber-300 shadow-sm shadow-amber-500/10'
                    : 'bg-slate-50 border-slate-200/80 opacity-55'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 ${
                    isUnlocked
                      ? 'bg-amber-100 text-amber-900 shadow-inner ring-2 ring-amber-200'
                      : 'bg-slate-200 text-slate-400 grayscale'
                  }`}
                >
                  {ach.icon}
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-bold text-slate-900 leading-tight">
                    {ach.title}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                    {ach.description}
                  </p>
                  <span
                    className={`inline-block mt-2 text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      isUnlocked
                        ? 'bg-amber-50 text-amber-800 border border-amber-200'
                        : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    {isUnlocked ? `Desbloqueado em ${ach.unlockedAt}` : 'Bloqueado'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. Tab: Favoritos */}
      {activeSubTab === 'favorites' && (
        <div className="space-y-3">
          {favorites.length === 0 ? (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center text-slate-400">
              <Heart className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <p className="text-sm">Você ainda não favoritou nenhum versículo.</p>
              <p className="text-xs mt-1 text-slate-500">
                Toque no coração ao lado de qualquer versículo na Bíblia para salvá-lo aqui.
              </p>
            </div>
          ) : (
            favorites.map((fav) => (
              <div
                key={fav.id}
                className="p-4 bg-white rounded-3xl border border-slate-200/80 shadow-2xs space-y-2 hover:border-amber-300 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-amber-800">
                    {fav.bookName} {fav.chapter}:{fav.verse}
                  </span>
                  <button
                    onClick={() => openChapter(fav.bookId, fav.chapter)}
                    className="text-xs font-semibold text-slate-600 hover:text-amber-700 flex items-center gap-1"
                  >
                    <span>Ler no contexto</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
                <blockquote className="font-scripture text-sm text-slate-800 italic leading-relaxed">
                  "{fav.text}"
                </blockquote>
              </div>
            ))
          )}
        </div>
      )}

      {/* 6. Settings, Admin & Danger Zone */}
      <div className="pt-6 border-t border-slate-200 space-y-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
          Gerenciamento & Ajustes
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Admin Panel button */}
          <button
            onClick={() => setIsAdminOpen(true)}
            className="p-3.5 bg-white hover:bg-slate-50 border border-slate-200/80 rounded-2xl text-left flex items-center justify-between text-xs font-bold text-slate-800 transition-colors shadow-2xs"
          >
            <div className="flex items-center gap-2.5">
              <ShieldAlert className="w-4 h-4 text-indigo-600" />
              <span>Painel do Administrador</span>
            </div>
            <span className="text-[10px] text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md font-bold">
              Gestão
            </span>
          </button>

          {/* Reset App */}
          <button
            onClick={() => {
              if (window.confirm('Tem certeza de que deseja restaurar o aplicativo para os dados originais?')) {
                resetAllProgress();
              }
            }}
            className="p-3.5 bg-white hover:bg-rose-50 border border-slate-200/80 hover:border-rose-200 rounded-2xl text-left flex items-center justify-between text-xs font-bold text-rose-700 transition-colors shadow-2xs"
          >
            <div className="flex items-center gap-2.5">
              <RotateCcw className="w-4 h-4 text-rose-500" />
              <span>Restaurar Dados Iniciais</span>
            </div>
            <span className="text-[10px] text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
              Reset
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
