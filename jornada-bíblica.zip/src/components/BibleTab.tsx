import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { BIBLE_BOOKS, getChapterVerses } from '../data/bibleData';
import { BibleBook, Verse } from '../types';
import {
  Search,
  BookOpen,
  Volume2,
  VolumeX,
  Heart,
  Highlighter,
  Share2,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Type,
  X,
  Filter,
} from 'lucide-react';

export const BibleTab: React.FC = () => {
  const {
    currentBookId,
    currentChapter,
    openChapter,
    favorites,
    toggleFavorite,
    highlights,
    addHighlight,
    removeHighlight,
    markChapterAsRead,
    setIsAiBibleOpen,
    showToast,
  } = useApp();

  const [isBookSelectorOpen, setIsBookSelectorOpen] = useState(false);
  const [testamentFilter, setTestamentFilter] = useState<'ALL' | 'AT' | 'NT'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [bookSearchQuery, setBookSearchQuery] = useState('');
  const [verseSearchQuery, setVerseSearchQuery] = useState('');

  // Reader Customization
  const [fontSize, setFontSize] = useState<number>(18);
  const [selectedHighlightColor, setSelectedHighlightColor] = useState<'amber' | 'emerald' | 'sky' | 'rose'>('amber');
  const [activeHighlighting, setActiveHighlighting] = useState(false);

  // Audio TTS playback state
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Current book object
  const currentBook = useMemo(() => {
    return BIBLE_BOOKS.find((b) => b.id === currentBookId) || BIBLE_BOOKS[0];
  }, [currentBookId]);

  // Current chapter verses
  const verses = useMemo(() => {
    return getChapterVerses(currentBook.id, currentChapter);
  }, [currentBook.id, currentChapter]);

  // Filtered verses by text search
  const displayedVerses = useMemo(() => {
    if (!verseSearchQuery.trim()) return verses;
    return verses.filter((v) =>
      v.text.toLowerCase().includes(verseSearchQuery.toLowerCase())
    );
  }, [verses, verseSearchQuery]);

  // Filtered books in modal
  const filteredBooks = useMemo(() => {
    return BIBLE_BOOKS.filter((b) => {
      const matchTestament = testamentFilter === 'ALL' || b.testament === testamentFilter;
      const matchCategory = categoryFilter === 'ALL' || b.category === categoryFilter;
      const matchSearch =
        b.name.toLowerCase().includes(bookSearchQuery.toLowerCase()) ||
        b.abbreviation.toLowerCase().includes(bookSearchQuery.toLowerCase());
      return matchTestament && matchCategory && matchSearch;
    });
  }, [testamentFilter, categoryFilter, bookSearchQuery]);

  // Chapter navigation
  const handlePrevChapter = () => {
    if (currentChapter > 1) {
      openChapter(currentBook.id, currentChapter - 1);
    } else {
      const currentIndex = BIBLE_BOOKS.findIndex((b) => b.id === currentBook.id);
      if (currentIndex > 0) {
        const prevBook = BIBLE_BOOKS[currentIndex - 1];
        openChapter(prevBook.id, prevBook.chaptersCount);
      }
    }
    stopAudio();
  };

  const handleNextChapter = () => {
    if (currentChapter < currentBook.chaptersCount) {
      openChapter(currentBook.id, currentChapter + 1);
    } else {
      const currentIndex = BIBLE_BOOKS.findIndex((b) => b.id === currentBook.id);
      if (currentIndex < BIBLE_BOOKS.length - 1) {
        const nextBook = BIBLE_BOOKS[currentIndex + 1];
        openChapter(nextBook.id, 1);
      }
    }
    stopAudio();
  };

  // Text-to-Speech playback
  const toggleAudio = () => {
    if (!('speechSynthesis' in window)) {
      showToast('Áudio não suportado', 'Seu navegador não suporta síntese de voz.', 'info');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const fullText = `${currentBook.name}, capítulo ${currentChapter}. ${verses
      .map((v) => `${v.verse}. ${v.text}`)
      .join(' ')}`;

    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.95;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    window.speechSynthesis.speak(utterance);
    setIsPlayingAudio(true);
    showToast('Reproduzindo capítulo em áudio', `${currentBook.name} ${currentChapter}`, 'info');
  };

  const stopAudio = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlayingAudio(false);
  };

  const handleShareVerse = (v: Verse) => {
    const textToShare = `"${v.text}" — ${v.bookName} ${v.chapter}:${v.verse} (Jornada Bíblica)`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToShare);
      showToast('Versículo copiado!', 'Pronto para compartilhar no WhatsApp ou redes.', 'info');
    }
  };

  const isVerseFavorite = (verseNum: number) => {
    return favorites.some(
      (f) => f.bookId === currentBook.id && f.chapter === currentChapter && f.verse === verseNum
    );
  };

  const getVerseHighlight = (verseNum: number) => {
    return highlights.find(
      (h) => h.bookId === currentBook.id && h.chapter === currentChapter && h.verse === verseNum
    );
  };

  const handleVerseClick = (v: Verse) => {
    if (activeHighlighting) {
      const existing = getVerseHighlight(v.verse);
      if (existing) {
        removeHighlight(existing.id);
      } else {
        addHighlight(currentBook.id, currentChapter, v.verse, selectedHighlightColor, v.text);
      }
    }
  };

  return (
    <div className="space-y-5 pb-16 animate-in fade-in duration-300">
      {/* 1. Header Toolbar */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3 sticky top-16 z-20 backdrop-blur-md bg-white/95">
        {/* Book & Chapter Selector Button */}
        <button
          onClick={() => setIsBookSelectorOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-amber-50 hover:bg-amber-100/80 border border-amber-200 rounded-2xl text-amber-950 font-bold text-sm sm:text-base transition-all group"
        >
          <BookOpen className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          <span>
            {currentBook.name} {currentChapter}
          </span>
          <span className="text-xs text-amber-600 bg-amber-200/60 px-2 py-0.5 rounded-full">
            Trocar
          </span>
        </button>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Audio TTS Button */}
          <button
            onClick={toggleAudio}
            className={`p-2.5 rounded-2xl transition-all border ${
              isPlayingAudio
                ? 'bg-amber-500 text-white border-amber-600 shadow-sm animate-pulse'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
            title={isPlayingAudio ? 'Pausar áudio' : 'Ouvir capítulo em áudio'}
          >
            {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Highlighting mode toggle */}
          <button
            onClick={() => setActiveHighlighting(!activeHighlighting)}
            className={`p-2.5 rounded-2xl transition-all border ${
              activeHighlighting
                ? 'bg-amber-100 text-amber-900 border-amber-400 shadow-xs ring-2 ring-amber-300'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
            }`}
            title="Modo Destaque (clique no versículo para colorir)"
          >
            <Highlighter className="w-4 h-4" />
          </button>

          {/* Font Zoom Controls */}
          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-2xl p-0.5">
            <button
              onClick={() => setFontSize((s) => Math.max(14, s - 2))}
              className="px-2 py-1 text-xs font-bold text-slate-600 hover:text-slate-900"
              title="Diminuir fonte"
            >
              A-
            </button>
            <div className="w-[1px] h-4 bg-slate-200" />
            <button
              onClick={() => setFontSize((s) => Math.min(26, s + 2))}
              className="px-2 py-1 text-xs font-bold text-slate-600 hover:text-slate-900"
              title="Aumentar fonte"
            >
              A+
            </button>
          </div>
        </div>
      </div>

      {/* 2. Color Palette when Highlighting Mode is active */}
      {activeHighlighting && (
        <div className="p-3 bg-amber-50/80 border border-amber-200/80 rounded-2xl flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-amber-900">
              Cor do destaque:
            </span>
            <div className="flex items-center gap-1.5">
              {(['amber', 'emerald', 'sky', 'rose'] as const).map((color) => {
                const colorClasses = {
                  amber: 'bg-amber-300',
                  emerald: 'bg-emerald-300',
                  sky: 'bg-sky-300',
                  rose: 'bg-rose-300',
                };
                return (
                  <button
                    key={color}
                    onClick={() => setSelectedHighlightColor(color)}
                    className={`w-6 h-6 rounded-full ${colorClasses[color]} border-2 transition-transform ${
                      selectedHighlightColor === color
                        ? 'border-slate-800 scale-110 shadow-xs'
                        : 'border-transparent hover:scale-105'
                    }`}
                  />
                );
              })}
            </div>
          </div>
          <span className="text-[11px] text-amber-800">
            Clique no versículo para pintar ou remover
          </span>
        </div>
      )}

      {/* 3. Search verses in current chapter */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          value={verseSearchQuery}
          onChange={(e) => setVerseSearchQuery(e.target.value)}
          placeholder={`Pesquisar palavra em ${currentBook.name} ${currentChapter}...`}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200/80 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
        />
        {verseSearchQuery && (
          <button
            onClick={() => setVerseSearchQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 4. Scripture Reader Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200/80 shadow-xs space-y-6">
        {/* Chapter Header */}
        <div className="text-center pb-6 border-b border-slate-100">
          <span className="text-xs uppercase tracking-widest text-amber-700 font-semibold font-mono">
            {currentBook.category} · {currentBook.testament === 'AT' ? 'Antigo Testamento' : 'Novo Testamento'}
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display mt-1">
            {currentBook.name}
          </h2>
          <span className="text-base font-serif italic text-slate-500 mt-1 block">
            Capítulo {currentChapter}
          </span>
        </div>

        {/* Verses Container */}
        <div className="space-y-4">
          {displayedVerses.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p>Nenhum versículo encontrado com "{verseSearchQuery}".</p>
            </div>
          ) : (
            displayedVerses.map((v) => {
              const highlight = getVerseHighlight(v.verse);
              const isFav = isVerseFavorite(v.verse);

              const highlightBg = highlight
                ? highlight.color === 'amber'
                  ? 'bg-amber-100/80'
                  : highlight.color === 'emerald'
                  ? 'bg-emerald-100/80'
                  : highlight.color === 'sky'
                  ? 'bg-sky-100/80'
                  : 'bg-rose-100/80'
                : '';

              return (
                <div
                  key={v.verse}
                  onClick={() => handleVerseClick(v)}
                  className={`group relative p-2.5 rounded-2xl transition-all ${highlightBg} ${
                    activeHighlighting ? 'cursor-pointer hover:bg-amber-50/70' : ''
                  }`}
                >
                  <p
                    className="font-scripture leading-relaxed text-slate-800"
                    style={{ fontSize: `${fontSize}px` }}
                  >
                    <sup className="font-sans font-bold text-amber-700 mr-2 text-xs select-none">
                      {v.verse}
                    </sup>
                    {v.text}
                  </p>

                  {/* Inline quick tools on verse hover/tap */}
                  <div className="mt-1 flex items-center justify-end gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                    {/* Ask AI about this verse */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setIsAiBibleOpen(true);
                      }}
                      className="p-1.5 text-xs text-amber-700 hover:bg-amber-100 rounded-lg flex items-center gap-1"
                      title="Perguntar à IA sobre este versículo"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-semibold">Explicar</span>
                    </button>

                    {/* Favorite */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(currentBook.id, currentBook.name, currentChapter, v.verse, v.text);
                      }}
                      className={`p-1.5 rounded-lg transition-colors ${
                        isFav
                          ? 'text-rose-600 bg-rose-50'
                          : 'text-slate-400 hover:text-rose-500 hover:bg-slate-100'
                      }`}
                      title={isFav ? 'Remover dos favoritos' : 'Favoritar versículo'}
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-500' : ''}`} />
                    </button>

                    {/* Share */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleShareVerse(v);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Compartilhar versículo"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* 5. Complete Chapter Button (+50 XP) */}
        <div className="pt-8 border-t border-slate-100 text-center space-y-3">
          <button
            onClick={() => markChapterAsRead(currentBook.id, currentChapter)}
            className="px-6 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-2xl text-sm transition-all shadow-md shadow-amber-500/20 inline-flex items-center gap-2 group"
          >
            <CheckCircle2 className="w-5 h-5 text-amber-100 group-hover:scale-110 transition-transform" />
            <span>Concluir Leitura deste Capítulo (+50 XP)</span>
          </button>
          <p className="text-xs text-slate-600 block">
            Tradução de Domínio Público (João Ferreira de Almeida)
          </p>
        </div>

        {/* 6. Chapter Navigation Bottom Bar */}
        <div className="flex items-center justify-between pt-4">
          <button
            onClick={handlePrevChapter}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl text-xs sm:text-sm font-semibold transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Anterior</span>
          </button>

          <span className="text-xs text-slate-600 font-medium">
            Capítulo {currentChapter} de {currentBook.chaptersCount}
          </span>

          <button
            onClick={handleNextChapter}
            className="flex items-center gap-1.5 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl text-xs sm:text-sm font-semibold transition-colors"
          >
            <span>Próximo</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 7. Book & Chapter Selector Modal */}
      {isBookSelectorOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Livros da Bíblia
                </h3>
                <p className="text-xs text-slate-500">
                  Selecione o livro e capítulo desejados
                </p>
              </div>
              <button
                onClick={() => setIsBookSelectorOpen(false)}
                className="p-2 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Testament Tabs & Search */}
            <div className="p-4 border-b border-slate-100 space-y-3 bg-slate-50/50">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setTestamentFilter('ALL')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                    testamentFilter === 'ALL'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  Todos (66)
                </button>
                <button
                  onClick={() => setTestamentFilter('AT')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                    testamentFilter === 'AT'
                      ? 'bg-amber-600 text-white'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  Antigo Testamento (39)
                </button>
                <button
                  onClick={() => setTestamentFilter('NT')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all ${
                    testamentFilter === 'NT'
                      ? 'bg-amber-600 text-white'
                      : 'bg-white text-slate-600 border border-slate-200'
                  }`}
                >
                  Novo Testamento (27)
                </button>
              </div>

              {/* Search in books */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={bookSearchQuery}
                  onChange={(e) => setBookSearchQuery(e.target.value)}
                  placeholder="Buscar livro por nome (ex: Gênesis, Salmos, Mateus)..."
                  className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                />
              </div>
            </div>

            {/* Books List & Chapter Grid */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {filteredBooks.map((book) => {
                  const isSelected = book.id === currentBook.id;
                  return (
                    <div
                      key={book.id}
                      className={`p-3 rounded-2xl border transition-all text-left ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/70 shadow-xs'
                          : 'border-slate-200/80 hover:border-amber-300 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-sm text-slate-900">
                          {book.name}
                        </span>
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded-md">
                          {book.chaptersCount} cap
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-500 block truncate">
                        {book.category}
                      </span>

                      {/* Chapters dropdown / buttons */}
                      <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap gap-1 max-h-20 overflow-y-auto">
                        {Array.from({ length: book.chaptersCount }, (_, i) => i + 1).map((ch) => (
                          <button
                            key={ch}
                            onClick={() => {
                              openChapter(book.id, ch);
                              setIsBookSelectorOpen(false);
                            }}
                            className={`w-6 h-6 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors ${
                              isSelected && ch === currentChapter
                                ? 'bg-amber-600 text-white font-bold'
                                : 'bg-slate-100 hover:bg-amber-200 text-slate-700'
                            }`}
                          >
                            {ch}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
