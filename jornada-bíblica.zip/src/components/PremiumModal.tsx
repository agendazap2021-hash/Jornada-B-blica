import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Crown, Check, Sparkles, ShieldCheck } from 'lucide-react';

export const PremiumModal: React.FC = () => {
  const { isPremiumOpen, setIsPremiumOpen, user, togglePremiumSubscription } = useApp();
  const [selectedBilling, setSelectedBilling] = useState<'monthly' | 'yearly'>('yearly');

  if (!isPremiumOpen) return null;

  const features = [
    { name: 'Leitura Bíblica Completa e Áudio', free: true, premium: true },
    { name: 'Versículo e Devocional Diário', free: true, premium: true },
    { name: 'Quizzes e Desafios Bíblicos Ilimitados', free: false, premium: true },
    { name: 'IA Bíblica Ilimitada (Dúvidas Teológicas)', free: false, premium: true },
    { name: 'Todos os 6 Planos de Leitura (NT 90 dias, Anual)', free: false, premium: true },
    { name: 'Biblioteca Completa de 30+ Personagens', free: false, premium: true },
    { name: 'Estatísticas Avançadas e Histórico Detalhado', free: false, premium: true },
    { name: 'Experiência 100% Livre de Anúncios e Distrações', free: false, premium: true },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Header Banner */}
        <div className="p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white relative overflow-hidden text-center">
          <button
            onClick={() => setIsPremiumOpen(false)}
            className="absolute top-4 right-4 p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-3xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center text-2xl mx-auto mb-3 shadow-inner">
            <Crown className="w-7 h-7 text-amber-400" />
          </div>

          <span className="text-[11px] font-extrabold uppercase tracking-widest text-amber-400 font-mono">
            Jornada Bíblica Premium
          </span>
          <h3 className="text-2xl font-extrabold font-display mt-1">
            Aprofunde sua Fé sem Limites
          </h3>
          <p className="text-xs text-amber-100/80 mt-1 max-w-xs mx-auto leading-relaxed">
            Acesso irrestrito à IA Bíblica, todos os planos de leitura, desafios e estudos profundos.
          </p>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {/* Plan Toggle Billing Cycle */}
          <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-2xl text-xs font-bold">
            <button
              onClick={() => setSelectedBilling('monthly')}
              className={`py-2 rounded-xl transition-all ${
                selectedBilling === 'monthly'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mensal (R$ 14,90/mês)
            </button>
            <button
              onClick={() => setSelectedBilling('yearly')}
              className={`py-2 rounded-xl transition-all relative ${
                selectedBilling === 'yearly'
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Anual (R$ 8,32/mês)</span>
              <span className="ml-1 text-[9px] bg-amber-200 text-amber-950 px-1.5 py-0.2 rounded-full font-extrabold">
                -45% OFF
              </span>
            </button>
          </div>

          {/* Pricing Box */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-center space-y-1">
            <span className="text-xs text-amber-900 font-semibold block">
              {selectedBilling === 'yearly'
                ? 'R$ 99,90 cobrados anualmente (equivalente a R$ 8,32/mês)'
                : 'R$ 14,90 cobrados mensalmente'}
            </span>
            <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-700 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>Teste 7 dias grátis · Cancele quando quiser</span>
            </div>
          </div>

          {/* Feature Comparison */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              O que está incluído:
            </h4>
            <div className="space-y-2">
              {features.map((feat, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between text-xs py-1 border-b border-slate-100 last:border-0"
                >
                  <span className="text-slate-700 font-medium">{feat.name}</span>
                  <div className="flex items-center gap-4 shrink-0 font-bold">
                    <span className={feat.free ? 'text-slate-400 text-[11px]' : 'text-slate-300'}>
                      {feat.free ? 'Grátis' : '—'}
                    </span>
                    <span className="text-emerald-600 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Pro</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Button: Subscribe / Toggle */}
          <div className="pt-2 space-y-2">
            <button
              onClick={() => {
                togglePremiumSubscription();
                setIsPremiumOpen(false);
              }}
              className="w-full py-4 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-white font-extrabold rounded-2xl text-sm transition-all shadow-md shadow-amber-500/20 flex items-center justify-center gap-2"
            >
              <Crown className="w-4 h-4 text-amber-200" />
              <span>
                {user.isPremium
                  ? 'Desativar Modo Premium (Simulação)'
                  : 'Começar 7 Dias Grátis Agora'}
              </span>
            </button>
            <p className="text-[11px] text-slate-600 text-center">
              Sem fidelidade. Cobrança segura via Google Play / App Store.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
