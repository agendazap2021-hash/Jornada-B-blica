import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { QuizCategory, QuizDifficulty, QuizQuestion } from '../types';
import {
  Heart,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Trophy,
  ArrowRight,
  Flame,
  HelpCircle,
  Filter,
} from 'lucide-react';

const CATEGORIES: { id: QuizCategory | 'ALL'; label: string; icon: string }[] = [
  { id: 'ALL', label: 'Todas as Categorias', icon: '✨' },
  { id: 'Personagens', label: 'Personagens', icon: '👥' },
  { id: 'Antigo Testamento', label: 'Antigo Testamento', icon: '📜' },
  { id: 'Novo Testamento', label: 'Novo Testamento', icon: '✝️' },
  { id: 'Jesus', label: 'Jesus', icon: '🕊️' },
  { id: 'Profetas', label: 'Profetas', icon: '🔥' },
  { id: 'Evangelhos', label: 'Evangelhos', icon: '📖' },
  { id: 'Versículos', label: 'Versículos', icon: '💡' },
  { id: 'História bíblica', label: 'História Bíblica', icon: '🏛️' },
];

const DIFFICULTIES: QuizDifficulty[] = ['Fácil', 'Médio', 'Difícil', 'Mestre'];

export const QuizTab: React.FC = () => {
  const { quizQuestions, recordQuizResult, setActiveTab } = useApp();

  // Filter settings
  const [selectedCategory, setSelectedCategory] = useState<QuizCategory | 'ALL'>('ALL');
  const [selectedDifficulty, setSelectedDifficulty] = useState<QuizDifficulty | 'ALL'>('ALL');

  // Game state
  const [gameState, setGameState] = useState<'lobby' | 'playing' | 'gameover' | 'victory'>('lobby');
  const [roundQuestions, setRoundQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lives, setLives] = useState(3);
  const [correctAnswersCount, setCorrectAnswersCount] = useState(0);
  const [roundXpEarned, setRoundXpEarned] = useState(0);

  // Current Question interaction
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState(false);

  // Filter available questions
  const availableQuestions = useMemo(() => {
    return quizQuestions.filter((q) => {
      const matchCat = selectedCategory === 'ALL' || q.category === selectedCategory;
      const matchDiff = selectedDifficulty === 'ALL' || q.difficulty === selectedDifficulty;
      return matchCat && matchDiff;
    });
  }, [quizQuestions, selectedCategory, selectedDifficulty]);

  // Start new round
  const startNewRound = () => {
    const pool = availableQuestions.length >= 10 ? availableQuestions : quizQuestions;
    // Shuffle and pick up to 10
    const shuffled = [...pool].sort(() => 0.5 - Math.random()).slice(0, 10);
    setRoundQuestions(shuffled);
    setCurrentIndex(0);
    setLives(3);
    setCorrectAnswersCount(0);
    setRoundXpEarned(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setGameState('playing');
  };

  const currentQuestion = roundQuestions[currentIndex];

  const handleSelectOption = (index: number) => {
    if (isAnswerSubmitted) return;
    setSelectedOption(index);
  };

  const handleConfirmAnswer = () => {
    if (selectedOption === null || isAnswerSubmitted) return;

    setIsAnswerSubmitted(true);
    const isCorrect = selectedOption === currentQuestion.correctIndex;

    if (isCorrect) {
      setCorrectAnswersCount((c) => c + 1);
      setRoundXpEarned((x) => x + 100);
    } else {
      setLives((l) => {
        const nextLives = l - 1;
        if (nextLives <= 0) {
          // Trigger gameover after small delay
          setTimeout(() => {
            recordQuizResult(correctAnswersCount, currentIndex + 1, roundXpEarned);
            setGameState('gameover');
          }, 1400);
        }
        return nextLives;
      });
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex + 1 < roundQuestions.length) {
      setCurrentIndex((i) => i + 1);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
    } else {
      // Victory / round completed!
      recordQuizResult(correctAnswersCount, roundQuestions.length, roundXpEarned);
      setGameState('victory');
    }
  };

  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-300">
      {/* 1. Lobby State (Selecting category & difficulty) */}
      {gameState === 'lobby' && (
        <div className="space-y-6">
          {/* Hero Banner */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden">
            <div className="relative z-10">
              <span className="text-xs uppercase tracking-wider font-bold text-amber-400 font-mono block mb-2">
                🎮 Desafio Bíblico Gamificado
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-display leading-tight mb-2">
                Teste seus Conhecimentos
              </h2>
              <p className="text-sm text-amber-100/90 leading-relaxed max-w-lg mb-6">
                Cada rodada tem 10 perguntas. Acerte e ganhe +100 XP por pergunta. Cuidado com suas 3 vidas!
              </p>

              <button
                onClick={startNewRound}
                className="px-6 py-3.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-extrabold rounded-2xl text-sm sm:text-base transition-all shadow-md shadow-amber-500/20 inline-flex items-center gap-2 group"
              >
                <span>Iniciar Rodada (10 Perguntas)</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Filters: Category & Difficulty */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-5">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                  Escolha uma Categoria
                </h3>
                <span className="text-xs text-slate-500">
                  {availableQuestions.length} perguntas disponíveis
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-center gap-2.5 ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/80 font-bold text-amber-950 shadow-2xs'
                          : 'border-slate-200/80 hover:border-amber-300 text-slate-700 bg-slate-50/50'
                      }`}
                    >
                      <span className="text-lg">{cat.icon}</span>
                      <span className="text-xs truncate">{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Difficulty Filter */}
            <div className="pt-4 border-t border-slate-100">
              <h4 className="font-bold text-slate-900 text-xs sm:text-sm mb-3">
                Nível de Dificuldade
              </h4>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setSelectedDifficulty('ALL')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    selectedDifficulty === 'ALL'
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Todos os Níveis
                </button>
                {DIFFICULTIES.map((diff) => {
                  const isSelected = selectedDifficulty === diff;
                  return (
                    <button
                      key={diff}
                      onClick={() => setSelectedDifficulty(diff)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 font-bold shadow-2xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {diff}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Active Game Screen */}
      {gameState === 'playing' && currentQuestion && (
        <div className="space-y-6">
          {/* Header with Hearts & Progress */}
          <div className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-4">
            {/* Round progress */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase">
                Pergunta {currentIndex + 1} de {roundQuestions.length}
              </span>
              <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                {currentQuestion.difficulty}
              </span>
            </div>

            {/* Lives ❤️❤️❤️ */}
            <div className="flex items-center gap-1.5" title={`${lives} vidas restantes`}>
              {[1, 2, 3].map((heartIndex) => (
                <Heart
                  key={heartIndex}
                  className={`w-6 h-6 transition-all duration-300 ${
                    heartIndex <= lives
                      ? 'text-rose-500 fill-rose-500 scale-105'
                      : 'text-slate-300 fill-slate-200 opacity-40 scale-95'
                  }`}
                />
              ))}
            </div>

            {/* Score */}
            <div className="flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200/70">
              <span>⭐</span>
              <span>+{roundXpEarned} XP</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-500 rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / roundQuestions.length) * 100}%` }}
            />
          </div>

          {/* Question Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full">
                {currentQuestion.category}
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-slate-500">{currentQuestion.reference}</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
              {currentQuestion.question}
            </h3>

            {/* Options List */}
            <div className="space-y-3">
              {currentQuestion.options.map((option, idx) => {
                const letters = ['A', 'B', 'C', 'D'];
                const isSelected = selectedOption === idx;
                const isCorrect = isAnswerSubmitted && idx === currentQuestion.correctIndex;
                const isWrongSelection = isAnswerSubmitted && isSelected && idx !== currentQuestion.correctIndex;

                return (
                  <button
                    key={idx}
                    disabled={isAnswerSubmitted}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full p-4 rounded-2xl border text-left transition-all flex items-center justify-between gap-3 text-sm sm:text-base font-medium ${
                      isCorrect
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold ring-2 ring-emerald-300'
                        : isWrongSelection
                        ? 'bg-rose-50 border-rose-500 text-rose-950 font-bold ring-2 ring-rose-300'
                        : isSelected
                        ? 'bg-amber-50 border-amber-500 text-amber-950 font-semibold ring-2 ring-amber-300'
                        : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span
                        className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                          isCorrect
                            ? 'bg-emerald-500 text-white'
                            : isWrongSelection
                            ? 'bg-rose-500 text-white'
                            : isSelected
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {letters[idx]}
                      </span>
                      <span>{option}</span>
                    </div>

                    {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />}
                    {isWrongSelection && <XCircle className="w-5 h-5 text-rose-600 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Explanation box after answer submission */}
            {isAnswerSubmitted && (
              <div
                className={`p-4 rounded-2xl border animate-in fade-in space-y-1.5 ${
                  selectedOption === currentQuestion.correctIndex
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                    : 'bg-rose-50/70 border-rose-200 text-rose-900'
                }`}
              >
                <div className="flex items-center gap-2 font-bold text-xs">
                  <span>
                    {selectedOption === currentQuestion.correctIndex
                      ? '✨ Resposta Correta! (+100 XP)'
                      : '❌ Resposta Incorreta (-1 Vida)'}
                  </span>
                  <span>·</span>
                  <span>{currentQuestion.reference}</span>
                </div>
                <p className="text-xs sm:text-sm leading-relaxed">
                  {currentQuestion.explanation}
                </p>
              </div>
            )}

            {/* Actions button */}
            <div className="pt-2">
              {!isAnswerSubmitted ? (
                <button
                  disabled={selectedOption === null}
                  onClick={handleConfirmAnswer}
                  className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-2xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <span>Confirmar Resposta</span>
                </button>
              ) : (
                <button
                  onClick={handleNextQuestion}
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-2xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <span>
                    {currentIndex + 1 < roundQuestions.length ? 'Próxima Pergunta' : 'Ver Resultado'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. Game Over Screen (Lost all 3 lives) */}
      {gameState === 'gameover' && (
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 text-center space-y-5 animate-in zoom-in-95 shadow-sm">
          <div className="w-20 h-20 rounded-full bg-rose-50 border border-rose-200 flex items-center justify-center text-4xl mx-auto">
            💔
          </div>
          <div>
            <h3 className="text-2xl font-extrabold text-slate-900 font-display">
              Você chegou ao fim desta rodada.
            </h3>
            <p className="text-slate-600 text-sm mt-1 max-w-sm mx-auto">
              Suas 3 vidas se esgotaram, mas o estudo bíblico é uma jornada contínua! Não desanime.
            </p>
          </div>

          <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 text-xs font-bold">
            <span>⭐ +{roundXpEarned} XP garantidos na rodada</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
            <button
              onClick={startNewRound}
              className="w-full sm:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-2xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Jogar novamente</span>
            </button>
            <button
              onClick={() => setGameState('lobby')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-2xl text-sm transition-colors"
            >
              Voltar
            </button>
          </div>
        </div>
      )}

      {/* 4. Victory Screen (Finished 10 questions) */}
      {gameState === 'victory' && (
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-amber-200 text-center space-y-5 animate-in zoom-in-95 shadow-lg">
          <div className="w-20 h-20 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-4xl mx-auto shadow-inner animate-bounce">
            🏆
          </div>
          <div>
            <span className="text-xs uppercase tracking-wider font-bold text-amber-700 font-mono">
              Parabéns! Rodada Concluída
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Excelente Desempenho!
            </h3>
            <p className="text-slate-600 text-sm mt-1 max-w-sm mx-auto">
              Você acertou {correctAnswersCount} de {roundQuestions.length} perguntas e demonstrou dedicação à Palavra.
            </p>
          </div>

          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200/80 inline-block">
            <span className="text-xs text-amber-800 font-semibold block">XP Conquistado</span>
            <span className="text-2xl font-extrabold text-amber-900 font-display">
              +{roundXpEarned} XP
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
            <button
              onClick={startNewRound}
              className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-2xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Jogar Nova Rodada</span>
            </button>
            <button
              onClick={() => setGameState('lobby')}
              className="w-full sm:w-auto px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-2xl text-sm transition-colors"
            >
              Voltar ao Menu
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
