import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Sparkles, Award, ArrowUpCircle, Info } from 'lucide-react';

export const NotificationToast: React.FC = () => {
  const { toasts, dismissToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-3">
      {toasts.map((toast) => {
        const isXp = toast.type === 'xp';
        const isLevel = toast.type === 'level';
        const isBadge = toast.type === 'badge';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-2xl shadow-xl border backdrop-blur-md transition-all duration-300 animate-in fade-in slide-in-from-top-4 ${
              isLevel
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white border-amber-300'
                : isBadge
                ? 'bg-slate-900/95 text-white border-amber-400/40'
                : isXp
                ? 'bg-amber-50/95 text-amber-950 border-amber-200'
                : 'bg-white/95 text-slate-800 border-slate-200'
            }`}
          >
            <div className="shrink-0 mt-0.5">
              {isLevel ? (
                <ArrowUpCircle className="w-5 h-5 text-amber-100 animate-bounce" />
              ) : isBadge ? (
                <Award className="w-5 h-5 text-amber-400" />
              ) : isXp ? (
                <Sparkles className="w-5 h-5 text-amber-600" />
              ) : (
                <Info className="w-5 h-5 text-slate-500" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold leading-snug">{toast.title}</h4>
              <p
                className={`text-xs mt-0.5 leading-relaxed line-clamp-2 ${
                  isLevel || isBadge ? 'text-amber-100' : 'text-slate-600'
                }`}
              >
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => dismissToast(toast.id)}
              className={`shrink-0 p-1 rounded-lg transition-colors ${
                isLevel || isBadge
                  ? 'hover:bg-white/20 text-white/80'
                  : 'hover:bg-slate-100 text-slate-400'
              }`}
              aria-label="Fechar notificação"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
