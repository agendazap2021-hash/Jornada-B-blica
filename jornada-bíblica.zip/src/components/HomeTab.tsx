import React from 'react';
import { useApp, getLevelInfo } from '../context/AppContext';
import {
  Sparkles,
  BookOpen,
  ArrowRight,
  HeartHandshake,
  Compass,
  Users,
  CalendarDays,
  Swords,
  Flame,
  CheckCircle2,
  Share2,
  Download,
} from 'lucide-react';

export const HomeTab: React.FC = () => {
  const {
    user,
    openChapter,
    setActiveTab,
    setIsDevotionalOpen,
    setIsAiBibleOpen,
    setIsCharactersOpen,
    setIsPlansOpen,
    setIsExportOpen,
    dailyMissions,
    journeyMilestones,
    showToast,
  } = useApp();

  const levelInfo = getLevelInfo(user.totalXp);

  // Daily verse of the day
  const verseOfTheDay = {
    reference: 'Salmos 23:1-3',
    text: 'O SENHOR é o meu pastor; nada me faltará. Ele me faz repousar em pastos verdejantes. Leva-me para junto das águas de descanso; refrigera-me a alma.',
    bookId: 'sl',
    chapter: 23,
    verse: 1,
  };

  // Find next active journey milestone
  const nextMilestone = journeyMilestones.find((m) => !m.completed) || journeyMilestones[journeyMilestones.length - 1];

  // Greeting based on time of day
  const getGreeting = () => {
    const hours = new Date().getHours();
    if (hours < 12) return 'Bom dia';
    if (hours < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  const handleShareVerse = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`"${verseOfTheDay.text}" — ${verseOfTheDay.reference}`);
      showToast('Copiado para compartilhar!', 'Texto e referência prontos para colar.', 'info');
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* 1. Header Greeting & Motivation */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-display">
            {getGreeting()}! 👋
          </h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1">
            Seu momento com Deus começa agora.
          </p>
        </div>

        {/* Quick Goal Tag */}
        {user.goal && (
          <div className="self-start sm:self-auto px-3.5 py-1.5 bg-amber-50/80 border border-amber-200/80 rounded-full text-xs text-amber-900 font-medium flex items-center gap-1.5 shadow-2xs">
            <span className="text-amber-600">🎯</span>
            <span className="truncate max-w-[220px]">{user.goal}</span>
          </div>
        )}
      </div>

      {/* 2. Gamification Card: Level, Streak & XP Bar */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-amber-100 shadow-sm shadow-amber-900/5 relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-44 h-44 bg-gradient-to-br from-amber-200/40 to-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="grid grid-cols-3 gap-3 divide-x divide-slate-100 mb-5">
          {/* Streak */}
          <div className="text-center px-2">
            <div className="flex items-center justify-center gap-1 text-orange-600 font-bold text-lg sm:text-xl">
              <Flame className="w-5 h-5 fill-orange-500 text-orange-500 animate-pulse" />
              <span>{user.streakDays}</span>
            </div>
            <span className="text-[11px] sm:text-xs text-slate-600 font-medium block mt-0.5">
              Dias consecutivos
            </span>
          </div>

          {/* XP */}
          <div className="text-center px-2">
            <div className="flex items-center justify-center gap-1 text-amber-700 font-bold text-lg sm:text-xl">
              <span>⭐</span>
              <span>{user.totalXp.toLocaleString('pt-BR')}</span>
            </div>
            <span className="text-[11px] sm:text-xs text-slate-600 font-medium block mt-0.5">
              XP Acumulado
            </span>
          </div>

          {/* Current Level */}
          <div className="text-center px-2">
            <div className="text-slate-900 font-bold text-lg sm:text-xl font-display">
              Nível {levelInfo.level}
            </div>
            <span className="text-[11px] sm:text-xs text-amber-800 font-semibold block mt-0.5">
              {levelInfo.levelName}
            </span>
          </div>
        </div>

        {/* Visual Progress Bar to Next Level */}
        <div>
          <div className="flex items-center justify-between text-xs text-slate-600 font-medium mb-1.5">
            <span>Progresso até o próximo nível</span>
            <span className="font-semibold text-amber-900">
              {levelInfo.xpToNext > 0
                ? `Faltam ${levelInfo.xpToNext} XP para Nível ${levelInfo.level + 1}`
                : 'Nível Máximo alcançado! 👑'}
            </span>
          </div>
          <div className="w-full h-3 bg-amber-100/70 rounded-full overflow-hidden p-0.5">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-700 shadow-xs"
              style={{ width: `${levelInfo.percent}%` }}
            />
          </div>
        </div>
      </div>

      {/* 3. Card: Versículo do Dia */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
            <span className="text-xs uppercase tracking-wider font-semibold text-amber-400 font-mono">
              Versículo do Dia
            </span>
          </div>

          <button
            onClick={handleShareVerse}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors"
            title="Compartilhar versículo"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        <blockquote className="font-scripture text-lg sm:text-xl text-amber-50/95 leading-relaxed italic mb-4">
          "{verseOfTheDay.text}"
        </blockquote>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-white/10">
          <span className="text-sm font-semibold tracking-wide text-amber-300">
            {verseOfTheDay.reference}
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsDevotionalOpen(true)}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
            >
              <HeartHandshake className="w-3.5 h-3.5 text-rose-400" />
              <span>Refletir</span>
            </button>

            <button
              onClick={() => openChapter(verseOfTheDay.bookId, verseOfTheDay.chapter)}
              className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-bold rounded-xl text-xs transition-all flex items-center gap-1.5 shadow-md shadow-amber-500/20"
            >
              <span>Ler versículo</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Card: Progresso da Jornada & "Continuar jornada" */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-5">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-2xl shrink-0 shadow-2xs">
            {nextMilestone.icon}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Etapa {nextMilestone.order} de {journeyMilestones.length}
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-xs text-slate-500">{nextMilestone.epoch}</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-0.5">
              {nextMilestone.title}
            </h3>
            <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">
              {nextMilestone.story}
            </p>
          </div>
        </div>

        <button
          onClick={() => setActiveTab('journey')}
          className="self-stretch sm:self-auto px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md shrink-0"
        >
          <Compass className="w-4 h-4 text-amber-400" />
          <span>Continuar jornada</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 5. Missões Diárias (Duolingo style quests) */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-base">🎯</span>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              Missões Diárias
            </h3>
          </div>
          <span className="text-xs font-medium text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200/60">
            Reinicia à meia-noite
          </span>
        </div>

        <div className="space-y-3">
          {dailyMissions.map((mission) => {
            const isDone = mission.completed;
            return (
              <div
                key={mission.id}
                className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                  isDone
                    ? 'bg-emerald-50/50 border-emerald-200/60'
                    : 'bg-slate-50/50 border-slate-200/70 hover:border-amber-300/70'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isDone
                        ? 'bg-emerald-500 text-white'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <span className="text-xs font-bold">+{mission.xpReward}</span>
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs sm:text-sm font-semibold text-slate-900 truncate">
                      {mission.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 truncate">
                      {mission.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-bold text-slate-600">
                    {mission.progress}/{mission.maxProgress}
                  </span>
                  {isDone ? (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                      Feito!
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        if (mission.type === 'read_chapter') openChapter('sl', 23);
                        if (mission.type === 'do_devotional') setIsDevotionalOpen(true);
                        if (mission.type === 'do_quiz') setActiveTab('quiz');
                      }}
                      className="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-[11px] rounded-lg transition-colors"
                    >
                      Fazer
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 6. Quick Access Menu Grid */}
      <div>
        <h3 className="font-bold text-slate-900 text-sm sm:text-base mb-3.5">
          Explore o Aplicativo
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          {/* Card: Momento com Deus */}
          <button
            onClick={() => setIsDevotionalOpen(true)}
            className="p-4 rounded-3xl bg-white hover:bg-rose-50/50 border border-slate-200/80 hover:border-rose-200 text-left transition-all group flex flex-col justify-between h-32 shadow-2xs"
          >
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center text-xl group-hover:scale-105 transition-transform">
              🙏
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block leading-tight">
                Momento com Deus
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Check-in emocional
              </span>
            </div>
          </button>

          {/* Card: Personagens Bíblicos */}
          <button
            onClick={() => setIsCharactersOpen(true)}
            className="p-4 rounded-3xl bg-white hover:bg-amber-50/50 border border-slate-200/80 hover:border-amber-200 text-left transition-all group flex flex-col justify-between h-32 shadow-2xs"
          >
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center text-xl group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block leading-tight">
                Personagens
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                30+ heróis da fé
              </span>
            </div>
          </button>

          {/* Card: Planos de Leitura */}
          <button
            onClick={() => setIsPlansOpen(true)}
            className="p-4 rounded-3xl bg-white hover:bg-sky-50/50 border border-slate-200/80 hover:border-sky-200 text-left transition-all group flex flex-col justify-between h-32 shadow-2xs"
          >
            <div className="w-10 h-10 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center text-xl group-hover:scale-105 transition-transform">
              <CalendarDays className="w-5 h-5 text-sky-700" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block leading-tight">
                Planos de Leitura
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                6 planos guiados
              </span>
            </div>
          </button>

          {/* Card: IA Bíblica */}
          <button
            onClick={() => setIsAiBibleOpen(true)}
            className="p-4 rounded-3xl bg-white hover:bg-indigo-50/50 border border-slate-200/80 hover:border-indigo-200 text-left transition-all group flex flex-col justify-between h-32 shadow-2xs"
          >
            <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center text-xl group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-indigo-700" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-900 block leading-tight">
                IA Bíblica
              </span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                Tire dúvidas teológicas
              </span>
            </div>
          </button>
        </div>

        {/* GitHub Pages testing banner */}
        <div className="mt-4 p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400 shrink-0">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                <span>Quer testar no seu GitHub Pages?</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-bold">
                  Grátis
                </span>
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Baixe o <strong>index.html</strong> único pronto para subir e deixar o Jornada Bíblica online para testes.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsExportOpen(true)}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm shrink-0 transition-transform active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Baixar Página Agora</span>
          </button>
        </div>
      </div>
    </div>
  );
};
