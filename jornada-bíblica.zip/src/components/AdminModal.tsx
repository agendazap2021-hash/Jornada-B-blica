import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { QuizCategory, QuizDifficulty } from '../types';
import {
  X,
  ShieldCheck,
  Plus,
  Users,
  Swords,
  CalendarDays,
  BarChart3,
  CheckCircle2,
} from 'lucide-react';

export const AdminModal: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    quizQuestions,
    addQuizQuestion,
    biblicalCharacters,
    addCharacter,
    readingPlans,
    user,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'metrics' | 'new-question' | 'new-character'>('metrics');

  // Form states for new question
  const [qText, setQText] = useState('');
  const [optA, setOptA] = useState('');
  const [optB, setOptB] = useState('');
  const [optC, setOptC] = useState('');
  const [optD, setOptD] = useState('');
  const [correctIdx, setCorrectIdx] = useState(0);
  const [explanation, setExplanation] = useState('');
  const [reference, setReference] = useState('');
  const [category, setCategory] = useState<QuizCategory>('Personagens');
  const [difficulty, setDifficulty] = useState<QuizDifficulty>('Fácil');

  // Form state for new character
  const [charName, setCharName] = useState('');
  const [charRole, setCharRole] = useState('');
  const [charTestament, setCharTestament] = useState<'AT' | 'NT'>('AT');
  const [charSummary, setCharSummary] = useState('');
  const [charIcon, setCharIcon] = useState('⭐');

  if (!isAdminOpen) return null;

  const handleCreateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qText.trim() || !optA.trim() || !optB.trim() || !optC.trim() || !optD.trim() || !reference.trim()) {
      showToast('Campos incompletos', 'Preencha todos os campos da pergunta.', 'info');
      return;
    }

    addQuizQuestion({
      id: `q-custom-${Date.now()}`,
      question: qText.trim(),
      options: [optA.trim(), optB.trim(), optC.trim(), optD.trim()],
      correctIndex: correctIdx,
      explanation: explanation.trim() || 'Resposta bíblica fundamentada.',
      reference: reference.trim(),
      category,
      difficulty,
      xpReward: 100,
    });

    // Reset form
    setQText('');
    setOptA('');
    setOptB('');
    setOptC('');
    setOptD('');
    setExplanation('');
    setReference('');
    setActiveTab('metrics');
  };

  const handleCreateCharacter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!charName.trim() || !charRole.trim() || !charSummary.trim()) {
      showToast('Campos incompletos', 'Preencha o nome, papel e resumo do personagem.', 'info');
      return;
    }

    addCharacter({
      id: `char-custom-${Date.now()}`,
      name: charName.trim(),
      role: charRole.trim(),
      testament: charTestament,
      category: 'Líderes e Juízes',
      avatarIcon: charIcon || '⭐',
      summary: charSummary.trim(),
      importantEvents: ['Chamado e obediência à vontade de Deus.'],
      keyVerses: [{ ref: 'Referência', text: 'Citação inspiradora das Escrituras.' }],
      curiosities: ['Mencionado nas Sagradas Escrituras como testemunha fiel.'],
    });

    setCharName('');
    setCharRole('');
    setCharSummary('');
    setActiveTab('metrics');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-indigo-50/60">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg">
                Painel do Administrador
              </h3>
              <p className="text-xs text-slate-500">
                Gerenciamento de banco de dados, conteúdos, quizzes e métricas
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAdminOpen(false)}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="p-3 border-b border-slate-100 flex items-center gap-2 bg-slate-50/50">
          <button
            onClick={() => setActiveTab('metrics')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'metrics'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Métricas do App</span>
          </button>

          <button
            onClick={() => setActiveTab('new-question')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'new-question'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Cadastrar Pergunta</span>
          </button>

          <button
            onClick={() => setActiveTab('new-character')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'new-character'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Cadastrar Personagem</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6">
          {activeTab === 'metrics' && (
            <div className="space-y-5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Estatísticas em Tempo Real do Banco de Dados
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100">
                  <span className="text-2xl font-extrabold text-indigo-900 block font-display">
                    {quizQuestions.length}
                  </span>
                  <span className="text-xs text-slate-600">Perguntas no Quiz</span>
                </div>

                <div className="p-4 rounded-2xl bg-amber-50/50 border border-amber-100">
                  <span className="text-2xl font-extrabold text-amber-900 block font-display">
                    {biblicalCharacters.length}
                  </span>
                  <span className="text-xs text-slate-600">Personagens</span>
                </div>

                <div className="p-4 rounded-2xl bg-sky-50/50 border border-sky-100">
                  <span className="text-2xl font-extrabold text-sky-900 block font-display">
                    {readingPlans.length}
                  </span>
                  <span className="text-xs text-slate-600">Planos de Leitura</span>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100">
                  <span className="text-2xl font-extrabold text-emerald-900 block font-display">
                    66
                  </span>
                  <span className="text-xs text-slate-600">Livros Bíblicos</span>
                </div>
              </div>

              {/* Current User Snapshot */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200/80 space-y-2">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Sessão Ativa: {user.name} ({user.email})
                </span>
                <div className="text-xs text-slate-600 grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                  <div>XP: <strong>{user.totalXp}</strong></div>
                  <div>Nível: <strong>{user.level} ({user.levelName})</strong></div>
                  <div>Capítulos: <strong>{user.chaptersReadCount}</strong></div>
                  <div>Status: <strong>{user.isPremium ? 'Premium 👑' : 'Gratuito'}</strong></div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'new-question' && (
            <form onSubmit={handleCreateQuestion} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Enunciado da Pergunta *
                </label>
                <input
                  type="text"
                  required
                  value={qText}
                  onChange={(e) => setQText(e.target.value)}
                  placeholder="Ex: Em qual monte Moisés recebeu as Tábuas da Lei?"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Opção A *</label>
                  <input
                    type="text"
                    required
                    value={optA}
                    onChange={(e) => setOptA(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Opção B *</label>
                  <input
                    type="text"
                    required
                    value={optB}
                    onChange={(e) => setOptB(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Opção C *</label>
                  <input
                    type="text"
                    required
                    value={optC}
                    onChange={(e) => setOptC(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Opção D *</label>
                  <input
                    type="text"
                    required
                    value={optD}
                    onChange={(e) => setOptD(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Opção Correta</label>
                  <select
                    value={correctIdx}
                    onChange={(e) => setCorrectIdx(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value={0}>Opção A</option>
                    <option value={1}>Opção B</option>
                    <option value={2}>Opção C</option>
                    <option value={3}>Opção D</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Categoria</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as QuizCategory)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="Personagens">Personagens</option>
                    <option value="Antigo Testamento">Antigo Testamento</option>
                    <option value="Novo Testamento">Novo Testamento</option>
                    <option value="Jesus">Jesus</option>
                    <option value="Profetas">Profetas</option>
                    <option value="Evangelhos">Evangelhos</option>
                    <option value="Versículos">Versículos</option>
                    <option value="História bíblica">História bíblica</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Dificuldade</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as QuizDifficulty)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="Fácil">Fácil</option>
                    <option value="Médio">Médio</option>
                    <option value="Difícil">Difícil</option>
                    <option value="Mestre">Mestre</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Referência Bíblica * (ex: Êxodo 19:20)
                </label>
                <input
                  type="text"
                  required
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  placeholder="Êxodo 20:1"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Explicação Teológica
                </label>
                <textarea
                  rows={2}
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  placeholder="Breve comentário explicando a resposta correta..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md"
              >
                Salvar Pergunta no Banco
              </button>
            </form>
          )}

          {activeTab === 'new-character' && (
            <form onSubmit={handleCreateCharacter} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Nome *</label>
                  <input
                    type="text"
                    required
                    value={charName}
                    onChange={(e) => setCharName(e.target.value)}
                    placeholder="Ex: Isaías"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Papel / Título *</label>
                  <input
                    type="text"
                    required
                    value={charRole}
                    onChange={(e) => setCharRole(e.target.value)}
                    placeholder="Ex: O Profeta Messiânico"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Testamento</label>
                  <select
                    value={charTestament}
                    onChange={(e) => setCharTestament(e.target.value as 'AT' | 'NT')}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="AT">Antigo Testamento</option>
                    <option value="NT">Novo Testamento</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Emoji / Ícone</label>
                  <input
                    type="text"
                    value={charIcon}
                    onChange={(e) => setCharIcon(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Resumo Biográfico *</label>
                <textarea
                  rows={3}
                  required
                  value={charSummary}
                  onChange={(e) => setCharSummary(e.target.value)}
                  placeholder="Síntese da vida e importância desse personagem..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md"
              >
                Cadastrar Personagem
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
