import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, CheckCircle2, ArrowRight } from 'lucide-react';

const GOAL_OPTIONS = [
  { id: 'read_more', label: 'Ler mais a Bíblia', icon: '📖', desc: 'Criar o hábito sagrado de leitura contínua e imersão nas Escrituras.' },
  { id: 'daily_moment', label: 'Ter um momento diário com Deus', icon: '🙏', desc: 'Devocionais curtos, oração e renovação espiritual diária.' },
  { id: 'know_better', label: 'Conhecer melhor a Bíblia', icon: '🎯', desc: 'Compreender o contexto histórico, os livros e o plano da salvação.' },
  { id: 'study_characters', label: 'Estudar personagens', icon: '🧠', desc: 'Aprender lições profundas com os grandes heróis e mulheres da fé.' },
  { id: 'learn_challenges', label: 'Aprender através de desafios', icon: '🎮', desc: 'Gamificação, quizzes bíblicos, vidas e conquistas semanais.' },
];

export const OnboardingModal: React.FC = () => {
  const { isOnboardingOpen, setIsOnboardingOpen, updateUserGoal, user } = useApp();
  const [selectedGoal, setSelectedGoal] = useState<string>(user.goal || GOAL_OPTIONS[0].label);

  if (!isOnboardingOpen) return null;

  const handleSave = () => {
    updateUserGoal(selectedGoal);
    setIsOnboardingOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/65 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl space-y-5 animate-in zoom-in-95">
        <div className="text-center space-y-1">
          <span className="text-xs uppercase tracking-wider font-extrabold text-amber-700 font-mono">
            Personalize sua Experiência
          </span>
          <h3 className="text-2xl font-extrabold text-slate-900 font-display">
            Qual seu objetivo principal?
          </h3>
          <p className="text-xs text-slate-500">
            Usaremos sua resposta para recomendar conteúdos e planos na Home.
          </p>
        </div>

        {/* Options */}
        <div className="space-y-2.5">
          {GOAL_OPTIONS.map((g) => {
            const isSelected = selectedGoal === g.label;

            return (
              <button
                key={g.id}
                onClick={() => setSelectedGoal(g.label)}
                className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-start gap-3 ${
                  isSelected
                    ? 'border-amber-500 bg-amber-50/80 shadow-2xs ring-2 ring-amber-300'
                    : 'border-slate-200/80 hover:border-amber-300 bg-white'
                }`}
              >
                <span className="text-2xl shrink-0 mt-0.5">{g.icon}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-slate-900">
                      {g.label}
                    </span>
                    {isSelected && (
                      <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                    {g.desc}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        <button
          onClick={handleSave}
          className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2"
        >
          <span>Continuar</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
