import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BibleIAAnswer } from '../types';
import {
  X,
  Sparkles,
  Send,
  Loader2,
  BookOpen,
  HelpCircle,
  Share2,
  AlertCircle,
} from 'lucide-react';

const SUGGESTED_QUESTIONS = [
  'O que significa a parábola do Filho Pródigo?',
  'Quem era Davi e qual sua importância?',
  'Qual o contexto histórico do Salmo 23?',
  'Quais versículos bíblicos falam sobre vencer a ansiedade?',
  'O que significa "O Verbo se fez carne" em João 1?',
];

export const AiBibleModal: React.FC = () => {
  const { isAiBibleOpen, setIsAiBibleOpen, currentBookId, currentChapter, showToast } = useApp();
  const [question, setQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [answer, setAnswer] = useState<BibleIAAnswer | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isAiBibleOpen) return null;

  const handleAsk = async (queryText?: string) => {
    const q = (queryText || question).trim();
    if (!q) return;

    setLoading(true);
    setErrorMsg(null);
    if (queryText) setQuestion(queryText);

    try {
      const response = await fetch('/api/gemini/bible-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: q,
          context: `Livro ID: ${currentBookId}, Capítulo: ${currentChapter}`,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success && data.answer) {
          setAnswer(data.answer);
          return;
        }
      }
      throw new Error('API não disponível no host estático');
    } catch {
      // Fallback estático inteligente para quando o app estiver no GitHub Pages (sem backend Node)
      const qLower = q.toLowerCase();
      let fallbackAnswer: BibleIAAnswer;

      if (qLower.includes('davi') || qLower.includes('golias')) {
        fallbackAnswer = {
          scripture: '«O Senhor é o meu pastor; de nada terei falta. Em verdes pastagens me faz repousar e me conduz a águas tranquilas.» — Salmos 23:1-2',
          explanation: 'Davi foi o segundo rei de Israel, ungido pelo profeta Samuel enquanto ainda era um jovem pastor de ovelhas em Belém. Ficou famoso por sua coragem contra o gigante Golias e por sua profunda comunhão com Deus, sendo chamado de "um homem segundo o coração de Deus" (1 Samuel 13:14).',
          interpretation: 'A trajetória de Davi revela que Deus não vê como o homem vê — o homem olha para a aparência exterior, mas o Senhor sonda o coração. Mesmo enfrentando perseguições e falhas humanas, Davi sempre retornava a Deus com arrependimento sincero.',
          reflection: 'Não importa o tamanho dos gigantes ou desafios à sua frente: sua força não vem de armaduras humanas, mas da confiança na soberania e no poder de Deus.'
        };
      } else if (qLower.includes('ansiedade') || qLower.includes('medo') || qLower.includes('preocupa')) {
        fallbackAnswer = {
          scripture: '«Não andeis ansiosos de coisa alguma; em tudo, porém, sejam conhecidas diante de Deus as vossas petições, pela oração e pela súplica, com ações de graças. E a paz de Deus guardará os vossos corações.» — Filipenses 4:6-7',
          explanation: 'O apóstolo Paulo escreveu estas palavras da prisão em Roma. Em vez de focar no cárcere ou nas incertezas, ele ensinou à igreja de Filipos o caminho da oração confiante e da gratidão diária.',
          interpretation: 'A ansiedade bíblica não é tratada como mera fraqueza, mas como um convite para depositar o fardo nas mãos do Pai celestial que cuida até mesmo dos lírios do campo e dos pássaros do céu (Mateus 6).',
          reflection: 'Qual preocupação está pesando em seus ombros hoje? Entregue-a em oração e permita que a paz celestial substitua a inquietação mental.'
        };
      } else if (qLower.includes('pródigo') || qLower.includes('perdão') || qLower.includes('graça')) {
        fallbackAnswer = {
          scripture: '«E, levantando-se, foi para seu pai. Vinha ele ainda longe, quando seu pai o avistou, e, compadecido dele, correndo, o abraçou, e o beijou.» — Lucas 15:20',
          explanation: 'A parábola do Filho Pródigo contada por Jesus em Lucas 15 ilustra o coração do Pai para com os pecadores arrependidos e confronta a atitude rígida e julgadora dos fariseus representada pelo irmão mais velho.',
          interpretation: 'O amor divino não exige que você pague ou se justifique para ser aceito de volta. A graça de Deus corre ao encontro daquele que se volta para o lar.',
          reflection: 'A misericórdia de Deus é inesgotável. Se você se sente distante, saiba que os braços do Pai continuam abertos esperando o seu retorno.'
        };
      } else if (qLower.includes('verbo') || qLower.includes('joão') || qLower.includes('jesus')) {
        fallbackAnswer = {
          scripture: '«No princípio era o Verbo, e o Verbo estava com Deus, e o Verbo era Deus. E o Verbo se fez carne e habitou entre nós, cheio de graça e de verdade.» — João 1:1, 14',
          explanation: 'João usa o conceito de "Logos" (o Verbo, a Palavra Viva) para proclamar a divindade eterna de Jesus Cristo e o mistério sublime da Encarnação divina na história humana.',
          interpretation: 'Deus não permaneceu distante ou inalcançável; Ele Se fez próximo, participou das dores e alegrias humanas e revelou o amor supremo através da cruz e ressurreição.',
          reflection: 'Jesus é a revelação viva de quem Deus é. Seguir Seus ensinamentos transforma o propósito de cada dia e ilumina suas escolhas.'
        };
      } else {
        fallbackAnswer = {
          scripture: '«Lâmpada para os meus pés é a tua palavra e luz, para o meu caminho.» — Salmos 119:105',
          explanation: `Estudo bíblico sobre: "${q}". A Escritura Sagrada é viva, eficaz e suficiente para nos instruir em toda boa obra (2 Timóteo 3:16).`,
          interpretation: 'Em toda a Bíblia, vemos a fidelidade imutável de Deus guiando Seus servos através da fé, da esperança e da caridade.',
          reflection: 'Guarde os ensinamentos divinos no seu coração. A leitura diária com oração produz sabedoria prática e paz espiritual.'
        };
      }

      setAnswer(fallbackAnswer);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyAnswer = () => {
    if (!answer) return;
    const text = `IA Bíblica: "${question}"\n\nTEXTO BÍBLICO:\n${answer.scripture}\n\nEXPLICAÇÃO:\n${answer.explanation}\n\nINTERPRETAÇÃO:\n${answer.interpretation}\n\nREFLEXÃO:\n${answer.reflection}\n\n— Jornada Bíblica`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('Estudo bíblico copiado!', 'Texto copiado para a área de transferência.', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-amber-50 to-amber-100/60">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg flex items-center gap-1.5">
                <span>Pergunte sobre a Bíblia</span>
                <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold">
                  IA Bíblica
                </span>
              </h3>
              <p className="text-xs text-slate-600">
                Respostas estruturadas separando texto sagrado, contexto e reflexão
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAiBibleOpen(false)}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* Question input */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
              Sua Dúvida Teológica ou Textual
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
                placeholder="Ex: O que significa essa passagem? Quem era Davi?..."
                className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
              />
              <button
                disabled={loading || !question.trim()}
                onClick={() => handleAsk()}
                className="px-5 py-3 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all flex items-center gap-2 shrink-0 shadow-xs"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span className="hidden sm:inline">Perguntar</span>
              </button>
            </div>
          </div>

          {/* Suggested Quick Questions */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-slate-500 block">
              Sugestões frequentes:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {SUGGESTED_QUESTIONS.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAsk(q)}
                  disabled={loading}
                  className="px-3 py-1.5 bg-amber-50/70 hover:bg-amber-100/80 border border-amber-200/70 rounded-full text-xs text-amber-950 font-medium transition-colors text-left"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Loading indicator */}
          {loading && (
            <div className="py-12 text-center space-y-3">
              <Loader2 className="w-8 h-8 text-amber-600 animate-spin mx-auto" />
              <p className="text-sm font-semibold text-slate-800">
                Consultando as Escrituras e fontes históricas...
              </p>
              <p className="text-xs text-slate-500">
                Diferenciando texto bíblico, exegese e interpretação teológica.
              </p>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-rose-800 text-xs sm:text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Answer Cards with the 4 strict biblical sections */}
          {answer && !loading && (
            <div className="space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Resposta Estruturada da IA Bíblica
                </span>
                <button
                  onClick={handleCopyAnswer}
                  className="text-xs font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Copiar Estudo</span>
                </button>
              </div>

              {/* 1. TEXTO BÍBLICO */}
              <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/90 border border-amber-300 space-y-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-900 font-mono block">
                  📜 TEXTO BÍBLICO (Citação Literal)
                </span>
                <blockquote className="font-scripture text-sm sm:text-base text-amber-950 italic leading-relaxed">
                  {answer.scripture}
                </blockquote>
              </div>

              {/* 2. EXPLICAÇÃO */}
              <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/80 space-y-1.5 shadow-2xs">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 font-mono block">
                  🔍 EXPLICAÇÃO HISTÓRICA E LINGUÍSTICA
                </span>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {answer.explanation}
                </p>
              </div>

              {/* 3. INTERPRETAÇÃO */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-900 font-mono block">
                  💡 INTERPRETAÇÃO TEOLÓGICA
                </span>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {answer.interpretation}
                </p>
              </div>

              {/* 4. REFLEXÃO */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white space-y-1.5 shadow-md">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-400 font-mono block">
                  🕊️ REFLEXÃO PRÁTICA E ORAÇÃO
                </span>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  {answer.reflection}
                </p>
              </div>

              <p className="text-[11px] text-slate-600 text-center italic">
                * A Jornada Bíblica separa rigorosamente a Palavra inspirada das explicações e reflexões humanas.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
