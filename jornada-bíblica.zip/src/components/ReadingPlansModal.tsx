import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ReadingPlan } from '../types';
import {
  X,
  CalendarDays,
  CheckCircle2,
  Circle,
  BookOpen,
  ArrowRight,
  Crown,
  Lock,
} from 'lucide-react';

export const ReadingPlansModal: React.FC = () => {
  const {
    isPlansOpen,
    setIsPlansOpen,
    readingPlans,
    togglePlanDay,
    selectedPlan,
    setSelectedPlan,
    openChapter,
    setIsPremiumOpen,
    user,
  } = useApp();

  if (!isPlansOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-sky-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center text-xl shadow-xs">
              <CalendarDays className="w-5 h-5 text-sky-700" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg">
                Planos de Leitura Bíblica
              </h3>
              <p className="text-xs text-slate-500">
                Guias estruturados para manter a disciplina diária na Palavra
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsPlansOpen(false);
              setSelectedPlan(null);
            }}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {!selectedPlan ? (
            /* Plans Overview List */
            <div className="space-y-3.5">
              {readingPlans.map((plan) => {
                const completedDaysCount = plan.days.filter((d) => d.completed).length;
                const percent = Math.round((completedDaysCount / plan.durationDays) * 100);
                const isLocked = plan.isPremium && !user.isPremium;

                return (
                  <div
                    key={plan.id}
                    className={`p-5 rounded-3xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                      isLocked
                        ? 'bg-slate-50/70 border-slate-200/80 opacity-75'
                        : 'bg-white border-slate-200/80 hover:border-sky-300 shadow-2xs'
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded-md">
                          {plan.category}
                        </span>
                        <span className="text-xs text-slate-400">·</span>
                        <span className="text-xs font-semibold text-slate-600">
                          {plan.durationDays} dias
                        </span>
                        {plan.isPremium && (
                          <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <Crown className="w-3 h-3 text-amber-600" />
                            <span>Premium</span>
                          </span>
                        )}
                      </div>

                      <h4 className="text-base font-bold text-slate-900 leading-tight">
                        {plan.title}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                        {plan.description}
                      </p>

                      {/* Progress Bar */}
                      <div className="mt-3">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600 mb-1">
                          <span>
                            {completedDaysCount} de {plan.durationDays} dias concluídos
                          </span>
                          <span className="font-bold text-sky-700">{percent}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-sky-500 rounded-full transition-all duration-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    <div className="shrink-0">
                      {isLocked ? (
                        <button
                          onClick={() => setIsPremiumOpen(true)}
                          className="w-full sm:w-auto px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Desbloquear</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => setSelectedPlan(plan)}
                          className="w-full sm:w-auto px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          <span>Continuar plano</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Selected Plan Days View */
            <div className="space-y-5 animate-in fade-in">
              <button
                onClick={() => setSelectedPlan(null)}
                className="text-xs font-bold text-sky-700 hover:underline flex items-center gap-1"
              >
                ← Voltar aos planos
              </button>

              {/* Plan Header */}
              <div className="p-5 rounded-3xl bg-slate-900 text-white shadow-md">
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 font-mono">
                  {selectedPlan.category} · {selectedPlan.durationDays} dias
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold font-display text-white mt-1">
                  {selectedPlan.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  {selectedPlan.description}
                </p>

                {/* Progress in Header */}
                <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                  <span>
                    Concluídos:{' '}
                    <strong>
                      {selectedPlan.days.filter((d) => d.completed).length}/
                      {selectedPlan.durationDays}
                    </strong>
                  </span>
                  <span className="font-bold text-sky-300">
                    {Math.round(
                      (selectedPlan.days.filter((d) => d.completed).length /
                        selectedPlan.durationDays) *
                        100
                    )}
                    %
                  </span>
                </div>
              </div>

              {/* Days List */}
              <div className="space-y-2">
                {selectedPlan.days.map((day) => {
                  const isDone = day.completed;

                  return (
                    <div
                      key={day.day}
                      className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                        isDone
                          ? 'bg-emerald-50/60 border-emerald-200'
                          : 'bg-white border-slate-200/80 hover:border-sky-300'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Checkbox Button */}
                        <button
                          onClick={() => togglePlanDay(selectedPlan.id, day.day)}
                          className="shrink-0 p-1 hover:scale-110 transition-transform"
                          title={isDone ? 'Desmarcar dia' : 'Marcar dia como lido (+25 XP)'}
                        >
                          {isDone ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          ) : (
                            <Circle className="w-5 h-5 text-slate-300 hover:text-slate-400" />
                          )}
                        </button>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900">
                              Dia {day.day}
                            </span>
                            <span className="text-[11px] text-slate-500 truncate">
                              {day.title}
                            </span>
                          </div>

                          {/* Passages buttons */}
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {day.passages.map((p, pIdx) => (
                              <button
                                key={pIdx}
                                onClick={() => {
                                  openChapter(p.bookId, p.chapter);
                                  setIsPlansOpen(false);
                                }}
                                className="px-2 py-0.5 bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-900 rounded-md text-[11px] font-semibold flex items-center gap-1 transition-colors"
                              >
                                <BookOpen className="w-3 h-3" />
                                <span>
                                  {p.bookName} {p.chapter}
                                </span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {isDone && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-md shrink-0">
                          Lido!
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
