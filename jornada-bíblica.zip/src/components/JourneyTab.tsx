import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { JourneyMilestone } from '../types';
import {
  Lock,
  CheckCircle2,
  ArrowRight,
  BookOpen,
  Users,
  Swords,
  X,
  Sparkles,
} from 'lucide-react';

export const JourneyTab: React.FC = () => {
  const {
    journeyMilestones,
    completeMilestone,
    openChapter,
    setActiveTab,
    setIsCharactersOpen,
    user,
  } = useApp();

  const [selectedMilestone, setSelectedMilestone] = useState<JourneyMilestone | null>(null);

  const handleOpenMilestone = (m: JourneyMilestone) => {
    setSelectedMilestone(m);
  };

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-300">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden">
        <span className="text-xs uppercase tracking-wider font-bold text-amber-400 font-mono block mb-1">
          🗺️ O Grande Mapa da Salvação
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold font-display leading-tight mb-2">
          Jornada Bíblica
        </h2>
        <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed max-w-lg">
          Percorra os grandes marcos da história sagrada, desde a Criação no Éden até a Nova Jerusalém no Apocalipse.
        </p>
      </div>

      {/* Interactive Road / Journey Timeline */}
      <div className="relative max-w-xl mx-auto px-4 py-6">
        {/* Vertical Journey Path Line */}
        <div className="absolute left-1/2 top-4 bottom-8 -translate-x-1/2 w-1.5 bg-gradient-to-b from-amber-400 via-amber-200 to-slate-200 rounded-full" />

        <div className="space-y-10 relative">
          {journeyMilestones.map((milestone, idx) => {
            const isCompleted = milestone.completed;
            const isUnlocked = user.totalXp >= milestone.requiredXp || isCompleted;
            const isCurrent = !isCompleted && isUnlocked;
            const isEven = idx % 2 === 0;

            return (
              <div
                key={milestone.id}
                className={`flex items-center gap-4 sm:gap-6 ${
                  isEven ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                {/* Milestone Card */}
                <div
                  onClick={() => isUnlocked && handleOpenMilestone(milestone)}
                  className={`w-[45%] p-4 rounded-3xl border transition-all cursor-pointer ${
                    isEven ? 'text-right' : 'text-left'
                  } ${
                    isCompleted
                      ? 'bg-white border-emerald-300/80 shadow-xs hover:border-emerald-400'
                      : isCurrent
                      ? 'bg-amber-50/90 border-amber-400 shadow-md ring-2 ring-amber-300 hover:bg-amber-100/70'
                      : 'bg-slate-50/70 border-slate-200/80 opacity-60 cursor-not-allowed'
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">
                    Etapa {milestone.order}
                  </span>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-tight mt-0.5">
                    {milestone.title}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-1">
                    {milestone.subtitle}
                  </p>

                  <div
                    className={`mt-2 flex items-center gap-1.5 text-[10px] font-semibold ${
                      isEven ? 'justify-end' : 'justify-start'
                    } ${
                      isCompleted
                        ? 'text-emerald-700'
                        : isCurrent
                        ? 'text-amber-800'
                        : 'text-slate-500'
                    }`}
                  >
                    {isCompleted ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Concluída</span>
                      </>
                    ) : isCurrent ? (
                      <>
                        <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                        <span>Em andamento</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3" />
                        <span>Bloqueada ({milestone.requiredXp} XP)</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Central Node Circle */}
                <button
                  onClick={() => isUnlocked && handleOpenMilestone(milestone)}
                  disabled={!isUnlocked}
                  className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl z-10 transition-all duration-300 shrink-0 ${
                    isCompleted
                      ? 'bg-emerald-500 text-white shadow-md ring-4 ring-emerald-100 hover:scale-105'
                      : isCurrent
                      ? 'bg-gradient-to-br from-amber-400 to-amber-500 text-white shadow-lg ring-4 ring-amber-200 animate-pulse hover:scale-110'
                      : 'bg-slate-200 text-slate-400 ring-4 ring-slate-100 cursor-not-allowed'
                  }`}
                >
                  {milestone.icon}
                </button>

                {/* Empty spacer for alternating balance */}
                <div className="w-[45%]" />
              </div>
            );
          })}
        </div>
      </div>

      {/* Milestone Detail Modal */}
      {selectedMilestone && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl relative space-y-5 animate-in zoom-in-95">
            <button
              onClick={() => setSelectedMilestone(null)}
              className="absolute top-4 right-4 p-2 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center text-3xl shrink-0 shadow-2xs">
                {selectedMilestone.icon}
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
                  Etapa {selectedMilestone.order} · {selectedMilestone.epoch}
                </span>
                <h3 className="text-xl font-bold text-slate-900 leading-snug">
                  {selectedMilestone.title}
                </h3>
                <p className="text-xs text-slate-500">{selectedMilestone.subtitle}</p>
              </div>
            </div>

            {/* Narrative Story */}
            <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200/70 text-xs sm:text-sm text-slate-700 leading-relaxed font-scripture">
              "{selectedMilestone.story}"
            </div>

            {/* Recommended Chapters */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span>Capítulos Recomendados</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {selectedMilestone.recommendedChapters.map((ch, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      openChapter(ch.bookId, ch.chapter);
                      setSelectedMilestone(null);
                    }}
                    className="p-2.5 rounded-xl border border-slate-200/80 hover:border-amber-300 hover:bg-amber-50/50 text-left transition-all flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-xs text-slate-900 block">
                        {ch.bookName} {ch.chapter}
                      </span>
                      <span className="text-[10px] text-slate-500 block truncate">
                        {ch.label}
                      </span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-600" />
                  </button>
                ))}
              </div>
            </div>

            {/* Key Characters */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-amber-600" />
                <span>Personagens Relevantes</span>
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {selectedMilestone.keyCharacters.map((charName, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setIsCharactersOpen(true);
                      setSelectedMilestone(null);
                    }}
                    className="px-3 py-1 bg-slate-100 hover:bg-amber-100 rounded-full text-xs font-medium text-slate-700 transition-colors"
                  >
                    {charName}
                  </button>
                ))}
              </div>
            </div>

            {/* Actions Button: Quiz or Complete milestone */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
              <button
                onClick={() => {
                  setSelectedMilestone(null);
                  setActiveTab('quiz');
                }}
                className="w-full sm:flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Swords className="w-4 h-4 text-amber-400" />
                <span>Fazer Desafio ({selectedMilestone.quizCategory})</span>
              </button>

              {!selectedMilestone.completed && (
                <button
                  onClick={() => {
                    completeMilestone(selectedMilestone.id);
                    setSelectedMilestone(null);
                  }}
                  className="w-full sm:w-auto px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-2xl text-xs transition-all shadow-md flex items-center justify-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Concluir Etapa (+250 XP)</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
