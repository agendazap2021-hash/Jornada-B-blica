import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MOOD_ENTRIES } from '../data/emotionsData';
import { MoodEntry, EmotionalMood } from '../types';
import { X, HeartHandshake, CheckCircle2, Sparkles, BookOpen, Share2 } from 'lucide-react';

export const DevotionalModal: React.FC = () => {
  const { isDevotionalOpen, setIsDevotionalOpen, completeDevotional, showToast, openChapter } = useApp();
  const [selectedMood, setSelectedMood] = useState<MoodEntry | null>(null);
  const [isCompletedThisSession, setIsCompletedThisSession] = useState(false);

  if (!isDevotionalOpen) return null;

  const handleSelectMood = (mood: MoodEntry) => {
    setSelectedMood(mood);
    setIsCompletedThisSession(false);
  };

  const handleFinish = () => {
    completeDevotional();
    setIsCompletedThisSession(true);
  };

  const handleShare = () => {
    if (!selectedMood) return;
    const text = `Momento com Deus: "${selectedMood.verse.text}" (${selectedMood.verse.reference})\n\nReflexão: ${selectedMood.reflection}\n\nOração: ${selectedMood.prayer}\n\n— Jornada Bíblica`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('Devocional copiado!', 'Pronto para compartilhar no WhatsApp ou redes.', 'info');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center text-xl">
              🙏
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg">
                Momento com Deus
              </h3>
              <p className="text-xs text-slate-500">
                Um refúgio diário para oração, paz e renovação da alma
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsDevotionalOpen(false)}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {!selectedMood ? (
            <div className="space-y-4">
              <div className="text-center py-2">
                <span className="text-xs uppercase tracking-wider font-bold text-amber-700 font-mono">
                  Check-in do Coração
                </span>
                <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 font-display mt-1">
                  Como você está hoje?
                </h4>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-sm mx-auto">
                  Deus conhece cada detalhe do seu ser. Escolha o sentimento que mais reflete seu momento agora:
                </p>
              </div>

              {/* Mood Buttons Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {MOOD_ENTRIES.map((mood) => (
                  <button
                    key={mood.id}
                    onClick={() => handleSelectMood(mood)}
                    className="p-3.5 rounded-2xl border border-slate-200/80 hover:border-amber-400 hover:bg-amber-50/50 text-left transition-all flex items-center gap-3 group shadow-2xs"
                  >
                    <span className="text-2xl group-hover:scale-110 transition-transform">
                      {mood.emoji}
                    </span>
                    <span className="text-sm font-bold text-slate-800">
                      {mood.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-5 animate-in fade-in">
              {/* Active mood banner */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{selectedMood.emoji}</span>
                  <span className="text-sm font-bold text-slate-900">
                    {selectedMood.label}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedMood(null)}
                  className="text-xs text-amber-700 hover:underline font-semibold"
                >
                  Trocar sentimento
                </button>
              </div>

              {/* 1. Scripture section */}
              <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800 font-mono">
                    📜 Palavra de Deus
                  </span>
                  <span className="text-xs font-bold text-amber-900">
                    {selectedMood.verse.reference}
                  </span>
                </div>
                <blockquote className="font-scripture text-base sm:text-lg text-amber-950 italic leading-relaxed">
                  "{selectedMood.verse.text}"
                </blockquote>
              </div>

              {/* 2. Reflection section */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200/80 space-y-2 shadow-2xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
                  🕊️ Reflexão para Hoje
                </span>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {selectedMood.reflection}
                </p>
              </div>

              {/* 3. Suggested Prayer */}
              <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-2 shadow-md">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 font-mono block">
                  🙏 Oração Sugerida
                </span>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed italic">
                  "{selectedMood.prayer}"
                </p>
              </div>

              {/* Actions */}
              <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
                {!isCompletedThisSession ? (
                  <button
                    onClick={handleFinish}
                    className="w-full sm:flex-1 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Concluir Momento com Deus (+30 XP)</span>
                  </button>
                ) : (
                  <div className="w-full sm:flex-1 py-3 bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold rounded-2xl text-xs sm:text-sm flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Momento Concluído com Sucesso! (+30 XP)</span>
                  </div>
                )}

                <button
                  onClick={handleShare}
                  className="w-full sm:w-auto px-4 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl text-xs transition-colors flex items-center justify-center gap-1.5"
                  title="Compartilhar devocional"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Compartilhar</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
