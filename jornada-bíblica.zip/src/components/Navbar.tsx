import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Crown, Flame, BookOpen, HeartHandshake, Download } from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    user,
    setIsDevotionalOpen,
    setIsAiBibleOpen,
    setIsPremiumOpen,
    setActiveTab,
    setIsAuthOpen,
    setIsExportOpen,
  } = useApp();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-amber-100/60 transition-all">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        {/* Brand */}
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left group focus:outline-none"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="font-display font-bold text-lg tracking-tight text-slate-900 block leading-tight">
              Jornada Bíblica
            </span>
            <span className="text-[10px] font-medium tracking-wide text-amber-700/80 uppercase block">
              Estudo & Fé
            </span>
          </div>
        </button>

        {/* Gamification Badges & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Streak indicator */}
          <div
            title="Sequência diária de leitura"
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-50 border border-amber-200/70 rounded-full text-amber-900 text-xs font-semibold"
          >
            <Flame className="w-4 h-4 text-orange-500 fill-orange-500 animate-pulse" />
            <span>{user.streakDays}d</span>
          </div>

          {/* XP indicator */}
          <div
            title="Experiência acumulada"
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-500/10 border border-amber-300/60 rounded-full text-amber-900 text-xs font-bold"
          >
            <span className="text-amber-500 text-sm">⭐</span>
            <span>{user.totalXp.toLocaleString('pt-BR')} XP</span>
          </div>

          {/* Quick Action: Momento com Deus */}
          <button
            onClick={() => setIsDevotionalOpen(true)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-colors border border-slate-200/80"
            title="Momento com Deus — Devocional emocional"
          >
            <HeartHandshake className="w-4 h-4 text-rose-500" />
            <span>Devocional</span>
          </button>

          {/* Quick Action: IA Bíblica */}
          <button
            onClick={() => setIsAiBibleOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100/70 hover:bg-amber-100 rounded-full transition-all border border-amber-300/80 shadow-xs"
            title="Pergunte sobre a Bíblia com inteligência teológica"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-spin-slow" />
            <span className="hidden xs:inline">IA Bíblica</span>
          </button>

          {/* Download for GitHub Pages button */}
          <button
            onClick={() => setIsExportOpen(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-950 bg-slate-100 hover:bg-slate-200/90 rounded-full transition-all border border-slate-200 shadow-xs"
            title="Baixar página para testar no GitHub Pages"
          >
            <Download className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Baixar p/ Git</span>
          </button>

          {/* Premium button */}
          <button
            onClick={() => setIsPremiumOpen(true)}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold rounded-full transition-all ${
              user.isPremium
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-sm'
                : 'text-amber-800 bg-amber-50 hover:bg-amber-100/80 border border-amber-200'
            }`}
            title="Assinatura Premium"
          >
            <Crown className={`w-3.5 h-3.5 ${user.isPremium ? 'text-amber-200' : 'text-amber-600'}`} />
            <span className="hidden sm:inline">{user.isPremium ? 'Premium' : 'Seja Pro'}</span>
          </button>

          {/* Avatar button */}
          <button
            onClick={() => setIsAuthOpen(true)}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 flex items-center justify-center text-sm font-bold text-slate-800 transition-colors ml-0.5"
            title="Conta & Perfil"
          >
            {user.avatar || '👤'}
          </button>
        </div>
      </div>
    </header>
  );
};
