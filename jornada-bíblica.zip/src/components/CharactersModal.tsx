import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { BiblicalCharacter } from '../types';
import {
  X,
  Search,
  Users,
  BookOpen,
  Swords,
  Sparkles,
  ChevronRight,
  Filter,
} from 'lucide-react';

const CATEGORIES = [
  'Todos',
  'Patriarcas',
  'Líderes e Juízes',
  'Reis',
  'Profetas',
  'Mulheres da Bíblia',
  'Apóstolos e Discípulos',
  'Figuras Centrais',
];

export const CharactersModal: React.FC = () => {
  const {
    isCharactersOpen,
    setIsCharactersOpen,
    biblicalCharacters,
    selectedCharacter,
    setSelectedCharacter,
    setActiveTab,
    openChapter,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('Todos');

  if (!isCharactersOpen) return null;

  const filteredCharacters = useMemo(() => {
    return biblicalCharacters.filter((c) => {
      const matchCat = selectedCat === 'Todos' || c.category === selectedCat;
      const matchSearch =
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.summary.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [biblicalCharacters, selectedCat, searchQuery]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-amber-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-xl shadow-xs">
              👥
            </div>
            <div>
              <h3 className="font-bold text-slate-900 font-display text-lg">
                Biblioteca de Personagens Bíblicos
              </h3>
              <p className="text-xs text-slate-500">
                {biblicalCharacters.length} heróis, líderes e testemunhas da fé
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsCharactersOpen(false);
              setSelectedCharacter(null);
            }}
            className="p-2 rounded-xl hover:bg-slate-200/60 text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {!selectedCharacter ? (
            <div className="space-y-4">
              {/* Search & Categories */}
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar personagem por nome ou história (ex: Moisés, Davi, Ester)..."
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                  />
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCat(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                        selectedCat === cat
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Characters Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredCharacters.map((char) => (
                  <div
                    key={char.id}
                    className="p-4 rounded-3xl border border-slate-200/80 hover:border-amber-300 hover:bg-amber-50/30 transition-all flex flex-col justify-between shadow-2xs group"
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-900 flex items-center justify-center text-2xl shrink-0 group-hover:scale-105 transition-transform">
                          {char.avatarIcon}
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-slate-900 text-sm sm:text-base leading-tight">
                            {char.name}
                          </h4>
                          <span className="text-[11px] font-medium text-amber-800 block truncate">
                            {char.role}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {char.summary}
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => setSelectedCharacter(char)}
                        className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1"
                      >
                        <span>Conhecer história</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          setIsCharactersOpen(false);
                          setActiveTab('quiz');
                        }}
                        className="px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl text-xs font-bold transition-colors flex items-center gap-1"
                      >
                        <Swords className="w-3.5 h-3.5 text-amber-700" />
                        <span>Fazer desafio</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Selected Character Deep Profile View */
            <div className="space-y-6 animate-in fade-in">
              {/* Back button */}
              <button
                onClick={() => setSelectedCharacter(null)}
                className="text-xs font-bold text-amber-800 hover:underline flex items-center gap-1"
              >
                ← Voltar à lista de personagens
              </button>

              {/* Profile Header */}
              <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 to-amber-950 text-white flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left shadow-lg">
                <div className="w-20 h-20 rounded-3xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-4xl shrink-0">
                  {selectedCharacter.avatarIcon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded-full uppercase tracking-wider">
                      {selectedCharacter.category}
                    </span>
                    <span className="text-xs text-slate-300">
                      {selectedCharacter.testament === 'AT' ? 'Antigo Testamento' : 'Novo Testamento'}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-white mt-1">
                    {selectedCharacter.name}
                  </h3>
                  <p className="text-xs sm:text-sm text-amber-200/90 font-medium mt-0.5">
                    {selectedCharacter.role}
                  </p>
                </div>
              </div>

              {/* Summary */}
              <div className="p-5 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-xs sm:text-sm text-slate-800 leading-relaxed font-scripture">
                "{selectedCharacter.summary}"
              </div>

              {/* Key Events */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>Acontecimentos Importantes</span>
                </h4>
                <ul className="space-y-1.5">
                  {selectedCharacter.importantEvents.map((event, idx) => (
                    <li
                      key={idx}
                      className="p-3 bg-white rounded-xl border border-slate-200/80 text-xs sm:text-sm text-slate-700 flex items-start gap-2.5 shadow-2xs"
                    >
                      <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{event}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Main Verses */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                  <span>Principais Versículos</span>
                </h4>
                <div className="space-y-2">
                  {selectedCharacter.keyVerses.map((verse, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1"
                    >
                      <span className="text-xs font-bold text-amber-800 block">
                        {verse.ref}
                      </span>
                      <blockquote className="font-scripture text-xs sm:text-sm text-slate-800 italic leading-relaxed">
                        "{verse.text}"
                      </blockquote>
                    </div>
                  ))}
                </div>
              </div>

              {/* Curiosities */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                  <span>💡</span>
                  <span>Curiosidades Históricas e Bíblicas</span>
                </h4>
                <div className="space-y-1.5">
                  {selectedCharacter.curiosities.map((curio, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-amber-50/50 rounded-xl border border-amber-200/60 text-xs text-slate-700"
                    >
                      • {curio}
                    </div>
                  ))}
                </div>
              </div>

              {/* Action: Challenge */}
              <div className="pt-2">
                <button
                  onClick={() => {
                    setIsCharactersOpen(false);
                    setActiveTab('quiz');
                  }}
                  className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Swords className="w-4 h-4 text-amber-400" />
                  <span>Fazer Desafio sobre {selectedCharacter.name}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
