import os
import glob
import zipfile
import re

dist_dir = 'dist'
public_dir = 'public'
os.makedirs(public_dir, exist_ok=True)

# 1. Read dist/index.html
with open(os.path.join(dist_dir, 'index.html'), 'r', encoding='utf-8') as f:
    html_content = f.read()

# 2. Find CSS and JS
css_files = glob.glob(os.path.join(dist_dir, 'assets', '*.css'))
js_files = glob.glob(os.path.join(dist_dir, 'assets', '*.js'))

css_content = ""
if css_files:
    with open(css_files[0], 'r', encoding='utf-8') as f:
        css_content = f.read()

js_content = ""
if js_files:
    with open(js_files[0], 'r', encoding='utf-8') as f:
        js_content = f.read()

# 3. Create standalone HTML using lambda or direct string replace to avoid regex escape issues
safe_js = js_content.replace('</script>', '<\\/script>')

# Replace stylesheet link
standalone_html = re.sub(
    r'<link rel="stylesheet"[^>]*href="[^"]*assets/[^"]*\.css"[^>]*>',
    lambda m: f'<style>\n{css_content}\n</style>',
    html_content
)

# Replace script tag
standalone_html = re.sub(
    r'<script type="module"[^>]*src="[^"]*assets/[^"]*\.js"[^>]*></script>',
    lambda m: f'<script type="module">\n{safe_js}\n</script>',
    standalone_html
)

standalone_path = os.path.join(public_dir, 'jornada-biblica-unico.html')
with open(standalone_path, 'w', encoding='utf-8') as f:
    f.write(standalone_html)
print(f"Generated standalone HTML: {standalone_path} ({len(standalone_html)} bytes)")

# Also save standalone index.html in a specific folder for easy download
standalone_dir = os.path.join(public_dir, 'standalone')
os.makedirs(standalone_dir, exist_ok=True)
with open(os.path.join(standalone_dir, 'index.html'), 'w', encoding='utf-8') as f:
    f.write(standalone_html)

# 4. Create ZIP package with standard dist folder (index.html + assets/)
zip_path = os.path.join(public_dir, 'jornada-biblica-github-pages.zip')
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(dist_dir):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, dist_dir)
            zipf.write(file_path, arcname)

print(f"Generated ZIP package: {zip_path} ({os.path.getsize(zip_path)} bytes)")

# 5. Also create a ZIP containing just the standalone single index.html
zip_single_path = os.path.join(public_dir, 'jornada-biblica-arquivo-unico.zip')
with zipfile.ZipFile(zip_single_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipf.write(standalone_path, 'index.html')

print(f"Generated single-file ZIP: {zip_single_path} ({os.path.getsize(zip_single_path)} bytes)")
